package com.example.rokbot

import android.content.Context
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedDeque
import kotlin.math.max

/**
 * Tracks runtime, learning-active time, recognition outcomes and verified accuracy.
 * Learning time is wall-clock elapsed only while eligible learning work is active.
 * Never sums parallel engine durations.
 */
object IntelligenceMetrics {
    private const val PREF = "intelligence_metrics"
    private const val HISTORY_FILE = "intelligence_history.json"
    private const val MAX_HISTORY = 500

    @Volatile private var botStartElapsed: Long = 0L
    @Volatile private var captureStartElapsed: Long = 0L
    @Volatile var totalBotRuntimeMs: Long = 0L; private set
    @Volatile var totalCaptureActiveMs: Long = 0L; private set
    @Volatile var learningActiveMs: Long = 0L; private set
    @Volatile private var learningSegmentStart: Long = 0L
    @Volatile private var learningActive: Boolean = false

    // recognition counters (session + persisted)
    @Volatile var verifiedCorrect: Int = 0; private set
    @Volatile var incorrectDetections: Int = 0; private set
    @Volatile var rejectedDetections: Int = 0; private set
    @Volatile var ambiguousDetections: Int = 0; private set
    @Volatile var totalEvaluatedExamples: Int = 0; private set
    @Volatile var successfulGameActions: Int = 0; private set
    @Volatile var confirmedGatheringOutcomes: Int = 0; private set
    @Volatile var failedGameActions: Int = 0; private set

    private val perCategory = LinkedHashMap<String, CatStats>()
    private val history = ConcurrentLinkedDeque<AccuracyPoint>()
    private var loaded = false

    data class CatStats(var correct: Int = 0, var incorrect: Int = 0, var rejected: Int = 0, var ambiguous: Int = 0, var evaluated: Int = 0)
    data class AccuracyPoint(val timeMs: Long, val accuracy: Double?, val evaluated: Int, val note: String = "")

    @Synchronized fun load(ctx: Context) {
        if (loaded) return
        val p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        totalBotRuntimeMs = p.getLong("botRuntime", 0L)
        totalCaptureActiveMs = p.getLong("captureRuntime", 0L)
        learningActiveMs = p.getLong("learningActive", 0L)
        verifiedCorrect = p.getInt("vCorrect", 0)
        incorrectDetections = p.getInt("vIncorrect", 0)
        rejectedDetections = p.getInt("rejected", 0)
        ambiguousDetections = p.getInt("ambiguous", 0)
        totalEvaluatedExamples = p.getInt("evaluated", 0)
        successfulGameActions = p.getInt("actionOk", 0)
        confirmedGatheringOutcomes = p.getInt("gatherOk", 0)
        failedGameActions = p.getInt("actionFail", 0)
        loadHistory(ctx)
        loaded = true
    }

    @Synchronized fun persist(ctx: Context) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putLong("botRuntime", totalBotRuntimeMs + runningBotSegment())
            .putLong("captureRuntime", totalCaptureActiveMs + runningCaptureSegment())
            .putLong("learningActive", currentLearningActiveMs())
            .putInt("vCorrect", verifiedCorrect).putInt("vIncorrect", incorrectDetections)
            .putInt("rejected", rejectedDetections).putInt("ambiguous", ambiguousDetections)
            .putInt("evaluated", totalEvaluatedExamples)
            .putInt("actionOk", successfulGameActions).putInt("gatherOk", confirmedGatheringOutcomes)
            .putInt("actionFail", failedGameActions).apply()
        persistHistory(ctx)
    }

    fun onBotStarted() { if (botStartElapsed == 0L) botStartElapsed = SystemClock.elapsedRealtime() }
    fun onBotStopped(ctx: Context?) {
        if (botStartElapsed != 0L) { totalBotRuntimeMs += SystemClock.elapsedRealtime() - botStartElapsed; botStartElapsed = 0L }
        endLearningSegment()
        if (ctx != null) persist(ctx)
    }
    fun onCaptureStarted() { if (captureStartElapsed == 0L) captureStartElapsed = SystemClock.elapsedRealtime() }
    fun onCaptureStopped(ctx: Context?) {
        if (captureStartElapsed != 0L) { totalCaptureActiveMs += SystemClock.elapsedRealtime() - captureStartElapsed; captureStartElapsed = 0L }
        if (ctx != null) persist(ctx)
    }

    fun beginLearningSegment() {
        if (!learningActive) { learningActive = true; learningSegmentStart = SystemClock.elapsedRealtime() }
    }
    fun endLearningSegment() {
        if (learningActive) { learningActiveMs += max(0L, SystemClock.elapsedRealtime() - learningSegmentStart); learningActive = false; learningSegmentStart = 0L }
    }
    fun currentLearningActiveMs(): Long = learningActiveMs + if (learningActive) max(0L, SystemClock.elapsedRealtime() - learningSegmentStart) else 0L
    fun runningBotSegment(): Long = if (botStartElapsed == 0L) 0L else SystemClock.elapsedRealtime() - botStartElapsed
    fun runningCaptureSegment(): Long = if (captureStartElapsed == 0L) 0L else SystemClock.elapsedRealtime() - captureStartElapsed
    fun currentBotRuntimeMs(): Long = totalBotRuntimeMs + runningBotSegment()
    fun currentCaptureActiveMs(): Long = totalCaptureActiveMs + runningCaptureSegment()

    @Synchronized fun recordRecognition(category: String, outcome: RecognitionOutcome, verified: Boolean) {
        totalEvaluatedExamples++
        val cs = perCategory.getOrPut(category) { CatStats() }
        cs.evaluated++
        when (outcome) {
            RecognitionOutcome.CORRECT -> { verifiedCorrect++; cs.correct++ }
            RecognitionOutcome.INCORRECT -> { incorrectDetections++; cs.incorrect++ }
            RecognitionOutcome.REJECTED -> { rejectedDetections++; cs.rejected++ }
            RecognitionOutcome.AMBIGUOUS -> { ambiguousDetections++; cs.ambiguous++ }
        }
        if (verified) addHistoryPoint("verified:$category:$outcome")
    }
    @Synchronized fun recordAction(success: Boolean, gatheringConfirmed: Boolean = false) {
        if (success) { successfulGameActions++; if (gatheringConfirmed) confirmedGatheringOutcomes++ } else failedGameActions++
    }

    fun verifiedAccuracy(): Double? {
        val denom = verifiedCorrect + incorrectDetections
        return if (denom == 0) null else verifiedCorrect.toDouble() / denom
    }

    @Synchronized private fun addHistoryPoint(note: String) {
        val p = AccuracyPoint(System.currentTimeMillis(), verifiedAccuracy(), verifiedCorrect + incorrectDetections, note)
        history.addLast(p)
        while (history.size > MAX_HISTORY) history.removeFirst()
    }

    fun historySnapshot(): List<AccuracyPoint> = history.toList()
    @Synchronized fun categorySnapshot(): Map<String, CatStats> = perCategory.mapValues { it.value.copy() }

    @Synchronized fun resetAll(ctx: Context) {
        totalBotRuntimeMs = 0; totalCaptureActiveMs = 0; learningActiveMs = 0
        botStartElapsed = 0; captureStartElapsed = 0; learningSegmentStart = 0; learningActive = false
        verifiedCorrect = 0; incorrectDetections = 0; rejectedDetections = 0; ambiguousDetections = 0
        totalEvaluatedExamples = 0; successfulGameActions = 0; confirmedGatheringOutcomes = 0; failedGameActions = 0
        perCategory.clear(); history.clear(); persist(ctx)
    }

    private fun historyFile(ctx: Context): File = File(ctx.filesDir, HISTORY_FILE)
    private fun loadHistory(ctx: Context) {
        history.clear()
        try {
            val f = historyFile(ctx)
            if (f.isFile) {
                val arr = JSONArray(f.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val acc = if (o.isNull("acc")) null else o.optDouble("acc")
                    history.addLast(AccuracyPoint(o.optLong("t"), acc, o.optInt("n"), o.optString("note","")))
                }
            }
        } catch (_: Exception) {}
    }
    private fun persistHistory(ctx: Context) {
        try {
            val arr = JSONArray()
            history.forEach { p -> arr.put(JSONObject().put("t", p.timeMs).put("acc", p.accuracy ?: JSONObject.NULL).put("n", p.evaluated).put("note", p.note)) }
            historyFile(ctx).writeText(arr.toString())
        } catch (_: Exception) {}
    }

    fun formatDuration(ms: Long): String {
        val s = ms / 1000; val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return if (h > 0) "%dh %02dm %02ds".format(h, m, sec) else "%dm %02ds".format(m, sec)
    }
    fun accuracyText(): String {
        val a = verifiedAccuracy()
        return if (a == null) "Insufficient verified examples" else "%.1f%% (%d/%d verified)".format(a * 100.0, verifiedCorrect, verifiedCorrect + incorrectDetections)
    }
}

enum class RecognitionOutcome { CORRECT, INCORRECT, REJECTED, AMBIGUOUS }
