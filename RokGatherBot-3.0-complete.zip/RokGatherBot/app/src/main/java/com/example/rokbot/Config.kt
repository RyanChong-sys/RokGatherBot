package com.example.rokbot

/** UI automation state inferred from freshly recognised, workflow-specific screen markers. */
enum class GameState {
    UNKNOWN,
    GAME_LOADING,
    WORLD_MAP,
    SEARCH_PANEL,
    RESOURCE_SELECTION,
    RESOURCE_SEARCH_RESULTS,
    RESOURCE_SELECTED,
    RESOURCE_INFORMATION,
    TROOP_SELECTION,
    MARCH_PREPARATION,
    MARCH_CONFIRMATION,
    MARCH_DISPATCHED,
    MARCH_ACTIVE,
    GATHERING,
    GATHERING_COMPLETED,
    NO_FREE_MARCH,
    NO_TROOPS,
    RESOURCE_NOT_FOUND,
    POPUP,
    UNEXPECTED_POPUP,
    ERROR
}

/** Normalized ROI: left/top inclusive, right/bottom exclusive, values in [0,1]. */
data class NormalizedRoi(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    fun validate() {
        require(listOf(left, top, right, bottom).all { it.isFinite() && it in 0f..1f }) {
            "ROI coordinates must be finite values from 0 to 1"
        }
        require(right > left && bottom > top) { "ROI must have positive width and height" }
    }

    fun toPixels(width: Int, height: Int): IntArray {
        validate()
        require(width > 0 && height > 0) { "invalid screenshot dimensions" }
        val l = (left * width).toInt().coerceIn(0, width)
        val t = (top * height).toInt().coerceIn(0, height)
        val r = kotlin.math.ceil(right * width).toInt().coerceIn(0, width)
        val b = kotlin.math.ceil(bottom * height).toInt().coerceIn(0, height)
        require(r > l && b > t) { "ROI is empty at current screenshot dimensions" }
        return intArrayOf(l, t, r, b)
    }
}

/** An action. x/y remain historical anchor metadata only; they are never used as tap targets. */
data class Step(
    val name: String,
    val x: Float,
    val y: Float,
    val waitMs: Long,
    val template: String? = null,
    val timeoutMs: Long = 5000,
    val state: GameState = GameState.UNKNOWN,
    val nextState: GameState? = null,
    val verifyTemplate: String? = null,
)

data class Blocker(val template: String, val noMarches: Boolean = false)

object Config {
    // x/y are retained only as legacy metadata. Safe actions always use current detections.
    val searchButton = Step(
        "open search", 0.06f, 0.78f, 700, "btn_search", 5000,
        GameState.WORLD_MAP, GameState.SEARCH_PANEL, "tab_food"
    )

    val resourceTabs = mapOf(
        "food" to Step("food tab", 0.20f, 0.60f, 450, "tab_food", 5000,
            GameState.SEARCH_PANEL, GameState.RESOURCE_SELECTION, "btn_search_go"),
        "wood" to Step("wood tab", 0.32f, 0.60f, 450, "tab_wood", 5000,
            GameState.SEARCH_PANEL, GameState.RESOURCE_SELECTION, "btn_search_go"),
        "stone" to Step("stone tab", 0.44f, 0.60f, 450, "tab_stone", 5000,
            GameState.SEARCH_PANEL, GameState.RESOURCE_SELECTION, "btn_search_go"),
        "gold" to Step("gold tab", 0.56f, 0.60f, 450, "tab_gold", 5000,
            GameState.SEARCH_PANEL, GameState.RESOURCE_SELECTION, "btn_search_go"),
    )

    val searchGo = Step("search", 0.38f, 0.82f, 1800, "btn_search_go", 5000,
        GameState.RESOURCE_SELECTION, GameState.RESOURCE_INFORMATION, "btn_gather")
    val gatherButton = Step("gather", 0.62f, 0.55f, 900, "btn_gather", 5000,
        GameState.RESOURCE_INFORMATION, GameState.TROOP_SELECTION, "btn_new_troops")
    val newTroops = Step("new troops", 0.80f, 0.70f, 800, "btn_new_troops", 5000,
        GameState.TROOP_SELECTION, GameState.MARCH_CONFIRMATION, "btn_march")
    val marchButton = Step("march", 0.80f, 0.85f, 1000, "btn_march", 7000,
        GameState.MARCH_CONFIRMATION, GameState.GATHERING, null)
    val dismiss = Step("close popup", 0.93f, 0.08f, 600, "btn_close", 3000,
        GameState.POPUP, GameState.UNKNOWN, null)

    val blockers = listOf(
        Blocker("popup_no_free_march", noMarches = true),
        Blocker("popup_not_found"),
        Blocker("popup_no_troops"),
    )

    val expectedTemplates: List<String>
        get() = (listOf(searchButton) + resourceTabs.values +
            listOf(searchGo, gatherButton, newTroops, marchButton, dismiss))
            .mapNotNull { it.template } + blockers.map { it.template }

    val requiredTemplates: List<String>
        get() = (listOf(searchButton) + rotation.distinct().mapNotNull { resourceTabs[it] } +
            listOf(searchGo, gatherButton, newTroops, marchButton, dismiss))
            .mapNotNull { it.template } + blockers.map { it.template }

    /** User-configured ordered weighted rotation. Repeating a resource gives it more turns. */
    @Volatile var rotation: List<String> = listOf("food", "wood", "stone", "gold")
    @Volatile var maxMarches = 3
    @Volatile var threshold = 0.78
    @Volatile var cycleWaitMs = 30L * 60 * 1000
    @Volatile var retryWaitMs = 2L * 60 * 1000
    @Volatile var maxRetryWaitMs = 15L * 60 * 1000
    @Volatile var maxFailedRounds = 3
    @Volatile var diagnosticMode = false

    /** Per-action overrides; unspecified identifiers use the global threshold. */
    val thresholdOverrides: MutableMap<String, Double> = mutableMapOf()

    /** Tighten or widen this bounded set only after checking screenshots and template scale. */
    val scaleFactors: List<Float> = listOf(0.90f, 0.95f, 1.0f, 1.05f, 1.10f)

    const val gamePackage = "com.lilithgame.roc.gp"
    const val maxConfiguredMaxRetryWaitMs = 6L * 60 * 60 * 1000
    const val maxRotationEntries = 16
    const val minCycleWaitMs = 60L * 1000
    const val maxCycleWaitMs = 12L * 60 * 60 * 1000
    const val minRetryWaitMs = 60L * 1000
    const val maxConfiguredRetryWaitMs = 60L * 60 * 1000
    const val pollIntervalMs = 350L
    const val marchVerifyTimeoutMs = 7000L
    const val transitionVerifyTimeoutMs = 5000L
    const val requiredMissingFrames = 2
    const val verifyRegionMarginPx = 8
    const val gestureDurationMs = 80L
    const val gestureTimeoutMs = 2500L
    const val DELAY_JITTER = 0.10

    fun thresholdFor(template: String): Double =
        thresholdOverrides[template]?.coerceIn(0.50, 0.99) ?: threshold
}
