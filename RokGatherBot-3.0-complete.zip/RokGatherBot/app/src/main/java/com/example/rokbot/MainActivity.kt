package com.example.rokbot

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.cancel
import java.io.FileOutputStream

/** Dark, compact control panel. All existing automation actions remain wired to their original services. */
class MainActivity : Activity() {
    private val reqCapture = 42
    private val scope = CoroutineScope(Dispatchers.Default)
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var info: TextView
    private lateinit var accessValue: TextView
    private lateinit var captureValue: TextView
    private lateinit var botValue: TextView
    private lateinit var stateValue: TextView
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var logMeta: TextView
    private var lastRenderedLogSnapshot: String? = null
    private lateinit var diagnosticButton: Button
    private lateinit var learningSummary: TextView
    private lateinit var learningSwitch: Switch
    private lateinit var marchSlots: EditText
    private lateinit var rotationOrder: EditText
    private lateinit var thresholdInput: EditText
    private lateinit var cycleWaitInput: EditText
    private lateinit var retryWaitInput: EditText
    private lateinit var maxRetryWaitInput: EditText
    private lateinit var failedRoundsInput: EditText
    private val resourceChecks = linkedMapOf<String, CheckBox>()

    private val tick = object : Runnable {
        override fun run() {
            refreshDashboard()
            ui.postDelayed(this, 1000)
        }
    }

    private object Palette {
        const val BACKGROUND = 0xFF050608.toInt()
        const val SURFACE = 0xFF101115.toInt()
        const val SURFACE_ALT = 0xFF191C22.toInt()
        const val FIELD = 0xFF0A0C10.toInt()
        const val BORDER = 0xFF252B35.toInt()
        const val TEXT = 0xFFF1F4FA.toInt()
        const val MUTED = 0xFFA5B0C2.toInt()
        const val ACCENT = 0xFFA8C7FF.toInt()
        const val ACCENT_DARK = 0xFF244A77.toInt()
        const val GREEN = 0xFF72D6AA.toInt()
        const val RED = 0xFFFF7C86.toInt()
        const val AMBER = 0xFFFFC879.toInt()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Templates.init(this)
        try { BotSettings.load(this) } catch (_: Exception) {}
        initEngineFramework(this)
        EngineSupervisor.start()
        RoiConfig.load(Templates.folder())
        ThresholdConfig.load(Templates.folder())
        BotSettings.load(this)

        window.statusBarColor = Palette.BACKGROUND
        window.navigationBarColor = Palette.BACKGROUND
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        // App shell: compact brand header, independent tab pages and a floating-style bottom bar.
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Palette.BACKGROUND)
        }
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(13), dp(20), dp(11))
            background = rounded(Palette.BACKGROUND, 0)
        }
        val brandMark = TextView(this).apply {
            text = "R"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Palette.ACCENT)
            background = rounded(Palette.ACCENT_DARK, 13)
            layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginEnd = dp(11) }
        }
        topBar.addView(brandMark)
        val brandText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brandText.addView(TextView(this).apply {
            text = "ROK GATHER BOT 3.0"
            textSize = 12f
            letterSpacing = 0.09f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Palette.TEXT)
        })
        brandText.addView(TextView(this).apply {
            text = "ADAPTIVE INTELLIGENCE & COMPANION"
            textSize = 9f
            letterSpacing = 0.07f
            setTextColor(Palette.MUTED)
        })
        topBar.addView(brandText)
        topBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val versionBadge = TextView(this).apply {
            text = "3.0"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Palette.ACCENT)
            background = rounded(Palette.ACCENT_DARK, 20)
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        topBar.addView(versionBadge)
        root.addView(topBar, LinearLayout.LayoutParams(-1, -2))

        val contentHost = FrameLayout(this)
        root.addView(contentHost, LinearLayout.LayoutParams(-1, 0, 1f))

        fun createTabPage(): Pair<ScrollView, LinearLayout> {
            val content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(17), dp(8), dp(17), dp(22))
            }
            val scroll = ScrollView(this).apply {
                isFillViewport = true
                clipToPadding = false
                setPadding(0, 0, 0, dp(8))
                addView(content, FrameLayout.LayoutParams(-1, -2))
            }
            contentHost.addView(scroll, FrameLayout.LayoutParams(-1, -1))
            return scroll to content
        }
        fun addPageHeading(parent: LinearLayout, kicker: String, title: String, subtitle: String) {
            parent.addView(TextView(this).apply {
                text = kicker.uppercase()
                textSize = 10f
                letterSpacing = 0.13f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Palette.ACCENT)
                setPadding(0, dp(7), 0, dp(5))
            })
            parent.addView(TextView(this).apply {
                text = title
                textSize = 26f
                typeface = Typeface.create("sans-serif", Typeface.BOLD)
                setTextColor(Palette.TEXT)
            })
            parent.addView(TextView(this).apply {
                text = subtitle
                textSize = 12f
                setTextColor(Palette.MUTED)
                setPadding(0, dp(4), 0, dp(17))
            })
        }

        val (homeScroll, page) = createTabPage()
        val (gatherScroll, gatherPage) = createTabPage()
        val (recognitionScroll, recognitionPage) = createTabPage()
        val (activityScroll, activityPage) = createTabPage()
        val (settingsScroll, settingsPage) = createTabPage()
        val tabPages = linkedMapOf(
            "HOME" to homeScroll, "GATHER" to gatherScroll, "RECOGNITION" to recognitionScroll,
            "ACTIVITY" to activityScroll, "SETTINGS" to settingsScroll
        )
        addPageHeading(page, "OVERVIEW", "RokGatherBot 2.0", "Adaptive resource gathering · local recognition intelligence")
        addPageHeading(gatherPage, "AUTOMATION PROFILE", "Gathering", "Set resource priorities, march capacity and recovery timing")
        addPageHeading(recognitionPage, "COMPUTER VISION", "Recognition", "Templates, diagnostics and verified adaptive learning")
        addPageHeading(activityPage, "SYSTEM MONITOR", "Activity", "A chronological record of inputs, detections and service events")
        addPageHeading(settingsPage, "DEVICE SERVICES", "Settings", "Accessibility permissions and screen-capture lifecycle")

        // Live status card
        val statusCard = section(page, "LIVE STATUS", "Service health and current game context")
        val statusRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val accessTile = statusTile("ACCESSIBILITY", "OFF")
        accessValue = accessTile.second
        statusRow.addView(accessTile.first, weightedParams())
        val captureTile = statusTile("SCREEN CAPTURE", "OFF")
        captureValue = captureTile.second
        statusRow.addView(captureTile.first, weightedParams())
        val botTile = statusTile("BOT", "STOPPED")
        botValue = botTile.second
        statusRow.addView(botTile.first, weightedParams())
        statusCard.addView(statusRow)
        val stateLine = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(15), 0, dp(5))
        }
        stateLine.addView(TextView(this).apply {
            text = "GAME STATE"
            textSize = 10f
            letterSpacing = 0.08f
            setTextColor(Palette.MUTED)
        })
        stateValue = TextView(this).apply {
            text = "UNKNOWN"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Palette.AMBER)
            background = rounded(Palette.SURFACE_ALT, 8)
            setPadding(dp(10), dp(5), dp(10), dp(5))
        }
        stateLine.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        stateLine.addView(stateValue)
        statusCard.addView(stateLine)
        info = TextView(this).apply {
            textSize = 12f
            setTextColor(Palette.MUTED)
            setLineSpacing(dp(3).toFloat(), 1f)
        }
        statusCard.addView(info)

        // Gathering configuration
        val settingsCard = section(gatherPage, "GATHERING PLAN", "Choose march capacity and resource rotation")
        marchSlots = numberField(Config.maxMarches.toString(), "1–6 march slots")
        addField(settingsCard, "CONCURRENT MARCH SLOTS", marchSlots)
        settingsCard.addView(label("RESOURCES TO GATHER"))
        val resources = Config.resourceTabs.keys.toList()
        resources.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { resource ->
                val check = CheckBox(this).apply {
                    text = resource.replaceFirstChar { it.uppercase() }
                    textSize = 14f
                    setTextColor(Palette.TEXT)
                    buttonTintList = ColorStateList.valueOf(Palette.ACCENT)
                    isChecked = resource in Config.rotation
                    setPadding(0, dp(4), dp(8), dp(4))
                }
                resourceChecks[resource] = check
                row.addView(check, LinearLayout.LayoutParams(0, -2, 1f))
            }
            if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            settingsCard.addView(row)
        }
        rotationOrder = textField(Config.rotation.joinToString(","), "food,wood,food,stone,gold")
        addField(settingsCard, "PRIORITY / ROTATION", rotationOrder,
            "Comma-separated. Repeat a resource to give it more weight.")
        settingsCard.addView(note("Every enabled resource must appear at least once in the rotation."))

        // Timing and recognition
        val timingCard = section(gatherPage, "TIMING & RECOGNITION", "Tune detection and recovery behavior")
        thresholdInput = decimalField("${Config.threshold}", "0.70–0.95")
        cycleWaitInput = numberField((Config.cycleWaitMs / 60_000).toString(), "Minutes")
        retryWaitInput = numberField((Config.retryWaitMs / 60_000).toString(), "Minutes")
        maxRetryWaitInput = numberField((Config.maxRetryWaitMs / 60_000).toString(), "1–360 minutes")
        failedRoundsInput = numberField(Config.maxFailedRounds.toString(), "1–10 rounds")
        addField(timingCard, "DEFAULT MATCH CONFIDENCE", thresholdInput,
            "Per-button threshold overrides remain supported.")
        addField(timingCard, "WAIT AFTER CONFIRMED ROUND", cycleWaitInput)
        addField(timingCard, "INITIAL FAILED-ROUND RETRY", retryWaitInput)
        addField(timingCard, "MAXIMUM RETRY DELAY", maxRetryWaitInput)
        addField(timingCard, "STOP AFTER FAILED ROUNDS", failedRoundsInput)
        addWideButton(timingCard, "SAVE GATHERING SETTINGS", "primary") { saveSettings() }

        // Permissions / capture
        val captureCard = section(settingsPage, "PERMISSIONS & SCREEN CAPTURE", "Android access required for safe automation")
        addWideButton(captureCard, "ENABLE ACCESSIBILITY SERVICE", "secondary") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addWideButton(captureCard, "START / REQUEST SCREEN CAPTURE", "primary") {
            if (ScreenCapture.active) toast("Screen capture is already active")
            else {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), reqCapture)
            }
        }
        addWideButton(captureCard, "STOP SCREEN CAPTURE", "danger") {
            if (BotService.instance?.running == true) {
                toast("Stop the bot before stopping screen capture")
            } else {
                val wasActive = ScreenCapture.active
                val releaseConfirmed = if (wasActive) ScreenCapture.stop() else true
                stopService(Intent(this, CaptureService::class.java))
                val nowActive = ScreenCapture.active
                if (wasActive && releaseConfirmed && !nowActive) {
                    BotService.log("Screen capture stopped by user; MediaProjection release confirmed")
                    toast("Screen capture stopped")
                } else if (nowActive || (wasActive && !releaseConfirmed)) {
                    toast("Capture release is not confirmed; do not start another session")
                    BotService.log("Capture shutdown requested but MediaProjection release is not confirmed")
                } else toast("Screen capture is already off")
            }
        }

        // Template and diagnostics
        val diagnosticCard = section(recognitionPage, "TEMPLATES & DIAGNOSTICS", "Inspect recognition without sending game taps")
        addButtonRow(diagnosticCard,
            "CAPTURE SCREENSHOT · 6 S", "MANAGE TEMPLATES",
            { screenshotLater() },
            { startActivity(Intent(this, TemplateMakerActivity::class.java)) })
        addWideButton(diagnosticCard, "SHOW TEMPLATE INVENTORY", "secondary") { showTemplateInventory() }
        addWideButton(diagnosticCard, "RUN RECOGNITION TEST · 6 S · NO TAPS", "primary") {
            runWithGameForeground("recognition test") {
                Diagnostics.run(applicationContext, saveOverlay = false)
            }
        }
        addWideButton(diagnosticCard, "SAVE ANNOTATED SCREENSHOT · 6 S", "secondary") {
            runWithGameForeground("annotated diagnostic screenshot") {
                Diagnostics.run(applicationContext, saveOverlay = true)
            }
        }
        addButtonRow(diagnosticCard,
            "INSPECT ACCESSIBILITY NODES · 6 S", "CLEAR DIAGNOSTIC IMAGES",
            {
                runWithGameForeground("accessibility node inspection", requireCapture = false) {
                    BotService.instance?.inspectAccessibilityNodes(delayMs = 0L)
                        ?: BotService.log("Accessibility inspection aborted: service disconnected")
                }
            },
            {
                AlertDialog.Builder(this)
                    .setTitle("Clear diagnostic screenshots?")
                    .setMessage("Only PNG files in this app's diagnostics folder are deleted. Templates and settings are kept.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Clear") { _, _ ->
                        val result = Diagnostics.clear(this)
                        toast("Deleted ${result.first} screenshot(s)")
                    }.show()
            })
        diagnosticButton = makeButton(
            if (Config.diagnosticMode) "DIAGNOSTIC MODE  ·  ON" else "DIAGNOSTIC MODE  ·  OFF",
            if (Config.diagnosticMode) "success" else "secondary"
        ) {
            Config.diagnosticMode = !Config.diagnosticMode
            getSharedPreferences("rokbot_gather_settings", MODE_PRIVATE).edit()
                .putBoolean("diagnostic_mode", Config.diagnosticMode).apply()
            updateDiagnosticButton()
            toast("Diagnostic mode ${if (Config.diagnosticMode) "enabled" else "disabled"}")
        }
        diagnosticCard.addView(diagnosticButton, matchWidthParams())

        // RokGatherBot 3.0 modes and overlays
        val modeCard = section(page, "OPERATION MODE & OVERLAYS", "Choose how RokGatherBot 3.0 observes, assists, or performs supervised automation")
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val modeLabel = TextView(this).apply { text = "Mode: ${RuntimeState.mode.label}"; textSize = 13f; setTextColor(Palette.TEXT); typeface = Typeface.DEFAULT_BOLD }
        modeLabel.tag = "modeLabel"
        modeRow.addView(modeLabel, LinearLayout.LayoutParams(0,-2,1f))
        val modeBtn = makeButton("CHANGE MODE", "secondary") {
            val modes = OperationMode.values()
            val labels = modes.map { it.label }.toTypedArray()
            var sel = modes.indexOf(RuntimeState.mode).coerceAtLeast(0)
            AlertDialog.Builder(this).setTitle("Operating mode").setSingleChoiceItems(labels, sel) { _, which -> sel = which }
                .setPositiveButton("Apply") { _, _ ->
                    RuntimeState.mode = modes[sel]
                    BotService.operationMode = RuntimeState.mode
                    getSharedPreferences("rokbot_gather_settings", MODE_PRIVATE).edit().putString("operation_mode", RuntimeState.mode.name).apply()
                    modeLabel.text = "Mode: ${RuntimeState.mode.label}"
                    AppLog.add(LogCategory.SYSTEM, "Operation mode set to ${RuntimeState.mode.label}")
                    CompanionEngine.notify(1, "Mode changed", "Operating mode is now ${RuntimeState.mode.label}. ${if (RuntimeState.mode==OperationMode.OBSERVER) "No automated taps." else if (RuntimeState.mode==OperationMode.ASSISTANT) "Actions require approval." else "Supervised routines may run via Safe Action Controller."}")
                    EngineSupervisor.refreshHealth(); refreshDashboard()
                }.setNegativeButton("Cancel", null).show()
        }
        modeRow.addView(modeBtn)
        modeCard.addView(modeRow, matchWidthParams())
        addButtonRow(modeCard, "SHOW INTELLIGENCE MONITOR", "HIDE MONITOR",
            { requestOverlayThen { MonitorOverlayService.show(this) } }, { MonitorOverlayService.hide(this) })
        addButtonRow(modeCard, "SHOW COMPANION", "HIDE COMPANION",
            { requestOverlayThen { CompanionOverlayService.show(this) } }, { CompanionOverlayService.hide(this) })
        addWideButton(modeCard, "SYSTEM HEALTH & ENGINES", "secondary") {
            val s = StringBuilder()
            s.append("Mode: ${RuntimeState.mode.label}\n")
            s.append("Health: ${RuntimeState.systemHealth} — ${RuntimeState.systemHealthReason}\n")
            s.append("Bot runtime: ${IntelligenceMetrics.formatDuration(IntelligenceMetrics.currentBotRuntimeMs())}\n")
            s.append("Capture time: ${IntelligenceMetrics.formatDuration(IntelligenceMetrics.currentCaptureActiveMs())}\n")
            s.append("Learning-active: ${IntelligenceMetrics.formatDuration(IntelligenceMetrics.currentLearningActiveMs())}\n")
            s.append("Accuracy: ${IntelligenceMetrics.accuracyText()}\n\n")
            RuntimeState.engines().forEach { e -> s.append("• ${e.displayName}: ${e.health}\n  ${e.summary}\n") }
            AlertDialog.Builder(this).setTitle("RokGatherBot 3.0 Status").setMessage(s.toString()).setPositiveButton("OK", null).show()
        }

        // Automation controls
        val automationCard = section(page, "QUICK ACTIONS", "Start only after templates and screen state are verified. Observer mode never taps; Assistant requires approval; Supervised uses Safe Action Controller.")
        addWideButton(automationCard, "START BOT", "success") {
            if (saveSettings()) {
                val service = BotService.instance
                if (service == null) toast("Enable the accessibility service first")
                else if (service.start()) toast("Starting. Switch to Rise of Kingdoms in landscape within 6 seconds.")
                else toast("Cannot start. Check screen capture and templates in the status/log.")
            }
        }
        addButtonRow(automationCard, "STOP BOT", "RESET LIFETIME COUNTERS",
            { BotService.instance?.stop() },
            {
                AlertDialog.Builder(this)
                    .setTitle("Reset counters?")
                    .setMessage("This clears saved attempt, round and result counters. Gathering settings remain unchanged.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Reset") { _, _ ->
                        BotMetrics.reset(this)
                        refreshDashboard()
                        toast("Counters reset")
                    }.show()
            }, dangerFirst = true)

        // Chronological input/output console
        val logCard = section(activityPage, "ACTIVITY LOG", "User actions, recognition results, gestures and service events")
        val logHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        logMeta = TextView(this).apply {
            text = "LIVE EVENT STREAM"
            textSize = 10f
            letterSpacing = 0.08f
            setTextColor(Palette.GREEN)
            typeface = Typeface.DEFAULT_BOLD
        }
        logHeader.addView(logMeta)
        logHeader.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val copyButton = TextView(this).apply {
            text = "COPY LOG"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Palette.ACCENT)
            setPadding(dp(10), dp(6), dp(2), dp(6))
            setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("RoK Gather Bot log", BotService.recentLog()))
                toast("Activity log copied")
                BotService.log("UI INPUT: copied activity log")
            }
        }
        logHeader.addView(copyButton)
        logCard.addView(logHeader)
        logScroll = ScrollView(this).apply {
            isFillViewport = false
            isSmoothScrollingEnabled = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            // Keep this nested console independently scrollable inside the dashboard.
            isNestedScrollingEnabled = true
            setOnTouchListener { view, event ->
                val consoleCanScroll = canScrollVertically(-1) || canScrollVertically(1)
                view.parent?.requestDisallowInterceptTouchEvent(
                    event.actionMasked != android.view.MotionEvent.ACTION_UP &&
                        event.actionMasked != android.view.MotionEvent.ACTION_CANCEL && consoleCanScroll
                )
                false // Let ScrollView handle the gesture normally.
            }
            background = rounded(Palette.FIELD, 12, Palette.BORDER)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        logView = TextView(this).apply {
            text = "No events yet. Start with a recognition test to populate the log."
            textSize = 11.5f
            typeface = Typeface.create("monospace", Typeface.NORMAL)
            setTextColor(Palette.MUTED)
            setLineSpacing(dp(3).toFloat(), 1f)
            setTextIsSelectable(true)
        }
        logScroll.addView(logView)
        logCard.addView(logScroll, LinearLayout.LayoutParams(-1, dp(280)))
        logCard.addView(note("Logs stay on this device. Use COPY LOG to share them manually when requesting help."))

        // The learning panel uses labelled examples only. Unreviewed scores do not tune the bot.
        val learningCard = section(recognitionPage, "ADAPTIVE INTELLIGENCE", "The engine learns only from examples you confirm")
        learningSwitch = Switch(this).apply {
            text = "Collect local learning feedback"
            textSize = 14f
            setTextColor(Palette.TEXT)
            buttonTintList = ColorStateList.valueOf(Palette.ACCENT)
            isChecked = AdaptiveLearning.enabled
            setOnCheckedChangeListener { _, checked ->
                AdaptiveLearning.enabled = checked
                getSharedPreferences("rokbot_gather_settings", MODE_PRIVATE).edit()
                    .putBoolean("adaptive_learning_enabled", checked).apply()
                BotService.log("UI INPUT: adaptive learning ${if (checked) "enabled" else "disabled"}")
                refreshLearningSummary()
            }
        }
        learningCard.addView(learningSwitch)
        learningSummary = note(AdaptiveLearning.summary(Templates.folder()))
        learningCard.addView(learningSummary)
        addWideButton(learningCard, "REVIEW & TEACH RECOGNITION", "primary") { showLearningReview() }
        addWideButton(learningCard, "RESET LEARNING MEMORY", "danger") {
            AlertDialog.Builder(this)
                .setTitle("Reset adaptive learning memory?")
                .setMessage("This deletes only the locally stored recognition feedback and calibration examples. Your original templates, ROIs and gathering settings are preserved.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Reset memory") { _, _ ->
                    AdaptiveLearning.reset(Templates.folder())
                    refreshLearningSummary()
                    toast("Learning memory cleared")
                }.show()
        }

        // Floating-style bottom navigation inspired by your reference screenshots.
        val navOuter = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(9), dp(7), dp(9), dp(7))
            background = rounded(Palette.SURFACE, 28, Palette.BORDER)
            elevation = dp(5).toFloat()
        }
        val navEntries = listOf(
            Triple("HOME", "⌂", "Home"), Triple("GATHER", "◈", "Gather"),
            Triple("RECOGNITION", "◎", "Vision"), Triple("ACTIVITY", "▤", "Activity"),
            Triple("SETTINGS", "⚙", "Settings")
        )
        val navViews = linkedMapOf<String, LinearLayout>()
        fun selectTab(name: String) {
            tabPages.forEach { (key, view) -> view.visibility = if (key == name) View.VISIBLE else View.GONE }
            navViews.forEach { (key, view) ->
                val selected = key == name
                view.background = rounded(if (selected) Palette.ACCENT_DARK else Color.TRANSPARENT, 20)
                val icon = view.getChildAt(0) as TextView
                val label = view.getChildAt(1) as TextView
                icon.setTextColor(if (selected) Palette.ACCENT else Palette.MUTED)
                label.setTextColor(if (selected) Palette.ACCENT else Palette.MUTED)
            }
            BotService.log("UI NAVIGATION: $name")
        }
        navEntries.forEach { (key, symbol, title) ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(6), dp(3), dp(5))
                isClickable = true
                isFocusable = true
                setOnClickListener { selectTab(key) }
            }
            item.addView(TextView(this).apply {
                text = symbol
                textSize = 21f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Palette.MUTED)
            })
            item.addView(TextView(this).apply {
                text = title
                textSize = 9f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Palette.MUTED)
            })
            navViews[key] = item
            navOuter.addView(item, LinearLayout.LayoutParams(0, dp(53), 1f))
        }
        root.addView(navOuter, LinearLayout.LayoutParams(-1, -2).apply {
            leftMargin = dp(18); rightMargin = dp(18); topMargin = dp(5); bottomMargin = dp(9)
        })

        setContentView(root)
        selectTab("HOME")
        refreshDashboard()
    }

    private fun refreshDashboard() {
        if (!::info.isInitialized) return
        val required = Config.requiredTemplates
        val have = required.count { Templates.has(it) }
        val missing = required.filterNot { Templates.has(it) }
        val capture = ScreenCapture.displayInfo(this)
        val orientation = capture?.orientation ?: "UNKNOWN"
        val frame = capture?.let { "${it.frameWidth}×${it.frameHeight}" } ?: "not ready"
        val display = capture?.let { "${it.displayWidth}×${it.displayHeight}" } ?: "unknown"
        val service = BotService.instance
        val accessOn = service?.connected == true
        val captureOn = ScreenCapture.active
        val botOn = service?.running == true
        setStatusTile(accessValue, if (accessOn) "CONNECTED" else "OFFLINE", if (accessOn) Palette.GREEN else Palette.RED)
        setStatusTile(captureValue, if (captureOn) "ACTIVE" else "OFF", if (captureOn) Palette.GREEN else Palette.AMBER)
        setStatusTile(botValue, if (botOn) "RUNNING" else "STOPPED", if (botOn) Palette.GREEN else Palette.MUTED)
        stateValue.text = BotService.lastState.toString().replace('_', ' ')
        stateValue.setTextColor(if (BotService.lastState == GameState.UNKNOWN) Palette.AMBER else Palette.ACCENT)
        val confidence = if (BotService.lastConfidence < 0) "accessibility" else "%.3f".format(BotService.lastConfidence)
        info.text = "Orientation  $orientation     Capture  $frame\n" +
            "Display  $display\n" +
            "Templates  $have/${required.size} ready     Missing  ${missing.size}\n" +
            (if (missing.isEmpty()) "" else "Missing: ${missing.joinToString()}\n") +
            "Last button  ${BotService.lastDetectedButton}  ·  confidence  $confidence\n" +
            "Last tap  ${BotService.lastTapResult}\n" +
            "Last transition  ${BotService.lastTransition}\n" +
            "Rotation  ${Config.rotation.joinToString(" → ")}\n" +
            "March slots  ${Config.maxMarches}  ·  step  ${BotService.status}\n" +
            "Diagnostics  ${if (Config.diagnosticMode) "ON" else "OFF"}\n" +
            "Lighting profile  ${BotService.lastEnvironmentProfile}\n" +
            BotMetrics.summary(this)

        refreshActivityLog()
        refreshLearningSummary()
    }

    /**
     * Refresh the console without stealing the reader's scroll position.
     * Auto-follow is enabled only when the user was already at the true bottom
     * before new log content arrived. Re-rendering an unchanged log is avoided.
     */
    private fun refreshActivityLog() {
        if (!::logScroll.isInitialized || !::logView.isInitialized) return
        val lines = BotService.recentLog().lineSequence().toList().takeLast(160)
        val snapshot = lines.joinToString("\n")
        logMeta.text = "LIVE EVENT STREAM  ·  ${lines.size} ENTRIES"
        if (snapshot == lastRenderedLogSnapshot) return

        val child = logScroll.getChildAt(0)
        val oldScrollY = logScroll.scrollY
        val oldMaxScroll = child?.let {
            (it.bottom + logScroll.paddingBottom - logScroll.height).coerceAtLeast(0)
        } ?: 0
        // A 4dp tolerance avoids treating a deliberate scroll-up as "at bottom".
        val wasAtBottom = oldMaxScroll - oldScrollY <= dp(4)

        logView.text = styleLog(lines)
        lastRenderedLogSnapshot = snapshot

        logScroll.post {
            val updatedChild = logScroll.getChildAt(0) ?: return@post
            val newMaxScroll = (updatedChild.bottom + logScroll.paddingBottom - logScroll.height)
                .coerceAtLeast(0)
            val targetY = if (wasAtBottom) newMaxScroll else oldScrollY.coerceIn(0, newMaxScroll)
            logScroll.scrollTo(0, targetY)
        }
    }

    private fun styleLog(lines: List<String>): CharSequence {
        val out = SpannableStringBuilder()
        lines.forEachIndexed { index, line ->
            val start = out.length
            out.append(line)
            val end = out.length
            val body = line.substringAfter("] ", line)
            val color = when {
                body.startsWith("UI INPUT:") -> Palette.ACCENT
                listOf("ERROR", "FAILED", "failure", "CANCELLED", "ABORT", "MISSING", "REJECTED", "not confirmed").any { body.contains(it, true) } -> Palette.RED
                listOf("FOUND", "ACCEPTED", "completed", "confirmed", "saved", "connected", "started", "STOPPED").any { body.contains(it, true) } -> Palette.GREEN
                else -> Palette.TEXT
            }
            val stampEnd = line.indexOf("] ").let { if (it >= 0) it + 1 else 0 }
            if (stampEnd > 0) out.setSpan(ForegroundColorSpan(Palette.MUTED), start, start + stampEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (end > start) out.setSpan(ForegroundColorSpan(color), start + stampEnd, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (index != lines.lastIndex) out.append('\n')
        }
        return out
    }

    private fun updateDiagnosticButton() {
        diagnosticButton.text = if (Config.diagnosticMode) "DIAGNOSTIC MODE  ·  ON" else "DIAGNOSTIC MODE  ·  OFF"
        diagnosticButton.background = rounded(if (Config.diagnosticMode) 0xFF123D35.toInt() else Palette.SURFACE_ALT, 12,
            if (Config.diagnosticMode) 0xFF246B58.toInt() else Palette.BORDER)
        diagnosticButton.setTextColor(if (Config.diagnosticMode) Palette.GREEN else Palette.TEXT)
    }

    private fun statusTile(title: String, initial: String): Pair<View, TextView> {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Palette.SURFACE_ALT, 10)
            setPadding(dp(10), dp(10), dp(8), dp(10))
        }
        tile.addView(TextView(this).apply {
            text = title
            textSize = 9f
            letterSpacing = 0.04f
            setTextColor(Palette.MUTED)
            typeface = Typeface.DEFAULT_BOLD
        })
        val value = TextView(this).apply {
            text = initial
            textSize = 12f
            setTextColor(Palette.AMBER)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(5), 0, 0)
        }
        tile.addView(value)
        return tile to value
    }

    private fun setStatusTile(view: TextView, value: String, color: Int) {
        view.text = value
        view.setTextColor(color)
    }

    private fun section(parent: LinearLayout, title: String, subtitle: String): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Palette.SURFACE, 22)
            setPadding(dp(17), dp(16), dp(17), dp(17))
            elevation = dp(1).toFloat()
        }
        val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
        parent.addView(card, params)
        card.addView(TextView(this).apply {
            text = title
            textSize = 12f
            letterSpacing = 0.10f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setTextColor(Palette.MUTED)
        })
        card.addView(TextView(this).apply {
            text = subtitle
            textSize = 12f
            setTextColor(Palette.MUTED)
            setPadding(0, dp(4), 0, dp(13))
        })
        return card
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 10f
        letterSpacing = 0.06f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Palette.MUTED)
        setPadding(0, dp(12), 0, dp(5))
    }

    private fun note(text: String) = TextView(this).apply {
        this.text = text
        textSize = 11f
        setTextColor(Palette.MUTED)
        setLineSpacing(dp(2).toFloat(), 1f)
        setPadding(0, dp(6), 0, dp(4))
    }

    private fun addField(parent: LinearLayout, title: String, field: EditText, hint: String? = null) {
        parent.addView(label(title))
        parent.addView(field, matchWidthParams())
        if (hint != null) parent.addView(note(hint))
    }

    private fun makeButton(text: String, kind: String = "secondary", action: () -> Unit): Button {
        val (backgroundColor, stroke, foreground) = when (kind) {
            "primary" -> Triple(Palette.ACCENT_DARK, 0xFF365F91.toInt(), Palette.ACCENT)
            "success" -> Triple(0xFF124535.toInt(), 0xFF28765B.toInt(), 0xFFBFF5DF.toInt())
            "danger" -> Triple(0xFF4B2630.toInt(), 0xFF87404D.toInt(), 0xFFFFD9DD.toInt())
            else -> Triple(Palette.SURFACE_ALT, Palette.BORDER, Palette.TEXT)
        }
        return Button(this).apply {
            this.text = text
            textSize = 11f
            letterSpacing = 0.035f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setTextColor(foreground)
            isAllCaps = false
            minHeight = dp(50)
            setPadding(dp(12), dp(9), dp(12), dp(9))
            background = rounded(backgroundColor, 16, stroke)
            stateListAnimator = null
            elevation = dp(1).toFloat()
            setOnClickListener {
                BotService.log("UI INPUT: $text")
                action()
            }
        }
    }

    private fun addWideButton(parent: LinearLayout, text: String, kind: String = "secondary", action: () -> Unit) {
        parent.addView(makeButton(text, kind, action), LinearLayout.LayoutParams(-1, dp(48)).apply {
            topMargin = dp(5)
        })
    }

    private fun addButtonRow(
        parent: LinearLayout, left: String, right: String,
        leftAction: () -> Unit, rightAction: () -> Unit, dangerFirst: Boolean = false,
    ) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val a = makeButton(left, if (dangerFirst) "danger" else "secondary", leftAction)
        val b = makeButton(right, "secondary", rightAction)
        row.addView(a, LinearLayout.LayoutParams(0, dp(52), 1f).apply { rightMargin = dp(5); topMargin = dp(5) })
        row.addView(b, LinearLayout.LayoutParams(0, dp(52), 1f).apply { leftMargin = dp(5); topMargin = dp(5) })
        parent.addView(row)
    }

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeColor != null) setStroke(dp(1), strokeColor)
        }

    private fun weightedParams() = LinearLayout.LayoutParams(0, -2, 1f).apply {
        marginEnd = dp(5)
    }
    private fun matchWidthParams() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun numberField(value: String, hintText: String) = styledField(value, hintText,
        InputType.TYPE_CLASS_NUMBER)
    private fun decimalField(value: String, hintText: String) = styledField(value, hintText,
        InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
    private fun textField(value: String, hintText: String) = styledField(value, hintText,
        InputType.TYPE_CLASS_TEXT)

    private fun styledField(value: String, hintText: String, type: Int) = EditText(this).apply {
        setText(value)
        hint = hintText
        inputType = type
        maxLines = 1
        textSize = 14f
        setTextColor(Palette.TEXT)
        setHintTextColor(0xFF70839A.toInt())
        background = rounded(Palette.FIELD, 14, Palette.BORDER)
        setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    private fun showTemplateInventory() {
        val entries = Templates.inventory(Config.expectedTemplates)
        val lines = entries.map { entry ->
            if (entry.id == "UNMAPPED FILES") {
                "UNMAPPED FILES\n" + entry.variants.joinToString("\n") { "  ${it.path}: ${it.error}" }
            } else {
                val status = when {
                    entry.missing -> "MISSING"
                    entry.variants.any { it.duplicateOf != null } -> "DUPLICATE VARIANT"
                    else -> "${entry.variantCount} decodable variant(s)"
                }
                "$status  ${entry.id}\nROI: ${RoiConfig.description(entry.id)}\n" + entry.variants.joinToString("\n") {
                    "  ${it.path}: ${if (it.decodable) "${it.width}x${it.height}" else it.error}" +
                        (it.duplicateOf?.let { prior -> " (duplicate of $prior)" } ?: "")
                }
            }
        }
        val text = if (lines.isEmpty()) "No template identifiers configured" else lines.joinToString("\n\n")
        AlertDialog.Builder(this).setTitle("Template inventory")
            .setMessage(text).setPositiveButton("OK", null).show()
    }

    private fun refreshLearningSummary() {
        if (::learningSummary.isInitialized) {
            learningSummary.text = AdaptiveLearning.summary(Templates.folder())
        }
    }

    private fun showLearningReview() {
        val pending = AdaptiveLearning.pending(Templates.folder(), 50)
        if (pending.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("No learning examples to review")
                .setMessage("Run a recognition test first. The app will save local observations, then you can mark each candidate as correct or incorrect. Unreviewed observations never change recognition thresholds.")
                .setPositiveButton("OK", null)
                .show()
            return
        }
        val labels = pending.map { sample ->
            val verdict = if (sample.accepted) "ACCEPTED" else "REJECTED"
            val score = if (sample.score < 0) "no candidate" else "score ${"%.3f".format(sample.score)}"
            "${sample.templateId}  ·  ${sample.environment}\n$verdict  ·  $score"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Review recognition examples (${pending.size})")
            .setItems(labels) { _, index ->
                val sample = pending[index]
                val question = if (sample.hasCandidate) {
                    "Was the highlighted detection box actually around the '${sample.templateId}' target?"
                } else {
                    "Was '${sample.templateId}' visibly present on the game screen even though the matcher found no candidate?"
                }
                val details = "Environment: ${sample.environment}\n" +
                    "Score: ${if (sample.score < 0) "No candidate" else "%.3f".format(sample.score)}\n" +
                    "Threshold: ${"%.3f".format(sample.baseThreshold)}\n" +
                    (if (sample.hasCandidate) "Candidate centre: ${sample.x}, ${sample.y}" else "No candidate coordinates") +
                    "\n\nCheck the matching annotated screenshot before choosing a label."
                AlertDialog.Builder(this)
                    .setTitle("Teach the recognition engine")
                    .setMessage("$question\n\n$details\n\nYour answer is stored only on this device.")
                    .setPositiveButton(if (sample.hasCandidate) "Correct match" else "Target was present") { _, _ ->
                        AdaptiveLearning.label(Templates.folder(), sample.timestamp, true)
                        refreshLearningSummary()
                        toast("Example confirmed")
                    }
                    .setNegativeButton(if (sample.hasCandidate) "Wrong match" else "Target was absent") { _, _ ->
                        AdaptiveLearning.label(Templates.folder(), sample.timestamp, false)
                        refreshLearningSummary()
                        toast("Feedback saved")
                    }
                    .setNeutralButton("Not sure", null)
                    .show()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun saveSettings(): Boolean {
        val maxMarches = marchSlots.text.toString().toIntOrNull()
        val threshold = thresholdInput.text.toString().toDoubleOrNull()
        val cycleMinutes = cycleWaitInput.text.toString().toLongOrNull()
        val retryMinutes = retryWaitInput.text.toString().toLongOrNull()
        val maxRetryMinutes = maxRetryWaitInput.text.toString().toLongOrNull()
        val maxFailed = failedRoundsInput.text.toString().toIntOrNull()
        if (maxMarches == null || maxMarches !in 1..6) return invalid("March slots must be between 1 and 6")
        if (threshold == null || !threshold.isFinite() || threshold !in 0.70..0.95) return invalid("Threshold must be between 0.70 and 0.95")
        if (cycleMinutes == null || cycleMinutes !in 1L..720L) return invalid("Cycle wait must be between 1 and 720 minutes")
        if (retryMinutes == null || retryMinutes !in 1L..60L) return invalid("Initial retry wait must be between 1 and 60 minutes")
        if (maxRetryMinutes == null || maxRetryMinutes !in retryMinutes..360L) return invalid("Maximum retry wait must be at least the initial delay and no more than 360 minutes")
        if (maxFailed == null || maxFailed !in 1..10) return invalid("Stop-after-failures must be between 1 and 10")

        val enabled = resourceChecks.filterValues { it.isChecked }.keys
        if (enabled.isEmpty()) return invalid("Enable at least one resource")
        val sequence = rotationOrder.text.toString().split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        if (sequence.isEmpty() || sequence.size > Config.maxRotationEntries) return invalid("Rotation must contain 1–${Config.maxRotationEntries} entries")
        if (sequence.any { it !in enabled || it !in Config.resourceTabs.keys }) return invalid("Rotation may only contain enabled resources: ${enabled.joinToString()}")
        if (!sequence.toSet().containsAll(enabled)) return invalid("Every enabled resource must appear in the rotation order")

        BotSettings.save(this, sequence, maxMarches, threshold, cycleMinutes, retryMinutes, maxRetryMinutes, maxFailed)
        toast("Gathering settings saved")
        refreshDashboard()
        return true
    }

    private fun invalid(message: String): Boolean { toast(message); BotService.log("Settings rejected: $message"); return false }

    /**
     * Bring Rise of Kingdoms to the foreground before any screenshot-based test.
     * Accessibility root-package verification prevents accidentally analysing this app's UI.
     */
    private fun runWithGameForeground(
        taskName: String,
        requireCapture: Boolean = true,
        action: suspend () -> Unit,
    ) {
        if (BotService.instance?.running == true) {
            toast("Stop the bot before running a screenshot test")
            BotService.log("$taskName aborted: bot automation is active; no test screenshot taken")
            return
        }
        if (requireCapture && !ScreenCapture.active) {
            toast("Start screen capture first")
            BotService.log("$taskName aborted: screen capture is off")
            return
        }
        if (BotService.instance == null) {
            toast("Enable the RokGatherBot accessibility service first")
            BotService.log("$taskName aborted: accessibility service is unavailable; cannot verify foreground game")
            return
        }
        val launchIntent = try {
            packageManager.getLaunchIntentForPackage(Config.gamePackage)
        } catch (e: Exception) {
            BotService.log("$taskName: cannot query Rise of Kingdoms launch intent: ${e.message}")
            null
        }
        if (launchIntent == null) {
            toast("Rise of Kingdoms was not found. Install or update the game first.")
            BotService.log("$taskName aborted: no launchable app for package ${Config.gamePackage}")
            return
        }
        try {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
            BotService.log("$taskName: launch requested for ${Config.gamePackage}")
        } catch (e: Exception) {
            toast("Could not open Rise of Kingdoms")
            BotService.log("$taskName aborted: game launch failed: ${e.message}")
            return
        }

        toast("Opening Rise of Kingdoms…")
        scope.launch {
            val deadline = SystemClock.elapsedRealtime() + 15_000L
            var foreground = false
            while (SystemClock.elapsedRealtime() < deadline) {
                foreground = withContext(Dispatchers.Main) {
                    BotService.instance?.isGameForeground() == true
                }
                if (foreground) break
                delay(300L)
            }
            if (!foreground) {
                BotService.log("$taskName aborted: Rise of Kingdoms did not become the verified foreground app within 15 seconds; no screenshot taken")
                ui.post { if (!isFinishing) toast("Rise of Kingdoms did not open. No screenshot was taken.") }
                return@launch
            }

            BotService.log("$taskName: foreground verified (${Config.gamePackage}); starting 6-second capture countdown")
            ui.post { if (!isFinishing) toast("Rise of Kingdoms is ready. Capturing in 6 seconds…") }
            delay(6000L)
            if (requireCapture && !ScreenCapture.active) {
                BotService.log("$taskName aborted: screen capture stopped during countdown")
                ui.post { if (!isFinishing) toast("Screen capture stopped. Please start it again.") }
                return@launch
            }
            // Recheck immediately before processing, so a return to this app never gets captured.
            val stillForeground = withContext(Dispatchers.Main) {
                BotService.instance?.isGameForeground() == true
            }
            if (!stillForeground) {
                BotService.log("$taskName aborted: game left foreground before capture; no screenshot taken")
                ui.post { if (!isFinishing) toast("Game is no longer in front. Test cancelled safely.") }
                return@launch
            }
            action()
        }
    }

    private fun screenshotLater() {
        runWithGameForeground("game screenshot capture") {
            val bitmap = ScreenCapture.grabBitmap(applicationContext)
            if (bitmap == null) {
                BotService.log("Screenshot failed: no frame")
                ui.post { if (!isFinishing) toast("Screenshot failed: no game frame") }
                return@runWithGameForeground
            }
            try {
                FileOutputStream(Templates.screenshotFile()).use {
                    if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) error("PNG encoder returned false")
                }
                BotService.log("Screenshot saved (${bitmap.width}x${bitmap.height})")
                ui.post { if (!isFinishing) toast("Game screenshot saved. Open template management.") }
            } catch (e: Exception) {
                BotService.log("Screenshot save failed: ${e.message}")
                ui.post { if (!isFinishing) toast("Screenshot save failed") }
            } finally {
                bitmap.recycle()
            }
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode).putExtra("data", data))
        } else if (requestCode == reqCapture) {
            toast("Screen capture was not allowed")
            BotService.log("Screen capture permission denied")
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()


    private fun requestOverlayThen(action: () -> Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            AppLog.add(LogCategory.SYSTEM, "Overlay permission not granted; opening settings")
            AlertDialog.Builder(this)
                .setTitle("Overlay permission required")
                .setMessage("RokGatherBot 3.0 needs 'Display over other apps' permission to show the Intelligence Monitor and Companion while you play. Grant permission, then try again.")
                .setPositiveButton("Open Settings") { _, _ ->
                    try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } catch (e: Exception) { toast("Cannot open overlay settings: ${e.message}") }
                }.setNegativeButton("Cancel", null).show()
            return
        }
        action()
    }

    override fun onResume() { super.onResume(); ui.removeCallbacks(tick); ui.post(tick) }
    override fun onPause() { ui.removeCallbacks(tick); super.onPause() }

    override fun onDestroy() {
        ui.removeCallbacks(tick)
        scope.cancel()
        super.onDestroy()
    }
}
