package com.example.rokbot

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

class MonitorOverlayService : Service() {
    companion object {
        @Volatile var running = false
        fun hasPermission(ctx: Context): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(ctx) else true
        fun show(ctx: Context) {
            if (!hasPermission(ctx)) { AppLog.add(LogCategory.SYSTEM, "Overlay permission missing for Intelligence Monitor"); return }
            ctx.startService(Intent(ctx, MonitorOverlayService::class.java))
        }
        fun hide(ctx: Context) { ctx.stopService(Intent(ctx, MonitorOverlayService::class.java)) }
    }

    private lateinit var wm: WindowManager
    private var root: View? = null
    private var compact: LinearLayout? = null
    private var expanded: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private val ui = Handler(Looper.getMainLooper())
    private var minimized = false
    private var expandedMode = false
    private var lastDownX = 0f; private var lastDownY = 0f; private var lastRawX = 0f; private var lastRawY = 0f; private var dragging = false

    private val tick = object : Runnable {
        override fun run() { if (running) { refresh(); ui.postDelayed(this, 1000) } }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        running = true
        buildUi()
        ui.post(tick)
        AppLog.add(LogCategory.SYSTEM, "Intelligence Monitor overlay shown")
        EngineSupervisor.refreshHealth()
    }

    override fun onDestroy() {
        running = false
        ui.removeCallbacks(tick)
        try { root?.let { wm.removeView(it) } } catch (_: Exception) {}
        root = null
        AppLog.add(LogCategory.SYSTEM, "Intelligence Monitor overlay hidden")
        super.onDestroy()
    }

    private fun overlayType(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun buildUi() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(0xEE101820.toInt(), 18)
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text = "Intelligence Monitor"; setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.DEFAULT_BOLD }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        fun smallBtn(t: String, onClick: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(0xFFA8C7FF.toInt()); textSize = 12f; setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener { onClick() }
        }
        header.addView(smallBtn(if (expandedMode) "−" else "+") {
            expandedMode = !expandedMode
            compact?.visibility = if (expandedMode || minimized) View.GONE else View.VISIBLE
            expanded?.visibility = if (expandedMode && !minimized) View.VISIBLE else View.GONE
            refresh()
        })
        header.addView(smallBtn("_") {
            minimized = !minimized
            compact?.visibility = if (minimized || expandedMode) View.GONE else View.VISIBLE
            expanded?.visibility = if (minimized || !expandedMode) View.GONE else View.VISIBLE
            refresh()
        })
        header.addView(smallBtn("×") { stopSelf() })
        container.addView(header)

        compact = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        expanded = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        container.addView(compact)
        container.addView(expanded)

        container.setOnTouchListener { v, ev -> handleDrag(v, ev) }
        root = container
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(80) }
        wm.addView(container, params)
        refresh()
    }

    private fun handleDrag(v: View, ev: MotionEvent): Boolean {
        val p = params ?: return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dragging = false; lastDownX = ev.x; lastDownY = ev.y; lastRawX = ev.rawX; lastRawY = ev.rawY; return true }
            MotionEvent.ACTION_MOVE -> {
                val dx = ev.rawX - lastRawX; val dy = ev.rawY - lastRawY
                if (!dragging && (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(6))) dragging = true
                if (dragging) { p.x = max(0, (p.x + dx).toInt()); p.y = max(0, (p.y + dy).toInt()); lastRawX = ev.rawX; lastRawY = ev.rawY; try { wm.updateViewLayout(root, p) } catch (_: Exception) {} }
                return true
            }
            MotionEvent.ACTION_UP -> { if (!dragging) v.performClick(); dragging = false; return true }
        }
        return false
    }

    private fun refresh() {
        val c = compact ?: return
        val e = expanded ?: return
        if (minimized) { c.visibility = View.GONE; e.visibility = View.GONE; return }
        c.visibility = if (expandedMode) View.GONE else View.VISIBLE
        e.visibility = if (expandedMode) View.VISIBLE else View.GONE

        if (!expandedMode) {
            c.removeAllViews()
            c.addView(line("Mode: ${RuntimeState.mode.label} · Bot: ${if (BotService.instance?.running == true) "running" else "idle"}"))
            c.addView(line("Capture: ${if (RuntimeState.captureActive) "active" else "inactive"} · Recog: ${RuntimeState.recognitionStatus}"))
            c.addView(line("State: ${RuntimeState.currentGameState} · Learning: ${IntelligenceMetrics.formatDuration(IntelligenceMetrics.currentLearningActiveMs())}"))
            c.addView(line("Accuracy: ${IntelligenceMetrics.accuracyText()}"))
            c.addView(line("Health: ${RuntimeState.systemHealth}"))
            c.addView(line("Runtime: ${IntelligenceMetrics.formatDuration(IntelligenceMetrics.currentBotRuntimeMs())}"))
        } else {
            e.removeAllViews()
            addSection(e, "System", listOf(
                "Mode: ${RuntimeState.mode.label}",
                "Bot: ${if (BotService.instance?.running == true) "running" else "idle"} (${BotService.status})",
                "Capture: ${if (RuntimeState.captureActive) "active" else "inactive"} · permission missing: ${RuntimeState.capturePermissionMissing}",
                "Game state: ${RuntimeState.currentGameState}",
                "System health: ${RuntimeState.systemHealth} — ${RuntimeState.systemHealthReason}"
            ))
            addSection(e, "Time & Learning (verified)", listOf(
                "Total bot runtime: ${IntelligenceMetrics.formatDuration(IntelligenceMetrics.currentBotRuntimeMs())}",
                "Capture-active time: ${IntelligenceMetrics.formatDuration(IntelligenceMetrics.currentCaptureActiveMs())}",
                "Actual learning-active time: ${IntelligenceMetrics.formatDuration(IntelligenceMetrics.currentLearningActiveMs())} (wall-clock, not summed across parallel engines)",
                "Verified recognition accuracy: ${IntelligenceMetrics.accuracyText()}",
                "Insufficient validation examples remain reported as unavailable; raw confidence is not accuracy."
            ))
            addSection(e, "Recognition statistics", listOf(
                "Verified correct: ${IntelligenceMetrics.verifiedCorrect}",
                "Incorrect: ${IntelligenceMetrics.incorrectDetections}",
                "Rejected: ${IntelligenceMetrics.rejectedDetections}",
                "Ambiguous: ${IntelligenceMetrics.ambiguousDetections}",
                "Total evaluated observations: ${IntelligenceMetrics.totalEvaluatedExamples}",
                "Successful actions: ${IntelligenceMetrics.successfulGameActions} · Failed: ${IntelligenceMetrics.failedGameActions} · Confirmed gatherings: ${IntelligenceMetrics.confirmedGatheringOutcomes}"
            ))
            val cats = IntelligenceMetrics.categorySnapshot().entries.take(8).joinToString("\n") { (k,v) -> "$k: ok=${v.correct} bad=${v.incorrect} rej=${v.rejected} amb=${v.ambiguous} (n=${v.evaluated})" }
            addSection(e, "Performance by category", if (cats.isBlank()) listOf("No category data yet.") else cats.lines())
            val hist = IntelligenceMetrics.historySnapshot().takeLast(12)
            val graph: List<String> = if (hist.isEmpty()) listOf("No verified accuracy history yet.") else hist.map { p ->
                val a = p.accuracy?.let { "%.1f%%".format(it*100) } ?: "n/a"
                val bar = p.accuracy?.let { ac -> "█".repeat((ac*10).toInt().coerceIn(0,10)) + "░".repeat((10-(ac*10).toInt()).coerceIn(0,10)) } ?: "░░░░░░░░░░"
                "${SimpleDateFormat("HH:mm", Locale.US).format(Date(p.timeMs))} $bar $a (n=${p.evaluated})"
            }
            addSection(e, "Intelligence development (verified accuracy over time)", graph)
            val templates = try {
                val ids = (Config.requiredTemplates + listOf("popup_no_free_march","popup_not_found","popup_no_troops","btn_close")).distinct()
                Templates.inventory(ids).filter { it.expected }.take(10).map { t -> "${t.id}: variants=${t.variantCount} ${if (t.missing) "[MISSING]" else "[ok]"}" }
            } catch (_: Exception) { listOf("Template audit unavailable") }
            addSection(e, "Template performance / inventory", templates)
            val engines = RuntimeState.engines().take(13).map { s -> "${s.displayName}: ${s.health} — ${s.summary}" }
            addSection(e, "13 Engine status", if (engines.isEmpty()) listOf("Supervisor not initialized") else engines)
            val events = AppLog.tail(12).map { le -> "${SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(le.timeMs))} [${le.category}] ${le.message}" }
            addSection(e, "Recent events", if (events.isEmpty()) listOf("No events yet.") else events)
        }
    }

    private fun addSection(parent: LinearLayout, title: String, lines: List<String>) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(0xFF18222D.toInt(), 12); setPadding(dp(8), dp(6), dp(8), dp(6)); val lp = LinearLayout.LayoutParams(-1,-2); lp.topMargin = dp(6); layoutParams = lp }
        card.addView(TextView(this).apply { text = title; setTextColor(0xFFA8C7FF.toInt()); textSize = 11f; typeface = Typeface.DEFAULT_BOLD })
        lines.forEach { card.addView(TextView(this).apply { text = it; setTextColor(0xFFE3E7EE.toInt()); textSize = 10f }) }
        parent.addView(card)
    }

    private fun line(t: String) = TextView(this).apply { text = t; setTextColor(0xFFE3E7EE.toInt()); textSize = 10f }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
}
