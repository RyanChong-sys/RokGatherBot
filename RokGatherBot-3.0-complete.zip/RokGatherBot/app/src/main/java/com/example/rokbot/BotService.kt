package com.example.rokbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.*
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

private enum class Outcome { OK, ABORT, NO_MARCHES }
private enum class GestureResult { COMPLETED, CANCELLED, REJECTED, TIMEOUT, DISCONNECTED }
private data class StepResult(
    val outcome: Outcome,
    val match: TemplateMatcher.Match? = null,
    val state: GameState = GameState.UNKNOWN,
)
private data class RoiLookup(val pixels: IntArray?, val description: String, val error: String? = null)

/**
 * Accessibility-driven workflow. A detection, a dispatched gesture, Android's completion
 * callback, and a verified next-state marker are four separate events.
 */
class BotService : AccessibilityService() {

    companion object {
        @Volatile var instance: BotService? = null
        @Volatile var status: String = "Idle"
        @Volatile var lastState: GameState = GameState.UNKNOWN
        @Volatile var lastDetectedButton: String = "-"
        @Volatile var lastConfidence: Double = 0.0
        @Volatile var lastTapResult: String = "-"
        @Volatile var lastTransition: String = "-"
        @Volatile var lastEnvironmentProfile: String = "unknown"
        @Volatile var lastTapX: Float = -1f
        @Volatile var lastTapY: Float = -1f
        private val lines = mutableListOf<String>()
        @Volatile var operationMode: OperationMode = OperationMode.OBSERVER
        @Volatile var runningState: Boolean = false

        /** Compatibility hook used by AppLog to avoid duplicate timestamps. */
        fun logCompat(msg: String) {
            synchronized(lines) { lines += msg; while (lines.size > 400) lines.removeAt(0) }
        }

        fun log(msg: String) {
            val stamp = java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss"))
            synchronized(lines) {
                lines.add("[$stamp] $msg")
                while (lines.size > 500) lines.removeAt(0)
            }
        }

        fun recentLog(): String = synchronized(lines) { lines.joinToString("\n") }

        /** Android can revoke the projection independently (notification shade, system policy, etc.). */
        fun onCaptureStopped() {
            IntelligenceMetrics.onCaptureStopped(instance)
            RuntimeState.captureActive = false
            AppLog.add(LogCategory.CAPTURE, "Capture stopped")
            instance?.captureWasStopped()
        }
    }

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val mainHandler = Handler(Looper.getMainLooper())
    private val gestureInFlight = AtomicBoolean(false)
    private var job: Job? = null
    @Volatile private var lastEventPackage: String? = null
    @Volatile private var expectedRotation: Int = -1
    @Volatile private var expectedDisplayWidth: Int = 0
    @Volatile private var expectedDisplayHeight: Int = 0
    @Volatile private var gestureUncertainUntil: Long = 0L

    override fun onServiceConnected() {
        instance = this
        Templates.init(this)
        RoiConfig.load(Templates.folder())
        try {
            val info = serviceInfo
            info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or AccessibilityEvent.TYPE_VIEW_FOCUSED
            info.flags = info.flags or AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            serviceInfo = info
        } catch (e: Exception) {
            log("Accessibility configuration warning: ${e.message}")
        }
        log("Accessibility service connected; game package filter=${Config.gamePackage}")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        lastEventPackage = pkg
        if (pkg != Config.gamePackage && Config.diagnosticMode) {
            log("Accessibility event from non-game package: $pkg (${event.eventType})")
        }
    }

    override fun onInterrupt() { stop() }

    override fun onUnbind(intent: Intent?): Boolean {
        stop()
        instance = null
        lastEventPackage = null
        log("Accessibility service disconnected")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        stop()
        scope.cancel()
        if (instance === this) instance = null
        log("Accessibility service destroyed")
        super.onDestroy()
    }

    private fun captureWasStopped() {
        if (running) {
            job?.cancel()
            status = "Stopped: screen capture ended"
            log("Bot stopped automatically: Android MediaProjection session ended")
        }
    }

    /** Includes a gesture callback/timeout safety lock so capture cannot be released mid-tap. */
    val running: Boolean get() = job?.isActive == true || gestureInFlight.get() ||
        SystemClock.uptimeMillis() < gestureUncertainUntil
    val connected: Boolean get() = instance === this

    /** Inspect the verified foreground game's hierarchy; callers may supply a countdown. */
    fun isGameForeground(): Boolean {
        if (instance !== this) return false
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return false
        return try {
            root.packageName?.toString() == Config.gamePackage
        } finally {
            root.recycle()
        }
    }

    fun inspectAccessibilityNodes(delayMs: Long = 6000L) {
        scope.launch {
            if (delayMs > 0) delay(delayMs)
            val report = withContext(Dispatchers.Main) { inspectTreeOnMainThread() }
            report.forEach { log(it) }
        }
    }

    private fun inspectTreeOnMainThread(): List<String> {
        val report = mutableListOf<String>()
        val root = try { rootInActiveWindow } catch (e: Exception) {
            report += "Accessibility tree unavailable: ${e.message}"
            return report
        }
        if (root == null) return listOf("Accessibility tree: no active root window")
        try {
            val pkg = root.packageName?.toString()
            report += "Accessibility window: package=$pkg windowId=${root.windowId} class=${root.className}"
            if (pkg != Config.gamePackage) {
                report += "Accessibility tree ignored: expected ${Config.gamePackage}, found ${pkg ?: "unknown"}"
                return report
            }
            var visited = 0
            fun walk(node: AccessibilityNodeInfo, depth: Int) {
                if (visited >= 160) return
                visited++
                if (node.isVisibleToUser) {
                    val bounds = Rect().also { node.getBoundsInScreen(it) }
                    val text = node.text?.toString()?.replace('\n', ' ')?.take(70).orEmpty()
                    val desc = node.contentDescription?.toString()?.replace('\n', ' ')?.take(70).orEmpty()
                    val id = try { node.viewIdResourceName.orEmpty() } catch (_: Exception) { "" }
                    report += "AX[$depth] ${node.className} text='$text' desc='$desc' id='$id' " +
                        "bounds=$bounds clickable=${node.isClickable} enabled=${node.isEnabled} visible=${node.isVisibleToUser}"
                }
                for (i in 0 until node.childCount) {
                    val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
                    try { walk(child, depth + 1) } finally { child.recycle() }
                    if (visited >= 160) break
                }
            }
            walk(root, 0)
            if (visited >= 160) report += "Accessibility tree truncated at 160 nodes"
            if (visited <= 1) report += "No individual game controls exposed; use visual recognition"
        } finally {
            root.recycle()
        }
        return report
    }

    /** Returns false when safe prerequisites are not met. */
    fun start(): Boolean {
        if (job?.isActive == true) {
            log("Start ignored: bot is already running")
            return true
        }
        RuntimeState.mode = operationMode
        if (operationMode == OperationMode.OBSERVER) {
            status = "Observer mode: no automated taps"
            AppLog.add(LogCategory.SYSTEM, "Start blocked: Observer mode observes and learns but does not dispatch game taps")
            CompanionEngine.notify(1, "Observer mode", "Automation not started because Observer mode performs no automated game taps. Use Assistant for approved actions or Supervised for configured routines.")
            return false
        }
        if (operationMode == OperationMode.ASSISTANT) {
            status = "Assistant mode: approval required"
            AppLog.add(LogCategory.SYSTEM, "Start blocked: Assistant mode requires per-action user approval; automated loop not started without approval integration")
            CompanionEngine.notify(1, "Assistant mode", "Assistant mode can recommend actions but will not run unattended automation without explicit approval. Switch to Supervised Automation for configured routines, or use observation/diagnostics tools.")
            return false
        }
        if (gestureInFlight.get() || SystemClock.uptimeMillis() < gestureUncertainUntil) {
            status = "Waiting for previous gesture safety lock"
            log("START BLOCKED: previous gesture is still in flight or its result is uncertain")
            return false
        }
        Templates.init(this)
        RoiConfig.load(Templates.folder())
        ThresholdConfig.load(Templates.folder())
        BotSettings.load(this)
        IntelligenceMetrics.onBotStarted()
        AppLog.add(LogCategory.ACTIONS, "Supervised automation start requested")

        val problems = readinessProblems()
        if (problems.isNotEmpty()) {
            status = "Cannot start: setup incomplete"
            problems.forEach { log("START BLOCKED: $it") }
            return false
        }

        job = scope.launch {
            RuntimeState.botRunning = true
            status = "Waiting for game screen"
            log("Starting: switch to Rise of Kingdoms in landscape within 6 seconds")
            delay(6000)
            val initialFrame = ScreenCapture.grabGray(this@BotService)
            val initialInfo = ScreenCapture.displayInfo(this@BotService)
            if (initialFrame == null || initialInfo == null) {
                status = "Stopped: no screen frame available"
                log("START BLOCKED: MediaProjection did not produce a frame")
                return@launch
            }
            if (initialFrame.w <= initialFrame.h || initialInfo.displayWidth <= initialInfo.displayHeight) {
                status = "Stopped: game screen is portrait"
                log("START BLOCKED: capture=${initialFrame.w}x${initialFrame.h}; display=${initialInfo.displayWidth}x${initialInfo.displayHeight}; landscape required")
                return@launch
            }
            if (initialInfo.captureRotation != initialInfo.displayRotation) {
                status = "Stopped: capture rotation is stale"
                log("START BLOCKED: capture rotation ${initialInfo.captureRotation} != display rotation ${initialInfo.displayRotation}; restart screen capture")
                return@launch
            }
            val incompatible = Config.requiredTemplates.filter { name ->
                Templates.variants(name).none { it.gray.w <= initialFrame.w && it.gray.h <= initialFrame.h }
            }
            if (incompatible.isNotEmpty()) {
                status = "Stopped: incompatible or missing templates"
                log("START BLOCKED: no usable variant fits ${initialFrame.w}x${initialFrame.h}: ${incompatible.joinToString()}")
                return@launch
            }

            expectedRotation = initialInfo.displayRotation
            expectedDisplayWidth = initialInfo.displayWidth
            expectedDisplayHeight = initialInfo.displayHeight
            log("Capture preflight: ${initialFrame.w}x${initialFrame.h} landscape; display ${expectedDisplayWidth}x${expectedDisplayHeight}; rotation=$expectedRotation")
            log("Started: ${Config.maxMarches} march slot(s), rotation ${Config.rotation.joinToString(" → ")}, threshold ${"%.2f".format(Config.threshold)}; multi-variant/multi-scale grayscale+edge matching")

            var marchIndex = 0
            var failedRounds = 0
            while (isActive) {
                var sent = 0
                var noMarches = false
                for (i in 0 until Config.maxMarches) {
                    if (!isActive) break
                    val resource = Config.rotation[marchIndex % Config.rotation.size]
                    marchIndex++
                    status = "March ${i + 1}/${Config.maxMarches}: $resource"
                    val outcome = runMarch(resource)
                    BotMetrics.recordAttempt(this@BotService, resource, outcome.name)
                    when (outcome) {
                        Outcome.OK -> sent++
                        Outcome.ABORT -> recover()
                        Outcome.NO_MARCHES -> {
                            noMarches = true
                            recover()
                            break
                        }
                    }
                }
                if (!isActive) break

                BotMetrics.recordRound(this@BotService)
                log("Round complete: $sent confirmed dialog transition(s)" + if (noMarches) " (no free march slot)" else "")
                if (sent == 0 && !noMarches) failedRounds++ else failedRounds = 0
                // maxFailedRounds is the number of exponential retry waits (e.g. 2/4/8 min).
                // The bot stops on the next empty round, so every configured backoff is reachable.
                if (failedRounds > Config.maxFailedRounds) {
                    status = "Stopped: $failedRounds consecutive empty rounds after ${Config.maxFailedRounds} retry wait(s)"
                    log(status)
                    return@launch
                }

                val pauseMs = if (sent == 0 && !noMarches) retryDelayMs(failedRounds) else Config.cycleWaitMs
                status = if (sent == 0 && !noMarches) "Retry backoff: ${pauseMs / 60_000} min (failure $failedRounds/${Config.maxFailedRounds})"
                    else "Waiting for marches to return..."
                log("Next cycle in ${pauseMs / 60_000}m ${((pauseMs % 60_000) / 1000)}s")
                wait(pauseMs)
            }
        }
        job?.invokeOnCompletion { IntelligenceMetrics.onBotStopped(this@BotService); IntelligenceMetrics.persist(this@BotService); RuntimeState.botRunning = false; AppLog.add(LogCategory.SYSTEM, "Bot loop completed") }
        return true
    }

    fun stop() {
        SafeActionController.cancelAll("bot stopped by user")
        job?.cancel()
        status = "Stopped"
        log("Bot stopped; screen capture remains active until explicitly stopped")
        RuntimeState.botRunning = false
        IntelligenceMetrics.onBotStopped(this)
        IntelligenceMetrics.persist(this)
        AppLog.add(LogCategory.SYSTEM, "Bot stopped")
    }

    private fun readinessProblems(): List<String> {
        val problems = mutableListOf<String>()
        if (!connected) problems += "Accessibility service is not connected."
        if (!ScreenCapture.active) problems += "Screen capture is off; enable it before starting."
        if (Config.maxMarches !in 1..6) problems += "March count must be between 1 and 6."
        if (Config.threshold !in 0.50..0.99) problems += "Matching threshold must be between 0.50 and 0.99."
        if (Config.rotation.isEmpty() || Config.rotation.size > Config.maxRotationEntries || Config.rotation.any { it !in Config.resourceTabs }) {
            problems += "Resource rotation must contain 1-${Config.maxRotationEntries} valid resource entries."
        }
        if (Config.cycleWaitMs !in Config.minCycleWaitMs..Config.maxCycleWaitMs) problems += "Cycle wait must be between 1 minute and 12 hours."
        if (Config.retryWaitMs !in Config.minRetryWaitMs..Config.maxConfiguredRetryWaitMs) problems += "Retry wait must be between 1 and 60 minutes."
        if (Config.maxRetryWaitMs !in Config.retryWaitMs..Config.maxConfiguredMaxRetryWaitMs) problems += "Maximum retry wait must be at least the initial delay and no more than 360 minutes."
        if (Config.maxFailedRounds !in 1..10) problems += "Maximum failed rounds must be between 1 and 10."
        val missing = Config.requiredTemplates.filter { Templates.variants(it).isEmpty() }
        if (missing.isNotEmpty()) problems += "Missing or unreadable templates: ${missing.joinToString(", ")}."
        val uncalibrated = Config.requiredTemplates.filter { RoiConfig.get(it) == null }
        if (uncalibrated.isNotEmpty()) problems += "Calibrate a normalized search ROI from real game screenshots for: ${uncalibrated.joinToString(", ")}. Full-frame searches are diagnostic-only; the bot will not start without ROIs."
        Config.requiredTemplates.filterNot { it in missing }.forEach { name ->
            val valid = Templates.variants(name).filter { variant ->
                try { TemplateMatcher.validate(variant.gray); true } catch (e: Exception) {
                    problems += "Template '${variant.file.name}' rejected: ${e.message}"
                    false
                }
            }
            if (valid.isEmpty()) problems += "Template '$name' has no usable variant."
        }
        return problems
    }

    private fun retryDelayMs(failedRounds: Int): Long {
        val exponent = (failedRounds - 1).coerceIn(0, 6)
        return (Config.retryWaitMs * (1L shl exponent)).coerceAtMost(Config.maxRetryWaitMs)
    }

    // ---- verified gathering workflow ------------------------------------------------

    private suspend fun runMarch(resource: String): Outcome {
        val tab = Config.resourceTabs[resource] ?: run {
            log("Unknown resource '$resource'")
            return Outcome.ABORT
        }
        var state = GameState.UNKNOWN
        val steps = listOf(Config.searchButton, tab, Config.searchGo, Config.gatherButton, Config.newTroops, Config.marchButton)
        for (step in steps) {
            val result = runStep(step, state)
            if (result.outcome != Outcome.OK) return result.outcome
            state = result.state
            if (step == Config.marchButton) {
                val reference = result.match ?: run {
                    log("March button was tapped but no visual reference was retained; refusing to count it")
                    return Outcome.ABORT
                }
                if (!verifyMarchDialogClosed(reference)) return Outcome.ABORT
                lastState = GameState.GATHERING
                lastTransition = "MARCH_CONFIRMATION → GATHERING (dialog closed)"
                log("State transition confirmed: ${lastTransition}; this is not proof of troop arrival")
            }
        }
        return Outcome.OK
    }

    private suspend fun runStep(step: Step, currentState: GameState): StepResult {
        val name = step.template ?: run {
            log("'${step.name}' has no template configured")
            return StepResult(Outcome.ABORT)
        }
        if (Templates.variants(name).isEmpty()) {
            log("'${step.name}' blocked: template '$name' is missing or unreadable")
            return StepResult(Outcome.ABORT)
        }
        if (step.state != GameState.WORLD_MAP && currentState != step.state) {
            log("STATE MISMATCH: action '${step.name}' requires ${step.state}, workflow is $currentState; no tap performed")
            return StepResult(Outcome.ABORT, state = currentState)
        }

        val deadline = SystemClock.uptimeMillis() + step.timeoutMs
        var previousVisual: TemplateMatcher.Match? = null
        var visualStableFrames = 0
        var previousSemantic: String? = null
        var semanticStableFrames = 0
        while (currentCoroutineContext().isActive) {
            val screen = ScreenCapture.grabGray(this)
            if (screen == null) {
                log("'${step.name}' blocked: screen frame unavailable")
                return StepResult(Outcome.ABORT, state = currentState)
            }
            lastEnvironmentProfile = AdaptiveLearning.profile(screen).description
            if (!frameStillCalibrated(screen)) return StepResult(Outcome.ABORT, state = GameState.ERROR)
            val hybrid = TemplateMatcher.HybridFrame(screen)
            blocker(hybrid)?.let { return StepResult(it, state = GameState.POPUP) }

            val roi = roiFor(name, screen)
            if (roi.error != null) {
                log("ROI rejected for '$name': ${roi.error}; no tap performed")
                return StepResult(Outcome.ABORT, state = GameState.ERROR)
            }
            val detection = recognize(hybrid, name, roi.pixels)
            // Require the same visual location to be present in two consecutive frames before
            // any gesture. This temporal confirmation reduces taps on animation/noise artefacts.
            val visualMatchCandidate = detection.best?.match
            val visualStable = if (detection.accepted && visualMatchCandidate != null) {
                val prior = previousVisual
                val tolerance = maxOf(12.0, minOf(visualMatchCandidate.width, visualMatchCandidate.height) * 0.28)
                val dx = prior?.let { kotlin.math.abs(it.centerX - visualMatchCandidate.centerX).toDouble() } ?: Double.MAX_VALUE
                val dy = prior?.let { kotlin.math.abs(it.centerY - visualMatchCandidate.centerY).toDouble() } ?: Double.MAX_VALUE
                val sameLocation = prior != null && kotlin.math.sqrt(dx * dx + dy * dy) <= tolerance
                visualStableFrames = if (sameLocation) visualStableFrames + 1 else 1
                previousVisual = visualMatchCandidate
                visualStableFrames >= 2
            } else {
                visualStableFrames = 0
                previousVisual = null
                false
            }
            // Accessibility is a supplementary semantic fallback, never a text-only blind click:
            // the node must be unique, clickable, enabled, visible, in the game package and in-bounds.
            val semanticTarget = if (!detection.accepted) findAccessibilityTarget(name, screen) else null
            val semanticStable = semanticTarget?.let { target ->
                val key = "${target.label}:${target.bounds.centerX() / 16}:${target.bounds.centerY() / 16}"
                semanticStableFrames = if (key == previousSemantic) semanticStableFrames + 1 else 1
                previousSemantic = key
                semanticStableFrames >= 2
            } ?: run { semanticStableFrames = 0; previousSemantic = null; false }
            if (detection.accepted && !visualStable) {
                if (visualStableFrames == 1) log("Candidate for '$name' seen once; waiting for a second stable frame before any tap")
                delay(Config.pollIntervalMs)
                continue
            }
            if (semanticTarget != null && !semanticStable) {
                if (semanticStableFrames == 1) log("Accessibility candidate for '$name' seen once; waiting for a second stable frame before any tap")
                delay(Config.pollIntervalMs)
                continue
            }
            if (detection.accepted || semanticTarget != null) {
                // For the first step, a fresh visual/node marker establishes WORLD_MAP.
                val detectedState = if (step.state == GameState.WORLD_MAP && currentState == GameState.UNKNOWN) GameState.WORLD_MAP else currentState
                if (detectedState != step.state) {
                    log("State $detectedState does not permit '${step.name}' (${step.state}); no tap performed")
                    return StepResult(Outcome.ABORT, state = detectedState)
                }
                lastState = detectedState
                lastDetectedButton = name
                val visualMatch = detection.best?.match
                val tapComplete = if (visualMatch != null && detection.accepted) {
                    lastConfidence = visualMatch.score
                    logDetection(detection, roi.description, screen, detectedState, accepted = true)
                    tapDetected(step.name, visualMatch, screen)
                } else {
                    lastConfidence = -1.0 // semantic accessibility match, not a visual confidence score
                    log("ACCESSIBILITY ACCEPTED: id=$name state=$detectedState label='${semanticTarget!!.label}' " +
                        "bounds=${semanticTarget.bounds}; package=${Config.gamePackage}; clickable/enabled/visible; unique candidate")
                    tapAccessibilityTarget(step.name, semanticTarget, screen)
                }
                if (!tapComplete) {
                    log("Tap sequence failed for '${step.name}'; workflow halted")
                    return StepResult(Outcome.ABORT, state = GameState.ERROR)
                }
                wait(step.waitMs)
                val next = step.nextState ?: detectedState
                if (step.verifyTemplate != null) {
                    if (!verifyNextState(detectedState, next, step.verifyTemplate, Config.transitionVerifyTimeoutMs)) {
                        return StepResult(Outcome.ABORT, state = GameState.ERROR)
                    }
                    if (visualMatch != null && AdaptiveLearning.enabled) {
                        AdaptiveLearning.recordVerifiedPositive(
                            Templates.folder(), name, screen, visualMatch.score,
                            detection.threshold, visualMatch.centerX, visualMatch.centerY
                        )
                        log("Adaptive learning: recorded verified positive for $name in ${AdaptiveLearning.profile(screen).key}")
                    }
                }
                return StepResult(Outcome.OK, visualMatch, next)
            }
            if (Config.diagnosticMode) {
                // In diagnostic mode retain every poll result, including no-candidate/invalid ROI
                // cases, so a timeout explains the full search history rather than only its peak.
                logDetection(detection, roi.description, screen, currentState, accepted = false)
            }

            if (SystemClock.uptimeMillis() >= deadline) {
                val best = detection.best
                log("'${step.name}' not found before timeout; expected state=${step.state}, detected=${lastState}; " +
                    "template=$name ROI=${roi.description} score=${best?.score?.let { "%.3f".format(it) } ?: "none"} " +
                    "threshold=${"%.3f".format(detection.threshold)} reason=${detection.reason}; no tap performed")
                return StepResult(Outcome.ABORT, state = currentState)
            }
            delay(Config.pollIntervalMs)
        }
        return StepResult(Outcome.ABORT, state = currentState)
    }

    private suspend fun verifyNextState(from: GameState, to: GameState, marker: String, timeoutMs: Long): Boolean {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        while (currentCoroutineContext().isActive) {
            delay(180)
            val screen = ScreenCapture.grabGray(this)
            if (screen == null || !frameStillCalibrated(screen)) {
                log("Transition $from → $to unconfirmed: frame unavailable or orientation changed")
                return false
            }
            val hybrid = TemplateMatcher.HybridFrame(screen)
            blocker(hybrid)?.let {
                log("Transition $from → $to blocked by popup; no additional action")
                lastState = GameState.POPUP
                return false
            }
            val roi = roiFor(marker, screen)
            if (roi.error != null) {
                log("Transition ROI error for '$marker': ${roi.error}")
                return false
            }
            val result = recognize(hybrid, marker, roi.pixels)
            if (result.accepted) {
                val detail = "$from → $to"
                lastState = to
                lastTransition = detail
                log("State transition confirmed: $detail via '$marker' (${"%.3f".format(result.best!!.score)})")
                return true
            }
            if (SystemClock.uptimeMillis() >= deadline) {
                log("State transition NOT confirmed: expected $to marker '$marker'; best=${result.best?.score?.let { "%.3f".format(it) } ?: "none"}; no next action")
                return false
            }
        }
        return false
    }

    /** March success is deliberately only a dialog-close UI signal, not proof of troop dispatch. */
    private suspend fun verifyMarchDialogClosed(reference: TemplateMatcher.Match): Boolean {
        val name = Config.marchButton.template ?: return false
        if (Templates.variants(name).isEmpty()) return false
        val margin = Config.verifyRegionMarginPx
        val region = intArrayOf(
            (reference.x - margin).coerceAtLeast(0),
            (reference.y - margin).coerceAtLeast(0),
            (reference.x + reference.width + margin),
            (reference.y + reference.height + margin),
        )
        val deadline = SystemClock.uptimeMillis() + Config.marchVerifyTimeoutMs
        var consecutiveMissing = 0
        while (currentCoroutineContext().isActive) {
            val screen = ScreenCapture.grabGray(this) ?: run {
                log("March result unknown: no screen frame available")
                return false
            }
            if (!frameStillCalibrated(screen)) return false
            val hybrid = TemplateMatcher.HybridFrame(screen)
            if (blocker(hybrid) != null) {
                log("March result blocked by popup; dispatch not counted")
                return false
            }
            val result = recognize(hybrid, name, region)
            val stillVisible = result.candidates.any { it.score >= result.threshold }
            if (stillVisible) {
                consecutiveMissing = 0
            } else {
                consecutiveMissing++
                if (consecutiveMissing >= Config.requiredMissingFrames) {
                    log("March button absent from its original bounds for $consecutiveMissing frames across ${Templates.variants(name).size} variant(s); UI transition confirmed")
                    return true
                }
            }
            if (SystemClock.uptimeMillis() >= deadline) {
                log("March button remained visible; dispatch unconfirmed. No second March tap will be made")
                return false
            }
            delay(Config.pollIntervalMs)
        }
        return false
    }

    private suspend fun recover() {
        if (!ScreenCapture.active) {
            log("Recovery skipped: screen capture is off")
            return
        }
        val screen = ScreenCapture.grabGray(this) ?: run {
            log("Recovery skipped: screen frame unavailable")
            return
        }
        if (!frameStillCalibrated(screen)) return
        val hybrid = TemplateMatcher.HybridFrame(screen)
        if (blocker(hybrid) == null) {
            log("Recovery skipped: no known blocking popup currently detected")
            return
        }
        val closeName = Config.dismiss.template ?: return
        val roi = roiFor(closeName, screen)
        if (roi.error != null) {
            log("Recovery ROI error: ${roi.error}")
            return
        }
        val result = recognize(hybrid, closeName, roi.pixels)
        if (!result.accepted) {
            log("Recovery: close button not detected (${result.reason}); no tap performed")
            return
        }
        val found = result.best!!.match
        if (!tapDetected("recovery close", found, screen)) {
            log("Recovery close-button gesture not completed")
            return
        }
        wait(Config.dismiss.waitMs)
    }

    // ---- recognition, state and ROI --------------------------------------------------


    private data class AccessibilityTarget(val bounds: Rect, val label: String)

    private fun labelsFor(templateId: String): Set<String> = when (templateId) {
        "btn_search" -> setOf("search", "open search", "search map")
        "tab_food" -> setOf("food")
        "tab_wood" -> setOf("wood")
        "tab_stone" -> setOf("stone")
        "tab_gold" -> setOf("gold")
        "btn_search_go" -> setOf("search", "go", "find")
        "btn_gather" -> setOf("gather")
        "btn_new_troops" -> setOf("new troops", "troops")
        "btn_march" -> setOf("march")
        "btn_close" -> setOf("close")
        else -> emptySet()
    }

    private suspend fun findAccessibilityTarget(
        templateId: String,
        frame: TemplateMatcher.Gray,
    ): AccessibilityTarget? {
        val expectedLabels = labelsFor(templateId)
        if (expectedLabels.isEmpty()) return null
        val info = ScreenCapture.displayInfo(this) ?: return null
        return withContext(Dispatchers.Main) {
            val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return@withContext null
            try {
                val pkg = root.packageName?.toString()
                if (pkg != Config.gamePackage) {
                    if (Config.diagnosticMode) log("Accessibility fallback skipped: active package=$pkg expected=${Config.gamePackage}")
                    return@withContext null
                }
                val matches = mutableListOf<AccessibilityTarget>()
                var visited = 0
                fun norm(s: CharSequence?): String = s?.toString()?.trim()?.lowercase(Locale.ROOT)
                    ?.replace(Regex("[^a-z0-9 ]"), "")?.replace(Regex("\\s+"), " ").orEmpty()
                fun walk(node: AccessibilityNodeInfo) {
                    if (visited++ >= 160) return
                    if (node.isVisibleToUser && node.isEnabled && node.isClickable) {
                        val text = norm(node.text)
                        val desc = norm(node.contentDescription)
                        val resourceId = norm(try { node.viewIdResourceName } catch (_: Exception) { null })
                        val label = sequenceOf(text, desc, resourceId).firstOrNull { value ->
                            value.isNotEmpty() && expectedLabels.any { value == it || value.endsWith(" $it") }
                        }
                        if (label != null) {
                            val bounds = Rect().also { node.getBoundsInScreen(it) }
                            val validSize = bounds.width() in 12..(info.displayWidth * 0.60).toInt() &&
                                bounds.height() in 12..(info.displayHeight * 0.60).toInt()
                            val insideDisplay = bounds.left >= 0 && bounds.top >= 0 &&
                                bounds.right <= info.displayWidth && bounds.bottom <= info.displayHeight
                            if (validSize && insideDisplay) matches += AccessibilityTarget(Rect(bounds), label)
                        }
                    }
                    for (index in 0 until node.childCount) {
                        val child = try { node.getChild(index) } catch (_: Exception) { null } ?: continue
                        try { walk(child) } finally { child.recycle() }
                        if (visited >= 160) break
                    }
                }
                walk(root)
                when (matches.size) {
                    1 -> matches.first()
                    0 -> null
                    else -> {
                        log("Accessibility fallback rejected for $templateId: ${matches.size} matching clickable nodes; ambiguous")
                        null
                    }
                }
            } finally {
                root.recycle()
            }
        }
    }

    private suspend fun tapAccessibilityTarget(
        label: String,
        target: AccessibilityTarget,
        frame: TemplateMatcher.Gray,
    ): Boolean {
        val info = ScreenCapture.displayInfo(this) ?: return false
        val bounds = target.bounds
        if (bounds.isEmpty || bounds.left < 0 || bounds.top < 0 ||
            bounds.right > info.displayWidth || bounds.bottom > info.displayHeight ||
            info.captureRotation != expectedRotation || info.displayRotation != expectedRotation) {
            log("Accessibility node tap blocked for '$label': bounds/rotation invalid ($bounds)")
            lastTapResult = "BLOCKED: accessibility bounds invalid"
            return false
        }
        val x = bounds.exactCenterX()
        val y = bounds.exactCenterY()
        lastTapX = x
        lastTapY = y
        log("Accessibility target mapped from current window bounds; frame=${frame.w}x${frame.h}; display=${info.displayWidth}x${info.displayHeight}; tap=${x.toInt()},${y.toInt()}")
        val result = tapPx(label, x, y, info.displayWidth, info.displayHeight)
        lastTapResult = result.name
        return result == GestureResult.COMPLETED
    }

    private fun roiFor(name: String, screen: TemplateMatcher.Gray): RoiLookup = try {
        val normalized = RoiConfig.get(name)
        if (normalized == null) RoiLookup(null, RoiConfig.description(name))
        else RoiLookup(normalized.toPixels(screen.w, screen.h), RoiConfig.description(name))
    } catch (e: Exception) {
        RoiLookup(null, RoiConfig.description(name), e.message ?: "invalid ROI")
    }

    private fun recognize(frame: TemplateMatcher.HybridFrame, name: String, region: IntArray?): RecognitionResult =
        RecognitionRouter.recognize(frame, name, Config.thresholdFor(name), region)

    private fun blocker(frame: TemplateMatcher.HybridFrame): Outcome? {
        for (blocker in Config.blockers) {
            val name = blocker.template
            val roi = roiFor(name, frame.gray)
            if (roi.error != null) {
                log("Blocker ROI rejected for '$name': ${roi.error}")
                continue
            }
            val result = recognize(frame, name, roi.pixels)
            if (result.accepted) {
                log("Detected blocking popup '$name' confidence=${"%.3f".format(result.best!!.score)}")
                lastState = GameState.POPUP
                return if (blocker.noMarches) Outcome.NO_MARCHES else Outcome.ABORT
            }
        }
        return null
    }

    private fun logDetection(
        result: RecognitionResult,
        region: String,
        screen: TemplateMatcher.Gray,
        state: GameState,
        accepted: Boolean,
    ) {
        val best = result.best
        val prefix = "Recognition ${if (accepted) "ACCEPTED" else "REJECTED"}: id=${result.templateId} state=$state " +
            "frame=${screen.w}x${screen.h} orientation=${if (screen.w > screen.h) "LANDSCAPE" else "PORTRAIT"} ROI=$region"
        if (best == null) log("$prefix; no candidate; ${result.reason}")
        else {
            log("$prefix; template=${best.file}; method=multi-scale grayscale+edge; scale=${best.scale}; " +
                "confidence=${"%.3f".format(best.score)} threshold=${"%.3f".format(result.threshold)} " +
                "bounds=${best.match.x},${best.match.y},${best.match.width}x${best.match.height} " +
                "center=${best.match.centerX},${best.match.centerY}; competing=${result.candidates.size - 1}; ${result.reason}")
        }
    }

    private fun frameStillCalibrated(frame: TemplateMatcher.Gray): Boolean {
        val info = ScreenCapture.displayInfo(this)
        if (info == null) return pauseForRecalibration("display metadata unavailable")
        if (frame.w <= frame.h || info.displayWidth <= info.displayHeight) {
            return pauseForRecalibration("orientation changed to portrait; capture=${frame.w}x${frame.h} display=${info.displayWidth}x${info.displayHeight}")
        }
        if (frame.w != info.frameWidth || frame.h != info.frameHeight) {
            return pauseForRecalibration("captured frame dimensions changed: current=${frame.w}x${frame.h}, metadata=${info.frameWidth}x${info.frameHeight}")
        }
        if (info.captureRotation != expectedRotation || info.displayRotation != expectedRotation ||
            info.displayWidth != expectedDisplayWidth || info.displayHeight != expectedDisplayHeight) {
            return pauseForRecalibration("display rotation/size changed; expected=${expectedDisplayWidth}x${expectedDisplayHeight} rot=$expectedRotation, captureRot=${info.captureRotation}, display=${info.displayWidth}x${info.displayHeight} rot=${info.displayRotation}")
        }
        return true
    }

    private fun pauseForRecalibration(reason: String): Boolean {
        log("Automation paused: $reason; bot must be restarted after capture is recalibrated")
        status = "Paused: recalibration required"
        job?.cancel()
        return false
    }

    // ---- timing and accessibility gestures ------------------------------------------

    private suspend fun wait(ms: Long) {
        if (ms <= 0) return
        val jitter = (ms * Config.DELAY_JITTER).toLong().coerceAtLeast(0)
        val adjusted = if (jitter > 0) ms + kotlin.random.Random.nextLong(-jitter, jitter + 1) else ms
        delay(adjusted.coerceAtLeast(0))
    }

    private suspend fun activeWindowPackage(): String? = withTimeoutOrNull(700) {
        suspendCancellableCoroutine { continuation ->
            val posted = mainHandler.post {
                val pkg = try { rootInActiveWindow?.let { root ->
                    try { root.packageName?.toString() } finally { root.recycle() }
                } } catch (_: Exception) { null }
                if (continuation.isActive) continuation.resume(pkg)
            }
            if (!posted && continuation.isActive) continuation.resume(null)
        }
    }

    private suspend fun tapDetected(label: String, match: TemplateMatcher.Match, frame: TemplateMatcher.Gray): Boolean {
        val info = ScreenCapture.displayInfo(this)
        if (info == null || info.captureRotation != expectedRotation || info.displayRotation != expectedRotation) {
            lastTapResult = "BLOCKED: rotation mismatch"
            log("Tap blocked for '$label': capture/display rotation mismatch")
            return false
        }
        val point = CoordinateMapper.map(
            match.centerX.toFloat(), match.centerY.toFloat(), frame.w, frame.h,
            info.displayWidth, info.displayHeight, info.captureRotation, info.displayRotation
        )
        if (point == null) {
            lastTapResult = "BLOCKED: invalid coordinate mapping"
            log("Tap blocked for '$label': cannot map frame ${frame.w}x${frame.h} to display ${info.displayWidth}x${info.displayHeight} at rotation ${info.displayRotation}")
            return false
        }
        log("Button detected: '$label' at frame=${match.centerX},${match.centerY} confidence=${"%.3f".format(match.score)}")
        log("Coordinate mapping: ${frame.w}x${frame.h} → ${info.displayWidth}x${info.displayHeight}; display point=${point.x.toInt()},${point.y.toInt()}")
        lastTapX = point.x
        lastTapY = point.y
        val result = tapPx(label, point.x, point.y, info.displayWidth, info.displayHeight)
        lastTapResult = result.name
        return result == GestureResult.COMPLETED
    }

    private suspend fun tapPx(label: String, px: Float, py: Float, displayW: Int, displayH: Int): GestureResult {
        if (!connected || ((serviceInfo?.capabilities ?: 0) and AccessibilityServiceInfo.CAPABILITY_CAN_PERFORM_GESTURES) == 0) {
            log("Gesture blocked for '$label': accessibility service disconnected or gestures disabled")
            return GestureResult.DISCONNECTED
        }
        if (!px.isFinite() || !py.isFinite() || displayW <= 0 || displayH <= 0 ||
            px < 0f || py < 0f || px >= displayW || py >= displayH) {
            log("Gesture rejected for '$label': coordinate (${px},${py}) outside ${displayW}x${displayH}")
            return GestureResult.REJECTED
        }
        if (SystemClock.uptimeMillis() < gestureUncertainUntil) {
            log("Gesture blocked for '$label': previous gesture result was uncertain; cooldown still active")
            return GestureResult.TIMEOUT
        }
        if (!gestureInFlight.compareAndSet(false, true)) {
            log("Gesture rejected for '$label': another gesture is still in flight")
            return GestureResult.REJECTED
        }
        try {
            val pkg = activeWindowPackage()
            if (pkg != Config.gamePackage) {
                log("Gesture blocked for '$label': foreground accessibility package is '${pkg ?: "unknown"}', expected '${Config.gamePackage}'")
                return GestureResult.DISCONNECTED
            }
            val path = Path().apply { moveTo(px, py) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, Config.gestureDurationMs))
                .build()
            val result = withTimeoutOrNull(Config.gestureTimeoutMs) {
                suspendCancellableCoroutine { continuation ->
                    val posted = mainHandler.post {
                        if (!continuation.isActive) {
                            gestureInFlight.set(false)
                            return@post
                        }
                        try {
                            val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                                override fun onCompleted(gesture: GestureDescription?) {
                                    log("Gesture completed by Android: '$label'")
                                    gestureInFlight.set(false)
                                    if (continuation.isActive) continuation.resume(GestureResult.COMPLETED)
                                }
                                override fun onCancelled(gesture: GestureDescription?) {
                                    log("Gesture cancelled by Android: '$label'")
                                    gestureInFlight.set(false)
                                    if (continuation.isActive) continuation.resume(GestureResult.CANCELLED)
                                }
                            }, mainHandler)
                            if (accepted) {
                                log("Gesture dispatched to Android: '$label' at ${px.toInt()},${py.toInt()}")
                            } else {
                                log("dispatchGesture() rejected '$label'")
                                gestureInFlight.set(false)
                                if (continuation.isActive) continuation.resume(GestureResult.REJECTED)
                            }
                        } catch (e: Exception) {
                            log("Gesture dispatch exception for '$label': ${e.message}")
                            gestureInFlight.set(false)
                            if (continuation.isActive) continuation.resume(GestureResult.REJECTED)
                        }
                    }
                    if (!posted && continuation.isActive) {
                        gestureInFlight.set(false)
                        continuation.resume(GestureResult.DISCONNECTED)
                    }
                }
            }
            if (result == null) {
                gestureUncertainUntil = SystemClock.uptimeMillis() + 2000L
                log("Gesture callback timed out for '$label'; execution result is unknown; 2s duplicate-action guard applied")
                return GestureResult.TIMEOUT
            }
            if (result == GestureResult.COMPLETED) log("Gesture completed: '$label' (Android callback)")
            else log("Gesture did not complete: '$label' result=$result")
            return result
        } finally {
            gestureInFlight.set(false)
        }
    }
}
