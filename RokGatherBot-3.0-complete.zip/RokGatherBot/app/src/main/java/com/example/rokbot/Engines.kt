package com.example.rokbot

import android.content.Context
import android.os.SystemClock
import java.io.File
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

object CaptureEngineModule : RokEngine {
    override val id = "capture"
    override val displayName = "Engine 1: Live Screen Capture"
    override fun status(): EngineStatus {
        val active = ScreenCapture.active
        RuntimeState.captureActive = active
        val stale = active && RuntimeState.lastCaptureFrameMs > 0 && (SystemClock.elapsedRealtime() - RuntimeState.lastCaptureFrameMs) > 5000
        val h = when {
            !active -> if (RuntimeState.capturePermissionMissing) EngineHealth.DEGRADED else EngineHealth.STOPPED
            stale -> EngineHealth.DEGRADED
            else -> EngineHealth.HEALTHY
        }
        val info = try { null as CaptureInfo? } catch (_: Exception) { null }
        return EngineStatus(id, displayName, h,
            if (!active) "Capture inactive" else if (stale) "Stale/frozen frame risk" else "Projection active",
            details = mapOf("active" to active.toString(), "stale" to stale.toString()))
    }
}

object RecognitionMonitorEngine : RokEngine {
    override val id = "recognition_monitor"
    override val displayName = "Engine 2: Recognition Monitor"
    data class Obs(val target: String, val confidence: Double, val threshold: Double, val template: String?, val roi: String, val durationMs: Long, val accepted: Boolean, val ambiguous: Boolean, val rejected: Boolean, val reason: String, val time: Long = System.currentTimeMillis())
    private val recent = ConcurrentLinkedDeque<Obs>()
    private val MAX = 200
    @Volatile var lastObs: Obs? = null
    fun record(o: Obs) {
        lastObs = o; recent.addLast(o); while (recent.size > MAX) recent.removeFirst()
        RuntimeState.recognitionStatus = if (o.accepted) "Candidate confirmed: ${o.target}" else if (o.ambiguous) "Ambiguous: ${o.target}" else "Rejected: ${o.target}"
        val outcome = when { o.accepted -> RecognitionOutcome.CORRECT; o.ambiguous -> RecognitionOutcome.AMBIGUOUS; else -> RecognitionOutcome.REJECTED }
        // raw recognition observation; verified accuracy is tracked separately via explicit verification/feedback
        IntelligenceMetrics.recordRecognition(o.target, outcome, false)
    }
    fun snapshot(): List<Obs> = recent.toList()
    override fun status(): EngineStatus {
        val o = lastObs
        return EngineStatus(id, displayName, EngineHealth.HEALTHY,
            o?.let { "Last: ${it.target} ${"%.3f".format(it.confidence)} / ${"%.3f".format(it.threshold)} ${if (it.accepted) "confirmed-candidate" else it.reason}" } ?: "No observations yet",
            details = mapOf("observations" to recent.size.toString()))
    }
}

object TemplateCompetitionEngine : RokEngine {
    override val id = "template_competition"
    override val displayName = "Engine 3: Template Competition"
    data class Competition(val templateId: String, val winner: String?, val winnerScore: Double, val candidates: Int, val ambiguous: Boolean, val reason: String, val time: Long = System.currentTimeMillis())
    private val recent = ConcurrentLinkedDeque<Competition>()
    fun record(c: Competition) { recent.addLast(c); while (recent.size > 100) recent.removeFirst() }
    fun snapshot(): List<Competition> = recent.toList()
    override fun status(): EngineStatus = EngineStatus(id, displayName, EngineHealth.HEALTHY,
        recent.lastOrNull()?.let { "Last: ${it.templateId} → ${it.winner ?: "none"} (${it.candidates} candidates)" } ?: "Ready")
}

object AdaptiveRecognitionEngine : RokEngine {
    override val id = "adaptive_recognition"
    override val displayName = "Engine 4: Adaptive Visual Recognition"
    @Volatile var lastProfile: String = "unknown"
    @Volatile var lastStrategy: String = "hybrid(gray+edge)+multi-scale"
    override fun status(): EngineStatus = EngineStatus(id, displayName, EngineHealth.HEALTHY,
        "Profile: $lastProfile · $lastStrategy",
        details = mapOf("profile" to lastProfile))
}

object RoiDiscoveryEngine : RokEngine {
    override val id = "roi_discovery"
    override val displayName = "Engine 5: Dynamic ROI Discovery"
    data class RoiEvent(val templateId: String, val old: String, val new: String, val reason: String, val time: Long = System.currentTimeMillis())
    private val events = ConcurrentLinkedDeque<RoiEvent>()
    @Volatile var lastChange: String = "No dynamic changes"
    fun record(e: RoiEvent) { events.addLast(e); lastChange = "${e.templateId}: ${e.reason}"; while (events.size > 50) events.removeFirst(); AppLog.add(LogCategory.RECOGNITION, "ROI changed ${e.templateId}: ${e.reason}") }
    fun snapshot(): List<RoiEvent> = events.toList()
    override fun status(): EngineStatus = EngineStatus(id, displayName, EngineHealth.HEALTHY, lastChange,
        details = mapOf("changes" to events.size.toString()))
}

object GameStateEngine : RokEngine {
    override val id = "game_state"
    override val displayName = "Engine 6: Game State Detection"
    data class Transition(val from: GameState, val to: GameState, val plausible: Boolean, val evidence: String, val time: Long = System.currentTimeMillis())
    private val transitions = ConcurrentLinkedDeque<Transition>()
    @Volatile var previous: GameState = GameState.UNKNOWN

    fun update(newState: GameState, evidence: String, plausible: Boolean = true) {
        val from = RuntimeState.currentGameState
        if (from != newState) {
            transitions.addLast(Transition(from, newState, plausible, evidence))
            while (transitions.size > 200) transitions.removeFirst()
            previous = from
            RuntimeState.currentGameState = newState
            AppLog.add(LogCategory.RECOGNITION, "State $from → $newState ($evidence)")
        }
    }
    fun history(): List<Transition> = transitions.toList()
    override fun status(): EngineStatus = EngineStatus(id, displayName, EngineHealth.HEALTHY,
        "Current: ${RuntimeState.currentGameState} · transitions: ${transitions.size}")
}

object TemporalVerificationEngine : RokEngine {
    override val id = "temporal"
    override val displayName = "Engine 7: Temporal Verification"
    data class Check(val name: String, val framesRequired: Int, val framesSeen: Int, val passed: Boolean, val detail: String, val time: Long = System.currentTimeMillis())
    private val checks = ConcurrentLinkedDeque<Check>()
    fun record(c: Check) { checks.addLast(c); while (checks.size > 200) checks.removeFirst() }
    fun snapshot(): List<Check> = checks.toList()
    override fun status(): EngineStatus = EngineStatus(id, displayName, EngineHealth.HEALTHY,
        checks.lastOrNull()?.let { "Last: ${it.name} ${if (it.passed) "pass" else "pending/fail"} (${it.framesSeen}/${it.framesRequired})" } ?: "Ready")
}

object LearningMemoryEngine : RokEngine {
    override val id = "learning"
    override val displayName = "Engine 8: Self-Learning Memory"
    override fun status(): EngineStatus {
        val s = try { AdaptiveLearning.summary(Templates.folder()) } catch (_: Exception) { "Not initialized" }
        RuntimeState.learningStatus = s.lines().firstOrNull() ?: s
        return EngineStatus(id, displayName, EngineHealth.HEALTHY, RuntimeState.learningStatus)
    }
}

object TemplateGenerationEngine : RokEngine {
    override val id = "template_generation"
    override val displayName = "Engine 9: Automatic Template Generation"
    data class Candidate(val category: String, val source: String, val proposedPath: String, val status: String, val note: String, val time: Long = System.currentTimeMillis())
    private val candidates = ConcurrentLinkedDeque<Candidate>()
    fun propose(c: Candidate) { candidates.addLast(c); while (candidates.size > 50) candidates.removeFirst(); AppLog.add(LogCategory.LEARNING, "Template candidate for ${c.category}: ${c.status}") }
    fun snapshot(): List<Candidate> = candidates.toList()
    override fun status(): EngineStatus = EngineStatus(id, displayName, EngineHealth.HEALTHY,
        "Candidates proposed: ${candidates.size} (user approval required before production)")
}

object AdaptivePerformanceEngine : RokEngine {
    override val id = "adaptive_performance"
    override val displayName = "Engine 10: Adaptive Performance"
    @Volatile var lastRecognitionMs: Long = 0
    @Volatile var lastLearningMs: Long = 0
    @Volatile var captureIntervalMs: Long = 350
    @Volatile var queueDepth: Int = 0
    @Volatile var note: String = "Balanced"
    fun observe(recognitionMs: Long = -1, learningMs: Long = -1) {
        if (recognitionMs >= 0) lastRecognitionMs = recognitionMs
        if (learningMs >= 0) lastLearningMs = learningMs
        // adaptive backoff: slow down if recognition is expensive
        captureIntervalMs = when {
            lastRecognitionMs > 900 -> 700
            lastRecognitionMs > 500 -> 500
            else -> 350
        }
        note = "recog ${lastRecognitionMs}ms · learn ${lastLearningMs}ms · poll ${captureIntervalMs}ms"
    }
    override fun status(): EngineStatus = EngineStatus(id, displayName, EngineHealth.HEALTHY, note,
        details = mapOf("captureIntervalMs" to captureIntervalMs.toString(), "lastRecogMs" to lastRecognitionMs.toString()))
}

object DiagnosticRecoveryEngine : RokEngine {
    override val id = "diagnostics"
    override val displayName = "Engine 12: Diagnostic & Recovery"
    data class Issue(val key: String, val description: String, val recovery: String, val time: Long = System.currentTimeMillis())
    private val issues = ConcurrentLinkedDeque<Issue>()
    fun report(key: String, description: String, recovery: String) {
        issues.addLast(Issue(key, description, recovery)); while (issues.size > 200) issues.removeFirst()
        RuntimeState.lastError = description
        AppLog.add(LogCategory.DIAGNOSTICS, "$key: $description — recovery: $recovery")
    }
    fun snapshot(): List<Issue> = issues.toList()
    fun clear() { issues.clear() }
    override fun status(): EngineStatus {
        val last = issues.lastOrNull()
        return EngineStatus(id, displayName, if (last != null && issues.size > 20) EngineHealth.DEGRADED else EngineHealth.HEALTHY,
            last?.let { "${it.key}: ${it.description}" } ?: "No active issues")
    }
}

object CompanionEngine : RokEngine {
    override val id = "companion"
    override val displayName = "Intelligent Companion"
    data class Notice(val priority: Int, val title: String, val body: String, val time: Long = System.currentTimeMillis())
    private val notices = ConcurrentLinkedDeque<Notice>()
    private val history = ConcurrentLinkedDeque<String>()
    @Volatile var muted: Boolean = false
    @Volatile var lastExplanation: String = "Companion ready. I explain what I observe from verified signals."
    private var ctxRef: java.lang.ref.WeakReference<Context>? = null
    fun init(ctx: Context) { ctxRef = java.lang.ref.WeakReference(ctx.applicationContext) }
    fun notify(priority: Int, title: String, body: String) {
        if (muted && priority < 2) return
        val n = Notice(priority, title, body)
        notices.addLast(n); while (notices.size > 100) notices.removeFirst()
        val line = "$title: $body"
        history.addLast("${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())} $line")
        while (history.size > 200) history.removeFirst()
        lastExplanation = body
        AppLog.add(LogCategory.COMPANION, line)
    }
    fun explainCurrent(): String {
        val st = RuntimeState.currentGameState
        val mode = RuntimeState.mode.label
        val cap = if (RuntimeState.captureActive) "capture active" else "capture inactive"
        val rec = RuntimeState.recognitionStatus
        val health = RuntimeState.systemHealth
        return "Mode: $mode. I observe state=$st with $cap. Recognition: $rec. System: $health (${RuntimeState.systemHealthReason}). I only report observed signals and will not claim actions that were not verified."
    }
    fun recommend(): String {
        val s = RuntimeState.currentGameState
        return when (s) {
            GameState.NO_FREE_MARCH, GameState.UNKNOWN -> if (RuntimeState.lastError?.contains("march", true)==true) "No free march appears available from recent observations. Wait for a march to return or reduce march slots." else "State is uncertain. Use recognition test and diagnostics before automation."
            GameState.NO_TROOPS -> "Troops may be unavailable. Check troop selection screen and presets manually; I will not dispatch without verified markers."
            GameState.RESOURCE_NOT_FOUND -> "Search target was not found. Try a different resource, adjust priorities, or recapture templates/ROIs for search results."
            GameState.POPUP -> "An unexpected popup/state is visible. I recommend stopping automated taps and reviewing the diagnostic screenshot."
            else -> "If recognition is uncertain, recapture the relevant template/ROI and run a recognition test in Observer mode."
        }
    }
    fun noticesSnapshot(): List<Notice> = notices.toList()
    fun historySnapshot(): List<String> = history.toList()
    override fun status(): EngineStatus = EngineStatus(id, displayName, EngineHealth.HEALTHY,
        if (muted) "Muted" else "Active · ${notices.size} notices")
}
