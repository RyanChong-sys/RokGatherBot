package com.example.rokbot

import android.os.SystemClock
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

/** Logical engine module - not an Android Service. */
interface RokEngine {
    val id: String
    val displayName: String
    fun status(): EngineStatus
    fun start() {}
    fun stop() {}
}

enum class EngineHealth { HEALTHY, DEGRADED, STOPPED, ERROR, UNKNOWN }

data class EngineStatus(
    val id: String,
    val displayName: String,
    val health: EngineHealth,
    val summary: String,
    val lastUpdatedMs: Long = SystemClock.elapsedRealtime(),
    val details: Map<String, String> = emptyMap()
)

enum class OperationMode(val label: String, val allowsAutoActions: Boolean) {
    OBSERVER("Observer", false),
    ASSISTANT("Assistant", false),
    SUPERVISED("Supervised Automation", true);
    companion object { fun fromName(name: String?): OperationMode = values().firstOrNull { it.name == name } ?: OBSERVER }
}

enum class LogCategory { SYSTEM, CAPTURE, RECOGNITION, LEARNING, COMPANION, ACTIONS, DIAGNOSTICS, ERRORS }

data class LogEntry(val timeMs: Long, val category: LogCategory, val message: String, val level: Int = 0)

object AppLog {
    private const val MAX = 1200
    private val lines = CopyOnWriteArrayList<LogEntry>()
    @Volatile var autoFollow: Boolean = true

    fun add(category: LogCategory, message: String, level: Int = 0) {
        val e = LogEntry(System.currentTimeMillis(), category, message, level)
        lines.add(e)
        while (lines.size > MAX) lines.removeAt(0)
        // also mirror important lines to legacy BotService log for compatibility
        try { BotService.logCompat("[$category] $message") } catch (_: Throwable) {}
    }

    fun snapshot(): List<LogEntry> = lines.toList()
    fun snapshotFiltered(categories: Set<LogCategory>?): List<LogEntry> =
        if (categories == null || categories.isEmpty()) snapshot() else lines.filter { it.category in categories }
    fun clear() { lines.clear() }
    fun tail(n: Int): List<LogEntry> = lines.takeLast(n)
}

/** Consolidated system state read by UI, monitor, companion and supervisor. */
object RuntimeState {
    @Volatile var mode: OperationMode = OperationMode.OBSERVER
    @Volatile var botRunning: Boolean = false
    @Volatile var captureActive: Boolean = false
    @Volatile var capturePermissionMissing: Boolean = false
    @Volatile var lastCaptureFrameMs: Long = 0L
    @Volatile var recognitionStatus: String = "Idle"
    @Volatile var learningStatus: String = "Idle"
    @Volatile var companionStatus: String = "Ready"
    @Volatile var currentGameState: GameState = GameState.UNKNOWN
    @Volatile var lastActionOutcome: String = "-"
    @Volatile var lastError: String? = null
    @Volatile var systemHealth: EngineHealth = EngineHealth.UNKNOWN
    @Volatile var systemHealthReason: String = "Not started"
    private val engineStatuses = ConcurrentHashMap<String, EngineStatus>()

    fun updateEngine(status: EngineStatus) { engineStatuses[status.id] = status }
    fun engines(): List<EngineStatus> = engineStatuses.values.sortedBy { it.displayName }
    fun engine(id: String): EngineStatus? = engineStatuses[id]
}
