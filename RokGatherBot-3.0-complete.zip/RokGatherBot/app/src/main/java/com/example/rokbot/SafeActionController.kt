package com.example.rokbot

import android.os.SystemClock
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.atomic.AtomicInteger

/**
 * Engine 11 — Safe Action Controller. Single gate for all automated interactions.
 * BotService must consult this before proposing/dispatching actions.
 */
object SafeActionController : RokEngine {
    override val id = "action_controller"
    override val displayName = "Engine 11: Safe Action Controller"

    enum class Phase { PROPOSED, VALIDATED, PERMITTED, DISPATCHED, GESTURE_COMPLETED, GAME_RESPONSE_OBSERVED, SUCCESS, FAILURE, UNCERTAIN, CANCELLED, REJECTED }

    data class ActionRecord(
        val id: Long,
        val name: String,
        val mode: OperationMode,
        val requiredState: GameState,
        val observedState: GameState,
        val confidence: Double,
        val threshold: Double,
        var phase: Phase,
        val proposedAt: Long = System.currentTimeMillis(),
        var updatedAt: Long = System.currentTimeMillis(),
        var detail: String = "",
        var verifiedTransition: String? = null
    )

    private val seq = AtomicInteger(0)
    private val history = ConcurrentLinkedDeque<ActionRecord>()
    private val active = java.util.concurrent.ConcurrentHashMap<Long, ActionRecord>()
    @Volatile private var lastDuplicateKey: String? = null
    @Volatile private var lastDuplicateAt: Long = 0L
    @Volatile var pendingAssistantApproval: ActionRecord? = null

    fun canAutoAct(): Boolean = RuntimeState.mode.allowsAutoActions && RuntimeState.mode == OperationMode.SUPERVISED

    fun propose(name: String, requiredState: GameState, observedState: GameState, confidence: Double, threshold: Double): ActionRecord {
        val r = ActionRecord(seq.incrementAndGet().toLong(), name, RuntimeState.mode, requiredState, observedState, confidence, threshold, Phase.PROPOSED)
        active[r.id] = r
        AppLog.add(LogCategory.ACTIONS, "Action proposed: $name state=$observedState conf=${"%.3f".format(confidence)}")
        return r
    }

    fun validate(r: ActionRecord, temporalConfirmed: Boolean, targetKnown: Boolean, mappingValid: Boolean): Boolean {
        r.updatedAt = System.currentTimeMillis()
        if (!EngineSupervisor.canDispatchActions()) { reject(r, "unhealthy capture/recognition/action pipeline"); return false }
        if (r.requiredState != GameState.UNKNOWN && r.requiredState != r.observedState) { reject(r, "state mismatch ${r.observedState} != ${r.requiredState}"); return false }
        if (!targetKnown || r.confidence < r.threshold) { reject(r, "low confidence/unknown target ${"%.3f".format(r.confidence)} < ${"%.3f".format(r.threshold)}"); return false }
        if (!temporalConfirmed) { reject(r, "temporal confirmation missing"); return false }
        if (!mappingValid) { reject(r, "coordinate mapping invalid"); return false }
        val dupKey = "${r.name}:${r.observedState}:${(r.confidence*100).toInt()}"
        val now = SystemClock.elapsedRealtime()
        if (dupKey == lastDuplicateKey && now - lastDuplicateAt < 1200) { reject(r, "duplicate action prevented"); return false }
        lastDuplicateKey = dupKey; lastDuplicateAt = now
        r.phase = Phase.VALIDATED; r.detail = "validated"
        if (RuntimeState.mode == OperationMode.OBSERVER) { reject(r, "Observer mode: no automated taps"); return false }
        if (RuntimeState.mode == OperationMode.ASSISTANT) {
            pendingAssistantApproval = r
            r.phase = Phase.VALIDATED
            r.detail = "awaiting user approval"
            AppLog.add(LogCategory.ACTIONS, "Assistant approval required for ${r.name}")
            CompanionEngine.notify(1, "Approval needed", "Action '${r.name}' is ready. Approve in app to dispatch via Safe Action Controller.")
            return false
        }
        r.phase = Phase.PERMITTED
        return true
    }

    fun approvePending(): ActionRecord? = pendingAssistantApproval?.also { it.phase = Phase.PERMITTED; it.detail = "user approved"; pendingAssistantApproval = null }
    fun denyPending(reason: String = "user denied") { pendingAssistantApproval?.let { reject(it, reason); pendingAssistantApproval = null } }

    fun markDispatched(r: ActionRecord) { r.phase = Phase.DISPATCHED; r.updatedAt = System.currentTimeMillis(); AppLog.add(LogCategory.ACTIONS, "Dispatched: ${r.name}") }
    fun markGesture(r: ActionRecord, completed: Boolean, detail: String) {
        r.phase = if (completed) Phase.GESTURE_COMPLETED else Phase.FAILURE
        r.detail = detail; r.updatedAt = System.currentTimeMillis()
        AppLog.add(LogCategory.ACTIONS, "Gesture ${if (completed) "completed" else "not completed"}: ${r.name} ($detail)")
    }
    fun markGameResponse(r: ActionRecord, transition: String?, success: Boolean, uncertain: Boolean = false) {
        r.verifiedTransition = transition
        r.phase = when { success -> Phase.SUCCESS; uncertain -> Phase.UNCERTAIN; else -> Phase.FAILURE }
        r.updatedAt = System.currentTimeMillis()
        RuntimeState.lastActionOutcome = "${r.name}: ${r.phase}${transition?.let { " ($it)" } ?: ""}"
        IntelligenceMetrics.recordAction(success && !uncertain, success && transition?.contains("GATHER") == true)
        finalize(r)
    }
    fun reject(r: ActionRecord, reason: String) { r.phase = Phase.REJECTED; r.detail = reason; r.updatedAt = System.currentTimeMillis(); RuntimeState.lastActionOutcome = "${r.name}: rejected ($reason)"; AppLog.add(LogCategory.ACTIONS, "Rejected ${r.name}: $reason"); finalize(r) }
    fun cancelAll(reason: String) { pendingAssistantApproval = null; active.values.forEach { it.phase = Phase.CANCELLED; it.detail = reason; finalize(it) } }
    private fun finalize(r: ActionRecord) { active.remove(r.id); history.addLast(r); while (history.size > 300) history.removeFirst() }
    fun historySnapshot(): List<ActionRecord> = history.toList()

    override fun status(): EngineStatus = EngineStatus(id, displayName,
        if (EngineSupervisor.canDispatchActions() || RuntimeState.mode != OperationMode.SUPERVISED) EngineHealth.HEALTHY else EngineHealth.DEGRADED,
        "Mode ${RuntimeState.mode.label} · pending approval: ${pendingAssistantApproval?.name ?: "none"} · records ${history.size}")
}
