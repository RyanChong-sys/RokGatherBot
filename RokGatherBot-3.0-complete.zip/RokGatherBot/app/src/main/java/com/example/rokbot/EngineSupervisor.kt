package com.example.rokbot

import android.os.SystemClock
import java.util.concurrent.ConcurrentHashMap

/**
 * Engine 13 — Supervisor. Tracks health, coordinates priority and safe shutdown.
 * All other engines register here.
 */
object EngineSupervisor : RokEngine {
    override val id = "supervisor"
    override val displayName = "Engine 13: Supervisor"
    @Volatile private var running = false
    private val engines = ConcurrentHashMap<String, RokEngine>()

    fun register(engine: RokEngine) { engines[engine.id] = engine; RuntimeState.updateEngine(engine.status()) }
    fun get(id: String): RokEngine? = engines[id]
    fun all(): List<RokEngine> = engines.values.sortedBy { it.displayName }

    @Synchronized override fun start() {
        running = true
        AppLog.add(LogCategory.SYSTEM, "Supervisor starting ${engines.size} engines")
        // start non-dependent engines; capture/bot are user-controlled
        listOf("recognition_monitor","template_competition","adaptive_recognition","roi_discovery",
            "game_state","temporal","learning","template_generation","adaptive_performance",
            "action_controller","diagnostics","companion").forEach { id ->
            try { engines[id]?.start() } catch (e: Exception) { AppLog.add(LogCategory.ERRORS, "Engine $id start failed: ${e.message}") }
        }
        refreshHealth()
    }

    @Synchronized override fun stop() {
        running = false
        AppLog.add(LogCategory.SYSTEM, "Supervisor stopping engines")
        engines.values.filter { it.id != "supervisor" }.forEach { e ->
            try { e.stop() } catch (_: Exception) {}
        }
        refreshHealth()
    }

    fun refreshHealth() {
        var worst = EngineHealth.HEALTHY
        var reason = "All engines healthy"
        val critical = setOf("capture","recognition_monitor","action_controller","diagnostics")
        engines.values.forEach { e ->
            val st = try { e.status() } catch (ex: Exception) { EngineStatus(e.id, e.displayName, EngineHealth.ERROR, ex.message ?: "status error") }
            RuntimeState.updateEngine(st)
            if (st.health == EngineHealth.ERROR && e.id in critical) { worst = EngineHealth.ERROR; reason = "${st.displayName}: ${st.summary}" }
            else if (st.health == EngineHealth.DEGRADED && worst == EngineHealth.HEALTHY) { worst = EngineHealth.DEGRADED; reason = "${st.displayName}: ${st.summary}" }
        }
        RuntimeState.systemHealth = if (!running) EngineHealth.STOPPED else worst
        RuntimeState.systemHealthReason = if (!running) "Supervisor stopped" else reason
        RuntimeState.updateEngine(status())
    }

    fun canDispatchActions(): Boolean {
        val cap = RuntimeState.engine("capture")?.health
        val rec = RuntimeState.engine("recognition_monitor")?.health
        val act = RuntimeState.engine("action_controller")?.health
        if (cap == EngineHealth.ERROR || rec == EngineHealth.ERROR || act == EngineHealth.ERROR) return false
        if (!RuntimeState.captureActive) return false
        if (RuntimeState.systemHealth == EngineHealth.ERROR) return false
        return true
    }

    override fun status(): EngineStatus = EngineStatus(id, displayName,
        if (!running) EngineHealth.STOPPED else RuntimeState.systemHealth,
        if (!running) "Stopped" else "Coordinating ${engines.size} modules · ${RuntimeState.systemHealthReason}",
        SystemClock.elapsedRealtime(),
        mapOf("engines" to engines.size.toString(), "running" to running.toString()))
}

fun initEngineFramework(context: android.content.Context) {
    IntelligenceMetrics.load(context)
    // register all 13 logical engines (singletons)
    EngineSupervisor.register(CaptureEngineModule)
    EngineSupervisor.register(RecognitionMonitorEngine)
    EngineSupervisor.register(TemplateCompetitionEngine)
    EngineSupervisor.register(AdaptiveRecognitionEngine)
    EngineSupervisor.register(RoiDiscoveryEngine)
    EngineSupervisor.register(GameStateEngine)
    EngineSupervisor.register(TemporalVerificationEngine)
    EngineSupervisor.register(LearningMemoryEngine)
    EngineSupervisor.register(TemplateGenerationEngine)
    EngineSupervisor.register(AdaptivePerformanceEngine)
    EngineSupervisor.register(SafeActionController)
    EngineSupervisor.register(DiagnosticRecoveryEngine)
    EngineSupervisor.register(EngineSupervisor)
    CompanionEngine.init(context)
    EngineSupervisor.register(CompanionEngine)
}
