package com.example.rokbot

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import kotlin.math.abs
import kotlin.math.max

class CompanionOverlayService : Service() {
    companion object {
        @Volatile var running = false
        fun hasPermission(ctx: Context): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(ctx) else true
        fun show(ctx: Context) {
            if (!hasPermission(ctx)) { AppLog.add(LogCategory.SYSTEM, "Overlay permission missing for Companion"); return }
            ctx.startService(Intent(ctx, CompanionOverlayService::class.java))
        }
        fun hide(ctx: Context) { ctx.stopService(Intent(ctx, CompanionOverlayService::class.java)) }
    }

    private lateinit var wm: WindowManager
    private var root: View? = null
    private var params: WindowManager.LayoutParams? = null
    private val ui = Handler(Looper.getMainLooper())
    private var minimized = false
    private var expanded = false
    private var mainTv: TextView? = null
    private var histTv: TextView? = null
    private var titleTv: TextView? = null
    private var lastRawX = 0f; private var lastRawY = 0f; private var dragging = false
    private val tick = object : Runnable { override fun run() { if (running) { refresh(); ui.postDelayed(this, 1500) } } }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager; running = true
        buildUi(); ui.post(tick); AppLog.add(LogCategory.COMPANION, "Companion overlay shown")
    }
    override fun onDestroy() { running = false; ui.removeCallbacks(tick); try { root?.let { wm.removeView(it) } } catch (_: Exception) {}; root = null; AppLog.add(LogCategory.COMPANION, "Companion overlay hidden"); super.onDestroy() }

    private fun overlayType(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun buildUi() {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(0xEE121A24.toInt(), 18); setPadding(dp(10), dp(8), dp(10), dp(8)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        titleTv = TextView(this).apply { text = "Companion"; setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.DEFAULT_BOLD }
        header.addView(titleTv, LinearLayout.LayoutParams(0,-2,1f))
        fun b(txt: String, c: () -> Unit) = TextView(this).apply { text = txt; setTextColor(0xFFA8C7FF.toInt()); setPadding(dp(8),dp(4),dp(8),dp(4)); setOnClickListener { c() } }
        header.addView(b("+") { expanded = !expanded; refresh() })
        header.addView(b("_") { minimized = !minimized; refresh() })
        header.addView(b("M") { CompanionEngine.muted = !CompanionEngine.muted; AppLog.add(LogCategory.COMPANION, "Companion muted=${CompanionEngine.muted}"); refresh() })
        header.addView(b("×") { stopSelf() })
        container.addView(header)
        mainTv = TextView(this).apply { setTextColor(0xFFE3E7EE.toInt()); textSize = 11f; text = CompanionEngine.explainCurrent() }
        container.addView(mainTv)
        histTv = TextView(this).apply { setTextColor(0xFF9AA6B2.toInt()); textSize = 10f; visibility = View.GONE }
        container.addView(histTv)
        container.setOnTouchListener { v, ev -> handleDrag(v, ev) }
        root = container
        params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(300) }
        try { wm.addView(container, params) } catch (e: Exception) { AppLog.add(LogCategory.ERRORS, "Companion overlay add failed: ${e.message}") }
        refresh()
    }

    private fun handleDrag(v: View, ev: MotionEvent): Boolean {
        val p = params ?: return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dragging = false; lastRawX = ev.rawX; lastRawY = ev.rawY; return true }
            MotionEvent.ACTION_MOVE -> { val dx = ev.rawX-lastRawX; val dy = ev.rawY-lastRawY; if (!dragging && (abs(dx)+abs(dy)>dp(6))) dragging=true; if (dragging){ p.x = max(0,(p.x+dx).toInt()); p.y=max(0,(p.y+dy).toInt()); lastRawX=ev.rawX; lastRawY=ev.rawY; try{wm.updateViewLayout(root,p)}catch(_:Exception){} }; return true }
            MotionEvent.ACTION_UP -> { if (!dragging) v.performClick(); dragging=false; return true }
        }
        return false
    }

    private fun refresh() {
        val main = mainTv ?: return
        val hist = histTv ?: return
        if (minimized) { main.visibility = View.GONE; hist.visibility = View.GONE; titleTv?.text = "Companion (min)"; return }
        main.visibility = View.VISIBLE
        titleTv?.text = "Companion" + if (CompanionEngine.muted) " (muted)" else ""
        val explain = CompanionEngine.explainCurrent()
        val rec = CompanionEngine.recommend()
        val last = CompanionEngine.lastExplanation
        val notice = CompanionEngine.noticesSnapshot().lastOrNull()?.let { "${it.title}: ${it.body}" } ?: "No recent notice"
        main.text = "$explain\n\nObservation: $last\nRecommendation: $rec\nNotice: $notice"
        if (expanded) {
            hist.visibility = View.VISIBLE
            val lines = CompanionEngine.historySnapshot().takeLast(10).joinToString("\n")
            hist.text = "\nRecent:\n" + (if (lines.isBlank()) "None" else lines)
        } else hist.visibility = View.GONE
    }
}
