# RokGatherBot 3.0 — Adaptive Intelligence, In-Game Intelligence Monitor & Intelligent Companion

RokGatherBot 3.0 is an upgrade to the existing RokGatherBot 2.0 Android project. It keeps the original local, template/ROI-based recognition and verified gathering workflow, and adds a modular intelligence architecture, three operating modes, an in-game Intelligence Monitor overlay, an Intelligent Companion overlay, expanded runtime metrics, and safer action/control foundations.

**Package:** `com.example.rokbot`  
**Game:** Rise of Kingdoms (`com.lilithgame.roc.gp`)  
**Target environment:** Android 12, ARM64 (`arm64-v8a`), tested build target for Sharp AQUOS R5G / 3168×1440 landscape workflows  
**Build:** Android Gradle Plugin 8.5.2, Gradle wrapper distribution 8.7 (preserved from supplied project), compile/target SDK 34, minSdk 26, Java/Kotlin 17

## What is preserved from RokGatherBot 2.0

- Existing build configuration style and local aapt2 override workflow (no Gradle/AGP/Kotlin/SDK upgrades without demonstrated reason).
- Existing template inventory model: legacy `<id>.png` and variant folders `<id>/<variant>.png`.
- Existing ROI config (`roi_config.txt`) and per-template threshold config (`threshold_config.txt`).
- Existing adaptive learning memory (`adaptive_learning.csv`) loading/persistence in `Templates.init`/`AdaptiveLearning`; data is not overwritten with fabricated records.
- Existing screen-capture, recognition, diagnostics, template maker, and gathering settings concepts.
- Pure-Java `TemplateMatcher` and `CoordinateMapper` logic and existing JVM verification tests.

## RokGatherBot 3.0 architecture (13 logical engine modules)

Implemented as logical modules with clear responsibilities and interfaces (singletons/classes), **not** 13 Android services/processes:

| # | Engine | Status | Implementation notes |
|---|---|---|---|
| 1 | Live Screen Capture | Implemented (integrated) | `ScreenCapture` + `CaptureService` + `CaptureEngineModule`. MediaProjection lifecycle, frame timestamp tracking, stale/frozen awareness hooks, rotation/resolution metadata retained, explicit stop/release flow preserved. |
| 2 | Recognition Monitor | Implemented (integrated) | `RecognitionMonitorEngine`. Records target, confidence, threshold, template/variant, ROI, duration, accepted/rejected/ambiguous observations and recent history for UI/companion. |
| 3 | Automatic Template Competition | Implemented (foundation/integrated) | `TemplateCompetitionEngine` + existing `RecognitionEngine` multi-variant/multi-scale candidate competition, duplicate/overlap rejection, best-candidate selection and ambiguity detection. |
| 4 | Adaptive Visual Recognition | Implemented (integrated foundation) | `AdaptiveRecognitionEngine` + existing hybrid grayscale/edge matching, normalization via matcher/edge maps, multi-scale search, per-template thresholds, environment profiling hooks via `AdaptiveLearning.profile`. |
| 5 | Dynamic ROI Discovery | Implemented (foundation) | `RoiDiscoveryEngine` with event recording/rollback concept hooks; existing `RoiConfig` loading/validation preserved. Automatic ROI mutation is constrained and recorded; no arbitrary taps from ROI discovery. |
| 6 | Game State Detection | Implemented (expanded model) | `GameStateEngine` + expanded `GameState` enum (loading, search/results/selected, march preparation/dispatched/active, gathering completed, no free march/troops, resource not found, unexpected popup, unknown/error). Transition recording and explicit unknown handling. |
| 7 | Temporal Verification | Implemented (foundation + existing checks) | `TemporalVerificationEngine` records consistency checks; existing workflow already uses multi-frame/stability checks and post-action verification concepts (marker/transition checks, dialog-closed verification). Distinguishes detection/dispatch/gesture completion/game response where observable. |
| 8 | Self-Learning Memory | Implemented (preserved + extended) | Existing `AdaptiveLearning` local CSV memory preserved (verified feedback, bounded records, no source rewriting, no uploads). `LearningMemoryEngine` exposes status; `IntelligenceMetrics` tracks learning-active wall-clock time separately. |
| 9 | Automatic Template Generation | Implemented (safe foundation) | `TemplateGenerationEngine` records proposed candidates from real observations; requires user approval before production use, preserves rollback/versioning intent. Does not fabricate screenshots or auto-replace reliable templates. |
| 10 | Adaptive Performance | Implemented (foundation) | `AdaptivePerformanceEngine` monitors recognition/learning timing and adapts polling interval heuristics; bounded queues/history in new modules; avoids claiming unavailable CPU/battery measurements. |
| 11 | Safe Action Controller | Implemented (gatekeeper) | `SafeActionController` provides action lifecycle records (proposed→validated→permitted/approved→dispatched→gesture completed→game response observed→success/failure/uncertain), duplicate prevention, mode checks, cancellation, and history. Supervisor can block dispatch on unhealthy pipeline. |
| 12 | Diagnostic & Recovery Engine | Implemented (integrated foundation) | `DiagnosticRecoveryEngine` issue reporting/history + existing `Diagnostics` annotated screenshots, capture/permission/status logging, bounded diagnostics cleanup controls. |
| 13 | Engine Supervisor | Implemented | `EngineSupervisor` registers modules, starts/stops logical engines, tracks health/status, enforces dispatch gating (`canDispatchActions`), and publishes consolidated health to `RuntimeState`. |

## Three operating modes

- **Observer:** observes and learns only. No automated game taps. Bot automation start is blocked in this mode.
- **Assistant:** observes, explains, and can recommend actions, but does not run unattended automated taps without explicit approval integration. Automation start is blocked; Safe Action Controller records approval-needed actions.
- **Supervised Automation:** performs approved/configured gathering routines through the controlled action path and mode checks. Existing gathering workflow remains available in this mode.

Mode is selectable in the app, persisted in settings, and visible in the main GUI and overlays.

## In-Game Intelligence Monitor

- Movable, compact floating overlay (`MonitorOverlayService`, `SYSTEM_ALERT_WINDOW`, `TYPE_APPLICATION_OVERLAY` on Android O+).
- Controls: expand/collapse, minimize/restore, hide/close. Drag by touching the panel; does not request focus and does not intercept touches outside its controls.
- Compact view shows bot/capture/recognition/learning status, current game state, runtime, learning-active time, verified accuracy, and health.
- Expanded dashboard shows system/mode state, time & learning integrity, recognition statistics, per-category performance, verified accuracy history graph (textual bars over recorded verified points), template inventory/performance summary, all 13 engine statuses, and recent events.
- Overlay lifecycle is independent from capture and bot: hiding overlay does not stop MediaProjection; stopping bot cancels pending actions.

## Intelligent Companion

- Movable floating overlay (`CompanionOverlayService`) with contextual explanations, recommendations, notices, recent history, mute, expand/minimize/hide controls.
- Rule-based and context-aware from observed `RuntimeState`, engine status, recognition/action diagnostics, and game-state signals. No mandatory internet/external AI.
- Explains current observed state, recognition/uncertainty, mode constraints, and suggests recovery/next steps. It does not claim unobserved information or actions that did not happen.
- Notifications prioritized in logs/history; muted mode suppresses low-priority notices.

## Main application GUI (3.0)

- Dark, organized control center with mode selection, overlay permission flow, monitor/companion show/hide controls, system health/engine status dialog, and preserved setup/recognition/diagnostics/learning/gathering controls.
- Dashboard/status surfaces include runtime, capture, recognition, learning, action, and engine health signals.
- Logs remain local and inspectable; new categorized `AppLog` infrastructure (System/Capture/Recognition/Learning/Companion/Actions/Diagnostics/Errors) is added and mirrored for compatibility. Auto-follow behavior is tracked in app log state (existing log view remains available).

## Permissions and setup

1. **Accessibility Service:** enable "RoK Gather Bot 3.0" in Android Accessibility settings (required for gesture dispatch and optional UI inspection).
2. **Screen capture (MediaProjection):** grant capture permission when requested. Required for screenshot/recognition/diagnostics/automation.
3. **Display over other apps (overlay):** grant for Intelligence Monitor and Companion overlays shown above Rise of Kingdoms. If denied, the app explains and opens overlay settings.
4. **Notifications:** used for foreground/capture service behavior where applicable on supported Android versions.
5. **No root, no game memory reading, no client modification, no anti-cheat bypass.**

## Usage

1. Open RokGatherBot 3.0 and select mode (**Observer** recommended first).
2. Grant Accessibility, Screen Capture, and Overlay permissions as needed.
3. Prepare templates and ROIs from real game screenshots in Template Maker; verify inventory and run recognition tests (no taps).
4. Open Intelligence Monitor and Companion overlays while in Rise of Kingdoms landscape.
5. Use **Assistant** for explanations/recommendations and **Supervised Automation** only after verified templates/ROIs/states and one-march-slot validation.

## Build

Known working command (preserved intent; use available aarch64 `aapt2` on device):

```sh
sh gradlew -Pandroid.aapt2FromMavenOverride="$HOME/android-sdk/build-tools/36.0.0/aapt2" :app:assembleDebug --console=plain
```

On this environment, a compatible aarch64 `aapt2` override was required (Gradle-fetched aapt2 may be x86_64). Example successful build used the installed aarch64 `aapt2` binary and Gradle 8.7.

## Testing

Run JVM verification tests (no Android device required):

```sh
bash verify/run_tests.sh
bash verify/kotlin/run_adaptive_smoke.sh   # requires kotlinc
```

Real-device/in-game verification is still required for MediaProjection behavior, accessibility gestures, overlay interaction above Rise of Kingdoms, actual recognition on live screenshots, and supervised gathering outcomes.

## Safety and transparency

- Never claims a test/build/action succeeded without actual tool/runtime evidence.
- Distinguishes detection, gesture dispatch, Android gesture completion, and verified game-state transition.
- Observer mode performs no automated taps; Assistant requires approval; no unrestricted autonomous mode.
- Learning data and diagnostics are stored locally; no uploads by default.
- No invented accuracy/learning hours/intelligence scores. Learning-active time is wall-clock while eligible learning work is active (not summed across parallel engines). Verified accuracy is reported only from verified examples.
