# RokGatherBot 2.0 — Test and Verification Report

Verification date: 2026-11-12

## Executed successfully

| Test | Result | Scope |
|---|---:|---|
| Original Java matcher suite | 16 passed, 0 failed | Exact/phase-shifted image matching, noise/brightness changes, absent/flat/oversized templates, ROI constraints, decoy glyphs, ARGB conversion, downscaling and bounds |
| Hybrid recognition + coordinate suite | 12 passed, 0 failed | Multi-scale ROI matching, brightness/contrast changes, strongly darkened scene fallback, edge stability, competing detections, portrait/rotation rejection and tap bounds |
| Adaptive-learning Kotlin smoke test | Passed | Uses the real `TemplateMatcher.Gray` Java class plus small stubs for app services; tests brightness profile, minimum sample gate, overlap rejection, conservative calibration, feedback review, unique sample IDs and disabled mode |
| XML validation | Passed | `AndroidManifest.xml`, `styles.xml` and `accessibility_config.xml` parse correctly |
| Kotlin syntax scan of modified UI files | No parser diagnostics | `MainActivity.kt` and `TemplateMakerActivity.kt`; this is syntax-only, not Android framework type-checking |
| ZIP validation | Passed | `unzip -t RokGatherBot-2.0.zip` reported no compressed-data errors |

Commands run:

```sh
sh verify/run_tests.sh
sh verify/kotlin/run_adaptive_smoke.sh
```

The matcher suite took approximately 73 ms for its 2400x1080 desktop-JVM timing case. This is **not** a measurement of the AQUOS R5G; phone performance must be benchmarked on the device.

## Not performed

- `:app:assembleDebug` or APK generation.
- Full Kotlin/Java compilation against Android SDK 34 / Android 12 framework APIs.
- Emulator or physical-device testing of the redesigned screens, bottom navigation, touch scrolling, Template Studio, accessibility or MediaProjection.
- Live Rise of Kingdoms day/night recognition, state classification, gesture completion or gathering workflow.
- Battery, memory, CPU and sustained thermal measurements on the Sharp AQUOS R5G.

This environment has no Android `android.jar`, Android SDK or installed Gradle executable. The project archive also does not contain `gradlew`, `gradlew.bat` or `gradle-wrapper.jar`; only the existing `gradle-wrapper.properties` is present. Therefore a full Android build cannot be claimed here. Build in Code on the Go using its task runner and run `:app:assembleDebug`.

## Interpretation and safety limits

- The 28 passing Java tests validate the platform-independent matcher and coordinate-mapping logic, not the Android app as a whole.
- The adaptive-learning smoke test validates the learning store/calibration rules with service stubs, not an Android service integration.
- Environment profiles are coarse frame-wide luma/contrast buckets, not a perfect semantic detector for game daytime/nighttime/weather.
- Threshold calibration needs at least five reviewed positive and five reviewed negative **scored candidates** for the same template and environment, with a minimum 0.045 score gap. Overlapping evidence leaves the original threshold unchanged. No-candidate false negatives are recorded for review but cannot calibrate a numeric threshold because they have no candidate score.
- No neural network, OCR dependency or TFLite model is included. The recognition provider interface remains the extension point for a future model after device benchmarking.
- No real-game screenshot/template set was included in the source archive. Preserve the current device's `Android/data/com.example.rokbot/files/templates/` folder, including PNG variants, `roi_config.txt`, `threshold_config.txt` and adaptive-learning history, before uninstalling or clearing app data.

Before enabling automation on the phone, use one march slot, confirm the accessibility/capture status, run the no-tap recognition test in each relevant game interface, inspect annotated screenshots, and confirm that state transitions and gesture callbacks behave as expected.
