package com.example.rokbot

import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** ROI file format: one line per identifier, for example btn_search=0.00,0.00,0.35,1.00. */
object RoiConfig {
    private val regions = linkedMapOf<String, NormalizedRoi>()
    private var loadedFrom: String? = null
    private var loadedModified: Long = -1L

    @Synchronized
    fun load(templateFolder: File) {
        val file = File(templateFolder, "roi_config.txt")
        if (loadedFrom == file.absolutePath && loadedModified == file.lastModified()) return
        regions.clear()
        if (file.isFile) {
            file.readLines().forEachIndexed { index, raw ->
                val line = raw.substringBefore('#').trim()
                if (line.isEmpty()) return@forEachIndexed
                val parts = line.split('=', limit = 2)
                if (parts.size != 2) {
                    BotService.log("ROI config line ${index + 1} ignored: expected name=left,top,right,bottom")
                    return@forEachIndexed
                }
                val values = parts[1].split(',').mapNotNull { it.trim().toFloatOrNull() }
                if (values.size != 4) {
                    BotService.log("ROI config line ${index + 1} ignored: expected four numeric boundaries")
                    return@forEachIndexed
                }
                try {
                    val roi = NormalizedRoi(values[0], values[1], values[2], values[3])
                    roi.validate()
                    regions[parts[0].trim()] = roi
                } catch (e: Exception) {
                    BotService.log("ROI config line ${index + 1} rejected: ${e.message}")
                }
            }
        }
        loadedFrom = file.absolutePath
        loadedModified = file.lastModified()
        BotService.log(if (regions.isEmpty()) "ROI config: none; matching uses full-frame fallback" else
            "ROI config loaded for ${regions.keys.joinToString()}")
    }

    @Synchronized
    fun get(name: String): NormalizedRoi? = regions[name]

    @Synchronized
    fun description(name: String): String = regions[name]?.let {
        "normalized [${it.left},${it.top},${it.right},${it.bottom}]"
    } ?: "full frame (no calibrated ROI)"

    @Synchronized
    fun pixels(name: String, width: Int, height: Int): IntArray? = regions[name]?.toPixels(width, height)

    @Synchronized
    fun all(): Map<String, NormalizedRoi> = regions.toMap()

    @Synchronized
    fun set(templateFolder: File, name: String, roi: NormalizedRoi) {
        require(name.matches(Regex("[A-Za-z0-9_-]{1,60}"))) { "invalid template identifier" }
        roi.validate()
        regions[name] = roi
        val file = File(templateFolder, "roi_config.txt")
        val output = buildString {
            appendLine("# Normalized regions derived from a real screenshot. Keep the target inside each ROI.")
            regions.toSortedMap().forEach { (id, value) ->
                appendLine("$id=${value.left},${value.top},${value.right},${value.bottom}")
            }
        }
        file.writeText(output)
        loadedFrom = file.absolutePath
        loadedModified = file.lastModified()
        BotService.log("Search ROI saved for '$name': ${description(name)}")
    }
}


/** Per-button threshold overrides are stored beside templates and remain optional. */
object ThresholdConfig {
    private var loadedFrom: String? = null
    private var loadedModified: Long = -1L

    @Synchronized
    fun load(templateFolder: File) {
        val file = File(templateFolder, "threshold_config.txt")
        if (loadedFrom == file.absolutePath && loadedModified == file.lastModified()) return
        Config.thresholdOverrides.clear()
        if (file.isFile) file.readLines().forEachIndexed { index, raw ->
            val line = raw.substringBefore('#').trim()
            if (line.isEmpty()) return@forEachIndexed
            val parts = line.split('=', limit = 2)
            val value = parts.getOrNull(1)?.trim()?.toDoubleOrNull()
            if (parts.size != 2 || value == null || !value.isFinite() || value !in 0.50..0.99 || parts[0].isBlank()) {
                BotService.log("Threshold config line ${index + 1} ignored: expected identifier=0.50..0.99")
            } else {
                Config.thresholdOverrides[parts[0].trim()] = value
            }
        }
        loadedFrom = file.absolutePath
        loadedModified = file.lastModified()
        if (Config.thresholdOverrides.isNotEmpty()) BotService.log("Per-template thresholds loaded: ${Config.thresholdOverrides.keys.joinToString()}")
    }
}

data class RecognitionCandidate(
    val templateId: String,
    val file: String,
    val scale: Float,
    val score: Double,
    val match: TemplateMatcher.Match,
)

data class RecognitionResult(
    val templateId: String,
    val threshold: Double,
    val candidates: List<RecognitionCandidate>,
    val accepted: Boolean,
    val ambiguous: Boolean,
    val reason: String,
) {
    val best: RecognitionCandidate? get() = candidates.firstOrNull()
}

/** Stable injection point for a future TFLite/object detector; automation consumes boxes and scores. */
interface RecognitionProvider {
    fun recognize(
        frame: TemplateMatcher.HybridFrame,
        templateId: String,
        threshold: Double,
        region: IntArray?,
        scaleFactors: List<Float> = Config.scaleFactors,
    ): RecognitionResult
}

/** Multi-variant, bounded multi-scale, grayscale + edge matcher. */
object RecognitionEngine : RecognitionProvider {
    override fun recognize(
        frame: TemplateMatcher.HybridFrame,
        templateId: String,
        threshold: Double,
        region: IntArray?,
        scaleFactors: List<Float>,
    ): RecognitionResult {
        val environment = AdaptiveLearning.profile(frame.gray)
        val activeThreshold = AdaptiveLearning.calibratedThreshold(
            Templates.folder(), templateId, environment.key, threshold
        ) ?: threshold
        val variants = Templates.variants(templateId)
        if (variants.isEmpty()) {
            return RecognitionResult(templateId, activeThreshold, emptyList(), false, false, "missing or undecodable template")
        }
        val candidates = mutableListOf<RecognitionCandidate>()
        for (variant in variants) {
            try {
                TemplateMatcher.validate(variant.gray)
            } catch (e: Exception) {
                BotService.log("Template rejected: ${variant.file.name}: ${e.message}")
                continue
            }
            for (scale in scaleFactors.distinct()) {
                if (!scale.isFinite() || scale !in 0.75f..1.25f) continue
                val width = max(8, (variant.gray.w * scale).toInt())
                val height = max(8, (variant.gray.h * scale).toInt())
                val scaled = if (width == variant.gray.w && height == variant.gray.h) variant.gray
                    else TemplateMatcher.resize(variant.gray, width, height)
                val edges = if (scaled === variant.gray) variant.edges else TemplateMatcher.edgeMap(scaled)
                if (region != null && (region.size != 4 || region[2] - region[0] < width || region[3] - region[1] < height)) {
                    continue
                }
                val match = try {
                    TemplateMatcher.findHybridBest(frame, scaled, edges, activeThreshold, region)
                } catch (e: IllegalArgumentException) {
                    null
                } ?: continue
                candidates += RecognitionCandidate(
                    templateId, variant.file.relativeTo(Templates.folder()).path,
                    scale, match.score, match
                )
            }
        }
        // The low-cost primary pass returns one best hit per variant/scale. Probe four strips
        // around the global winner to catch a second identical button on the same screen.
        val primary = candidates.maxByOrNull { it.score }
        if (primary != null) {
            val variant = variants.firstOrNull {
                it.file.relativeTo(Templates.folder()).path == primary.file
            }
            if (variant != null) {
                val width = max(8, (variant.gray.w * primary.scale).toInt())
                val height = max(8, (variant.gray.h * primary.scale).toInt())
                val scaled = if (width == variant.gray.w && height == variant.gray.h) variant.gray
                    else TemplateMatcher.resize(variant.gray, width, height)
                val edges = if (scaled === variant.gray) variant.edges else TemplateMatcher.edgeMap(scaled)
                val hits = TemplateMatcher.findHybridCandidates(frame, scaled, edges, activeThreshold, region, 2)
                hits.drop(1).forEach { match ->
                    candidates += RecognitionCandidate(primary.templateId, primary.file, primary.scale, match.score, match)
                }
            }
        }

        val ranked = candidates.sortedByDescending { it.score }
        val unique = mutableListOf<RecognitionCandidate>()
        for (candidate in ranked) {
            val sameSpot = unique.any { existing ->
                intersectionOverUnion(existing.match, candidate.match) >= 0.35 ||
                    distance(existing.match, candidate.match) <
                    max(8.0, minOf(existing.match.width, existing.match.height) * 0.45)
            }
            if (!sameSpot) unique += candidate
        }
        val best = unique.firstOrNull()
        val second = unique.drop(1).firstOrNull()
        val ambiguous = best != null && second != null && second.score >= activeThreshold &&
            best.score - second.score < 0.07
        val accepted = best != null && best.score >= activeThreshold && !ambiguous
        val reason = when {
            best == null -> "no candidate in region"
            ambiguous -> "multiple competing detections (${"%.3f".format(best.score)}, ${"%.3f".format(second!!.score)})"
            best.score < activeThreshold -> "weak (${"%.3f".format(best.score)} < ${"%.3f".format(activeThreshold)})"
            else -> "accepted"
        }
        return RecognitionResult(templateId, activeThreshold, unique, accepted, ambiguous, reason)
    }


    private fun distance(a: TemplateMatcher.Match, b: TemplateMatcher.Match): Double {
        val dx = (a.centerX - b.centerX).toDouble()
        val dy = (a.centerY - b.centerY).toDouble()
        return sqrt(dx * dx + dy * dy)
    }

    private fun intersectionOverUnion(a: TemplateMatcher.Match, b: TemplateMatcher.Match): Double {
        val left = max(a.x, b.x)
        val top = max(a.y, b.y)
        val right = min(a.x + a.width, b.x + b.width)
        val bottom = min(a.y + a.height, b.y + b.height)
        val intersection = max(0, right - left) * max(0, bottom - top)
        val union = a.width * a.height + b.width * b.height - intersection
        return if (union <= 0) 0.0 else intersection.toDouble() / union
    }

}


/**
 * Single automation-facing provider seam. A future TFLite detector can be installed here while
 * BotService and the state/gesture logic continue consuming the same RecognitionResult contract.
 */
object RecognitionRouter {
    @Volatile var provider: RecognitionProvider = RecognitionEngine

    fun recognize(
        frame: TemplateMatcher.HybridFrame,
        templateId: String,
        threshold: Double,
        region: IntArray?,
        scaleFactors: List<Float> = Config.scaleFactors,
    ): RecognitionResult = provider.recognize(frame, templateId, threshold, region, scaleFactors)
}

