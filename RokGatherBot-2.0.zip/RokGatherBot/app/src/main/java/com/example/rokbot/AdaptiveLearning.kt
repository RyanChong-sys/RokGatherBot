package com.example.rokbot

import java.io.File
import java.io.FileOutputStream
import java.lang.ref.WeakReference
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Local-only adaptive recognition memory.
 *
 * The engine never treats an unlabelled match as truth. Diagnostic observations are saved with
 * their lighting profile and can be reviewed by the user. Threshold calibration only activates
 * when a button/environment pair has enough confirmed positives and negatives with a clear gap.
 * No screenshots are uploaded and no original templates are overwritten.
 */
data class EnvironmentProfile(
    val key: String,
    val meanLuma: Double,
    val contrast: Double,
) {
    val description: String get() = "$key · brightness ${meanLuma.toInt()} · contrast ${contrast.toInt()}"
}

data class LearningObservation(
    val timestamp: Long,
    val templateId: String,
    val environment: String,
    val meanLuma: Double,
    val contrast: Double,
    val score: Double,
    val baseThreshold: Double,
    val accepted: Boolean,
    val x: Int,
    val y: Int,
    val feedback: Int?, // null=pending, 1=correct/target present, 0=incorrect/target absent
) {
    val hasCandidate: Boolean get() = x >= 0 && y >= 0
}

object AdaptiveLearning {
    private const val FILE_NAME = "adaptive_learning.csv"
    private const val MAX_RECORDS = 2000
    private const val MIN_LABELS_PER_CLASS = 5
    private const val MIN_SEPARATION = 0.045

    @Volatile var enabled: Boolean = true
    private val records = mutableListOf<LearningObservation>()
    private var loadedPath: String? = null
    private var lastTimestamp: Long = 0L
    private var profileFrame = WeakReference<TemplateMatcher.Gray>(null)
    private var cachedProfile: EnvironmentProfile? = null

    /** Sample up to ~60k pixels once per frame; all template checks reuse this profile. */
    @Synchronized
    fun profile(gray: TemplateMatcher.Gray): EnvironmentProfile {
        if (profileFrame.get() === gray) cachedProfile?.let { return it }
        val count = gray.px.size
        if (count == 0) return EnvironmentProfile("UNKNOWN", 0.0, 0.0)
        val stride = max(1, count / 60_000)
        var sum = 0.0
        var sumSq = 0.0
        var n = 0
        var i = 0
        while (i < count) {
            val value = (gray.px[i].toInt() and 0xFF).toDouble()
            sum += value
            sumSq += value * value
            n++
            i += stride
        }
        val mean = sum / n
        val variance = (sumSq / n - mean * mean).coerceAtLeast(0.0)
        val contrast = sqrt(variance)
        val light = when {
            mean < 78.0 -> "DARK"
            mean > 178.0 -> "BRIGHT"
            else -> "NORMAL"
        }
        val contrastBand = if (contrast < 34.0) "LOW_CONTRAST" else "NORMAL_CONTRAST"
        val profile = EnvironmentProfile("${light}_$contrastBand", mean, contrast)
        profileFrame = WeakReference(gray)
        cachedProfile = profile
        return profile
    }

    @Synchronized
    fun load(templateFolder: File) {
        val path = File(templateFolder, FILE_NAME).absolutePath
        if (loadedPath == path) return
        records.clear()
        val file = File(path)
        if (file.isFile) {
            file.forEachLine { line -> parse(line)?.let { records += it } }
        }
        while (records.size > MAX_RECORDS) records.removeAt(0)
        lastTimestamp = records.maxOfOrNull { it.timestamp } ?: 0L
        loadedPath = path
    }

    @Synchronized
    fun record(
        templateFolder: File,
        templateId: String,
        profile: EnvironmentProfile,
        score: Double,
        threshold: Double,
        accepted: Boolean,
        x: Int = -1,
        y: Int = -1,
        trustedCorrect: Boolean? = null,
    ) {
        if (!enabled) return
        load(templateFolder)
        if (!templateId.matches(Regex("[A-Za-z0-9_-]{1,60}"))) return
        // Ensure stable unique review keys even when several templates are recorded in one ms.
        val timestamp = maxOf(System.currentTimeMillis(), lastTimestamp + 1L)
        lastTimestamp = timestamp
        val observation = LearningObservation(
            timestamp, templateId, profile.key,
            profile.meanLuma, profile.contrast,
            score.coerceIn(-1.0, 1.0), threshold.coerceIn(0.0, 1.0), accepted,
            x, y, trustedCorrect?.let { if (it) 1 else 0 }
        )
        records += observation
        if (records.size > MAX_RECORDS) records.removeAt(0)
        persist(templateFolder)
    }

    @Synchronized
    fun pending(templateFolder: File, limit: Int = 40): List<LearningObservation> {
        load(templateFolder)
        return records.asReversed().filter { it.feedback == null }.take(limit)
    }

    @Synchronized
    fun recent(templateFolder: File, limit: Int = 100): List<LearningObservation> {
        load(templateFolder)
        return records.asReversed().take(limit)
    }

    @Synchronized
    fun label(templateFolder: File, timestamp: Long, correct: Boolean): Boolean {
        load(templateFolder)
        val index = records.indexOfLast { it.timestamp == timestamp }
        if (index < 0 || records[index].feedback != null) return false
        records[index] = records[index].copy(feedback = if (correct) 1 else 0)
        persist(templateFolder)
        BotService.log("Learning feedback saved: ${records[index].templateId} ${records[index].environment} = ${if (correct) "CONFIRMED" else "INCORRECT"}")
        return true
    }

    /** A verified UI transition is a trusted positive label for the button that led to it. */
    @Synchronized
    fun recordVerifiedPositive(
        templateFolder: File,
        templateId: String,
        gray: TemplateMatcher.Gray,
        score: Double,
        threshold: Double,
        x: Int,
        y: Int,
    ) {
        record(templateFolder, templateId, profile(gray), score, threshold, true, x, y, true)
    }

    /** Returns null until there is enough reviewed evidence and clear positive/negative separation. */
    @Synchronized
    fun calibratedThreshold(templateFolder: File, templateId: String, environment: String, base: Double): Double? {
        if (!enabled) return null
        load(templateFolder)
        val relevant = records.filter { it.templateId == templateId && it.environment == environment && it.feedback != null }
        val positives = relevant.filter { it.feedback == 1 && it.score >= 0.0 }.map { it.score }.sorted()
        val negatives = relevant.filter { it.feedback == 0 && it.score >= 0.0 }.map { it.score }.sortedDescending()
        if (positives.size < MIN_LABELS_PER_CLASS || negatives.size < MIN_LABELS_PER_CLASS) return null
        // Conservative boundary: every known false candidate must remain below every known true one.
        val weakestPositive = positives.first()
        val strongestNegative = negatives.first()
        if (weakestPositive - strongestNegative < MIN_SEPARATION) return null
        val proposed = (weakestPositive + strongestNegative) / 2.0
        // Never adapt below 0.70. The per-button config remains the upper/base policy when stronger.
        return proposed.coerceIn(0.70, 0.95).let { candidate ->
            // The base may be increased by learning; it may only be lowered with a fully separated set.
            if (candidate < base && weakestPositive < base) candidate else max(base, candidate)
        }
    }

    @Synchronized
    fun summary(templateFolder: File): String {
        load(templateFolder)
        val reviewed = records.count { it.feedback != null }
        val positive = records.count { it.feedback == 1 }
        val negative = records.count { it.feedback == 0 }
        val confirmedMisses = records.count { it.feedback == 1 && it.score < 0.0 }
        val falseCandidates = records.count { it.feedback == 0 && it.score >= 0.0 }
        val pending = records.size - reviewed
        val environments = records.map { it.environment }.distinct().size
        val calibrated = records.filter { it.feedback != null }.map { it.templateId to it.environment }.distinct()
            .count { (id, env) -> calibratedThreshold(templateFolder, id, env, Config.thresholdFor(id)) != null }
        return "Local samples: ${records.size} · reviewed: $reviewed · pending: $pending\n" +
            "Verified correct: $positive · incorrect: $negative · lighting profiles: $environments\n" +
            "Confirmed missed targets: $confirmedMisses · false candidate boxes: $falseCandidates\n" +
            "Safely calibrated button/profile pairs: $calibrated\n" +
            "Learning is local-only; uncertain or unlabelled matches never change thresholds."
    }

    @Synchronized
    fun reset(templateFolder: File) {
        records.clear()
        lastTimestamp = 0L
        File(templateFolder, FILE_NAME).delete()
        loadedPath = templateFolder.absolutePath + File.separator + FILE_NAME
        BotService.log("Adaptive recognition memory cleared; original templates and ROIs were kept")
    }

    private fun persist(templateFolder: File) {
        val target = File(templateFolder, FILE_NAME)
        val temp = File(templateFolder, "$FILE_NAME.tmp")
        try {
            FileOutputStream(temp).bufferedWriter().use { writer ->
                records.forEach { writer.appendLine(encode(it)) }
            }
            if (!temp.renameTo(target)) {
                target.writeText(temp.readText())
                temp.delete()
            }
            loadedPath = target.absolutePath
        } catch (e: Exception) {
            temp.delete()
            BotService.log("Adaptive learning memory save failed: ${e.message}")
        }
    }

    private fun encode(o: LearningObservation): String = listOf(
        o.timestamp.toString(), o.templateId, o.environment,
        "%.3f".format(java.util.Locale.US, o.meanLuma),
        "%.3f".format(java.util.Locale.US, o.contrast),
        "%.4f".format(java.util.Locale.US, o.score),
        "%.4f".format(java.util.Locale.US, o.baseThreshold),
        if (o.accepted) "1" else "0", o.x.toString(), o.y.toString(),
        o.feedback?.toString() ?: "-"
    ).joinToString("|")

    private fun parse(line: String): LearningObservation? {
        return try {
            val p = line.split('|')
            if (p.size != 11) null else LearningObservation(
                p[0].toLong(), p[1], p[2], p[3].toDouble(), p[4].toDouble(), p[5].toDouble(),
                p[6].toDouble(), p[7] == "1", p[8].toInt(), p[9].toInt(),
                when (p[10]) { "1" -> 1; "0" -> 0; else -> null }
            )
        } catch (_: Exception) { null }
    }
}
