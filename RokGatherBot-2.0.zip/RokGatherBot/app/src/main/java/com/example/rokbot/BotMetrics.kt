package com.example.rokbot

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Small persistent counters for monitoring across app restarts. */
object BotMetrics {
    private const val PREFS = "rokbot_gather_metrics"

    fun recordAttempt(context: Context, resource: String, result: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val edit = prefs.edit()
        edit.putInt("attempts", prefs.getInt("attempts", 0) + 1)
        when (result) {
            "OK" -> edit.putInt("dialog_transitions", prefs.getInt("dialog_transitions", 0) + 1)
            "NO_MARCHES" -> edit.putInt("no_march_slots", prefs.getInt("no_march_slots", 0) + 1)
            else -> edit.putInt("aborted", prefs.getInt("aborted", 0) + 1)
        }
        edit.putString("last_resource", resource)
            .putString("last_result", result)
            .putLong("last_attempt_at", System.currentTimeMillis())
            .apply()
    }

    fun recordRound(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putInt("rounds", prefs.getInt("rounds", 0) + 1).apply()
    }

    fun summary(context: Context): String {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lastAt = p.getLong("last_attempt_at", 0L)
        val lastTime = if (lastAt == 0L) "never" else
            SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(lastAt))
        val last = if (lastAt == 0L) "none" else
            "${p.getString("last_resource", "?")} / ${p.getString("last_result", "?")} at $lastTime"
        return "Lifetime: ${p.getInt("attempts", 0)} attempts; " +
            "${p.getInt("dialog_transitions", 0)} dialog transitions; " +
            "${p.getInt("aborted", 0)} aborted; ${p.getInt("no_march_slots", 0)} no-slot detections; " +
            "${p.getInt("rounds", 0)} rounds\nLast attempt: $last"
    }

    fun reset(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        BotService.log("Lifetime counters reset")
    }
}
