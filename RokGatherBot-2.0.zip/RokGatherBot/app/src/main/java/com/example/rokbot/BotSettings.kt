package com.example.rokbot

import android.content.Context

/** Persists user-selected resources and timing controls across app/process restarts. */
object BotSettings {
    private const val PREFS = "rokbot_gather_settings"

    fun load(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val defaultRotation = Config.rotation.joinToString(",")
        val parsed = parseRotation(prefs.getString("rotation", defaultRotation).orEmpty())
        if (parsed.isNotEmpty()) Config.rotation = parsed

        Config.maxMarches = prefs.getInt("max_marches", Config.maxMarches).coerceIn(1, 6)
        Config.threshold = prefs.getFloat("threshold", Config.threshold.toFloat()).toDouble()
            .coerceIn(0.70, 0.95)
        Config.cycleWaitMs = prefs.getLong("cycle_wait_ms", Config.cycleWaitMs)
            .coerceIn(Config.minCycleWaitMs, Config.maxCycleWaitMs)
        Config.retryWaitMs = prefs.getLong("retry_wait_ms", Config.retryWaitMs)
            .coerceIn(Config.minRetryWaitMs, Config.maxConfiguredRetryWaitMs)
        Config.maxRetryWaitMs = prefs.getLong("max_retry_wait_ms", Config.maxRetryWaitMs)
            .coerceIn(Config.retryWaitMs, Config.maxConfiguredMaxRetryWaitMs)
        Config.maxFailedRounds = prefs.getInt("max_failed_rounds", Config.maxFailedRounds).coerceIn(1, 10)
        Config.diagnosticMode = prefs.getBoolean("diagnostic_mode", false)
        AdaptiveLearning.enabled = prefs.getBoolean("adaptive_learning_enabled", true)
    }

    fun save(
        context: Context,
        rotation: List<String>,
        maxMarches: Int,
        threshold: Double,
        cycleWaitMinutes: Long,
        retryWaitMinutes: Long,
        maxRetryWaitMinutes: Long,
        maxFailedRounds: Int,
    ) {
        require(rotation.isNotEmpty() && rotation.size <= Config.maxRotationEntries)
        require(rotation.all { it in Config.resourceTabs.keys })
        require(maxMarches in 1..6)
        require(threshold in 0.70..0.95)
        require(cycleWaitMinutes in 1L..720L)
        require(retryWaitMinutes in 1L..60L)
        require(maxRetryWaitMinutes in retryWaitMinutes..360L)
        require(maxFailedRounds in 1..10)

        Config.rotation = rotation.toList()
        Config.maxMarches = maxMarches
        Config.threshold = threshold
        Config.cycleWaitMs = cycleWaitMinutes * 60_000L
        Config.retryWaitMs = retryWaitMinutes * 60_000L
        Config.maxRetryWaitMs = maxRetryWaitMinutes * 60_000L
        Config.maxFailedRounds = maxFailedRounds

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("rotation", rotation.joinToString(","))
            .putInt("max_marches", maxMarches)
            .putFloat("threshold", threshold.toFloat())
            .putLong("cycle_wait_ms", Config.cycleWaitMs)
            .putLong("retry_wait_ms", Config.retryWaitMs)
            .putLong("max_retry_wait_ms", Config.maxRetryWaitMs)
            .putInt("max_failed_rounds", maxFailedRounds)
            .apply()

        BotService.log("Settings saved: ${rotation.joinToString(" → ")}; $maxMarches marches; " +
            "cycle ${cycleWaitMinutes}m; retry ${retryWaitMinutes}–${maxRetryWaitMinutes}m; threshold ${"%.2f".format(threshold)}")
    }

    private fun parseRotation(value: String): List<String> = value.split(',')
        .map { it.trim().lowercase() }
        .filter { it in Config.resourceTabs.keys }
        .take(Config.maxRotationEntries)
}
