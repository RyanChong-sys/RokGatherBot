package com.example.rokbot;

/**
 * Pure-Java template matcher (no Android imports, so it is unit-testable on a plain JVM).
 *
 * score = 1 - SAD / SAD_flat, where SAD_flat is the error you would get by "predicting" the
 * template with its own mean. 1.0 = identical, ~0 = no better than a flat patch, <0 = worse.
 * That makes the threshold independent of how contrasty the template is.
 *
 * Search is coarse-to-fine (downscaled pass, then full-resolution refinement around the best
 * coarse hit). Works well for UI art: buttons, icons, popups. It is NOT designed for
 * pixel-level white noise at non-aligned offsets.
 */
public final class TemplateMatcher {
    private TemplateMatcher() {}

    /** Mean absolute deviation (0..255) a template needs; flatter ones would match anywhere. */
    public static final double MIN_CONTRAST = 6.0;

    /** How much lower than the final threshold a coarse-pass score may be and still be kept. */
    private static final double COARSE_SLACK = 0.6;

    public static final class Gray {
        public final int w, h;
        public final byte[] px;

        public Gray(int w, int h, byte[] px) {
            if (w <= 0 || h <= 0 || px.length < w * h) throw new IllegalArgumentException("bad image size");
            this.w = w; this.h = h; this.px = px;
        }

        public static Gray fromArgb(int[] argb, int w, int h) {
            byte[] out = new byte[w * h];
            for (int i = 0; i < out.length; i++) {
                int c = argb[i];
                int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
                out[i] = (byte) ((77 * r + 151 * g + 28 * b) >> 8);
            }
            return new Gray(w, h, out);
        }

        public Gray downscale(int f) {
            if (f <= 1) return this;
            int nw = w / f, nh = h / f;
            if (nw == 0 || nh == 0) throw new IllegalArgumentException("too small to downscale");
            byte[] out = new byte[nw * nh];
            int area = f * f;
            for (int y = 0; y < nh; y++) {
                for (int x = 0; x < nw; x++) {
                    int sum = 0;
                    for (int dy = 0; dy < f; dy++) {
                        int row = (y * f + dy) * w + x * f;
                        for (int dx = 0; dx < f; dx++) sum += px[row + dx] & 0xFF;
                    }
                    out[y * nw + x] = (byte) (sum / area);
                }
            }
            return new Gray(nw, nh, out);
        }
    }

    public static final class Match {
        public final int x, y;             // top-left of the match
        public final int width, height;
        public final int centerX, centerY; // where to tap
        public final double score;
        Match(int x, int y, int tw, int th, double score) {
            this.x = x; this.y = y; this.width = tw; this.height = th;
            this.centerX = x + tw / 2; this.centerY = y + th / 2; this.score = score;
        }
        @Override public String toString() { return "Match(" + x + "," + y + " score=" + String.format("%.3f", score) + ")"; }
    }

    public static Match find(Gray screen, Gray tpl, double threshold) {
        return find(screen, tpl, threshold, null);
    }

    /**
     * @param threshold minimum score, ~0.75 is a good default. Pass 0.0 to get the best
     *                  candidate for diagnostics.
     * @param region    {left, top, right, bottom} in pixels the template must lie inside, or null.
     * @return best match with score >= threshold, or null.
     * @throws IllegalArgumentException if the template is too flat to match reliably.
     */
    public static void validate(Gray tpl) {
        if (tpl == null) throw new IllegalArgumentException("template is null");
        long flat = flatSad(tpl);
        if ((double) flat / ((double) tpl.w * tpl.h) < MIN_CONTRAST)
            throw new IllegalArgumentException("template is too flat/low-contrast to match reliably");
    }

    public static Match find(Gray screen, Gray tpl, double threshold, int[] region) {
        validate(tpl);
        long flat = flatSad(tpl);

        int left = 0, top = 0, right = screen.w, bottom = screen.h;
        if (region != null) {
            left = Math.max(0, region[0]); top = Math.max(0, region[1]);
            right = Math.min(screen.w, region[2]); bottom = Math.min(screen.h, region[3]);
        }
        if (right - left < tpl.w || bottom - top < tpl.h) return null;

        // Coarse pass: the downscaled grid is only aligned to the template at 1 of f sub-pixel
        // phases, so the true spot scores worse here than it will at full resolution. Therefore
        // keep the best few distinct candidates (not just one) and judge them again at full size.
        int[] cand = null; // flattened (x, y) full-res top-left guesses
        int f = chooseFactor(tpl);
        if (f > 1) {
            Gray cs = screen.downscale(f), ct = tpl.downscale(f);
            long cFlat = flatSad(ct);
            if ((double) cFlat / ((double) ct.w * ct.h) >= MIN_CONTRAST * 0.5) {
                final int K = 6;
                long[] cSad = new long[K];
                int[] cx = new int[K], cy = new int[K];
                int n = 0;
                int cl = (left + f - 1) / f, cT = (top + f - 1) / f;
                int cr = Math.min(right / f, cs.w), cb = Math.min(bottom / f, cs.h);
                long initial = (long) Math.ceil(cFlat * (1.0 - Math.max(-1.0, threshold - COARSE_SLACK)));
                long limit = initial;
                for (int oy = cT; oy + ct.h <= cb; oy++) {
                    for (int ox = cl; ox + ct.w <= cr; ox++) {
                        long sd = sad(cs, ct, ox, oy, limit);
                        if (sd >= limit) continue;
                        int near = -1;
                        for (int i = 0; i < n; i++)
                            if (Math.abs(cx[i] - ox) <= ct.w / 2 && Math.abs(cy[i] - oy) <= ct.h / 2) { near = i; break; }
                        if (near >= 0) {
                            if (sd < cSad[near]) { cSad[near] = sd; cx[near] = ox; cy[near] = oy; }
                        } else if (n < K) {
                            cSad[n] = sd; cx[n] = ox; cy[n] = oy; n++;
                        } else {
                            int w = 0;
                            for (int i = 1; i < K; i++) if (cSad[i] > cSad[w]) w = i;
                            if (sd < cSad[w]) { cSad[w] = sd; cx[w] = ox; cy[w] = oy; }
                        }
                        if (n == K) { limit = initial; for (int i = 0; i < K; i++) limit = Math.min(limit, cSad[i]); }
                    }
                }
                if (n == 0) return null;
                // (limit above is only an upper bound for pruning; all n candidates get refined)
                cand = new int[2 * n];
                for (int i = 0; i < n; i++) { cand[2 * i] = cx[i] * f; cand[2 * i + 1] = cy[i] * f; }
            }
        }

        long best = (long) Math.floor(flat * (1.0 - threshold)) + 1; // SAD must be below this
        int mx = -1, my = -1;
        if (cand == null) {
            for (int oy = top; oy <= bottom - tpl.h; oy++) {
                for (int ox = left; ox <= right - tpl.w; ox++) {
                    long sd = sad(screen, tpl, ox, oy, best);
                    if (sd < best) { best = sd; mx = ox; my = oy; }
                }
            }
        } else {
            for (int i = 0; i < cand.length; i += 2) {
                int fy0 = Math.max(top, cand[i + 1] - f), fy1 = Math.min(bottom - tpl.h, cand[i + 1] + f);
                int fx0 = Math.max(left, cand[i] - f),    fx1 = Math.min(right - tpl.w, cand[i] + f);
                for (int oy = fy0; oy <= fy1; oy++) {
                    for (int ox = fx0; ox <= fx1; ox++) {
                        long sd = sad(screen, tpl, ox, oy, best);
                        if (sd < best) { best = sd; mx = ox; my = oy; }
                    }
                }
            }
        }
        if (mx < 0) return null;
        return new Match(mx, my, tpl.w, tpl.h, 1.0 - (double) best / flat);
    }


    /** A frame whose edge map is computed once and reused for every template in that frame. */
    public static final class HybridFrame {
        public final Gray gray;
        public final Gray edges;
        public HybridFrame(Gray gray) {
            if (gray == null) throw new IllegalArgumentException("screen frame is null");
            this.gray = gray;
            this.edges = edgeMap(gray);
        }
    }

    /** Bilinear resize for a bounded set of calibrated scale hypotheses. */
    public static Gray resize(Gray src, int newW, int newH) {
        if (src == null || newW <= 0 || newH <= 0) throw new IllegalArgumentException("invalid resize dimensions");
        if (src.w == newW && src.h == newH) return src;
        byte[] out = new byte[newW * newH];
        double sx = (double) src.w / newW, sy = (double) src.h / newH;
        for (int y = 0; y < newH; y++) {
            double fy = Math.max(0.0, Math.min(src.h - 1.0, (y + 0.5) * sy - 0.5));
            int y0 = (int) Math.floor(fy);
            int y1 = Math.min(src.h - 1, y0 + 1);
            double wy = fy - y0;
            for (int x = 0; x < newW; x++) {
                double fx = Math.max(0.0, Math.min(src.w - 1.0, (x + 0.5) * sx - 0.5));
                int x0 = (int) Math.floor(fx);
                int x1 = Math.min(src.w - 1, x0 + 1);
                double wx = fx - x0;
                int a = src.px[y0 * src.w + x0] & 255;
                int b = src.px[y0 * src.w + x1] & 255;
                int c = src.px[y1 * src.w + x0] & 255;
                int d = src.px[y1 * src.w + x1] & 255;
                double top = a * (1.0 - wx) + b * wx;
                double bot = c * (1.0 - wx) + d * wx;
                out[y * newW + x] = (byte) Math.max(0, Math.min(255, (int) Math.round(top * (1.0 - wy) + bot * wy)));
            }
        }
        return new Gray(newW, newH, out);
    }

    /**
     * Sobel structure map with a very low fixed noise floor. Magnitudes are deliberately kept
     * in their raw linear range: scoreAt performs bounded local contrast normalization at each
     * candidate, which compensates for dimming/gain changes without making the whole screenshot's
     * map scale depend on unrelated scenery elsewhere in the frame.
     */
    public static Gray edgeMap(Gray src) {
        byte[] out = new byte[src.w * src.h];
        if (src.w < 3 || src.h < 3) return new Gray(src.w, src.h, out);
        for (int y = 1; y < src.h - 1; y++) {
            int row = y * src.w;
            for (int x = 1; x < src.w - 1; x++) {
                int i = row + x;
                int p00 = src.px[i - src.w - 1] & 255, p01 = src.px[i - src.w] & 255, p02 = src.px[i - src.w + 1] & 255;
                int p10 = src.px[i - 1] & 255,                                      p12 = src.px[i + 1] & 255;
                int p20 = src.px[i + src.w - 1] & 255, p21 = src.px[i + src.w] & 255, p22 = src.px[i + src.w + 1] & 255;
                int gx = -p00 + p02 - 2 * p10 + 2 * p12 - p20 + p22;
                int gy = -p00 - 2 * p01 - p02 + p20 + 2 * p21 + p22;
                int magnitude = Math.min(255, (int) (Math.sqrt((double) gx * gx + (double) gy * gy) / 4.0));
                // Retain faint edges: night/dim filters can scale gradients down substantially.
                out[i] = (byte) (magnitude < 2 ? 0 : magnitude);
            }
        }
        return new Gray(src.w, src.h, out);
    }

    /** Contrast-normalized similarity at a known top-left coordinate (0..1). */
    public static double scoreAt(Gray screen, Gray template, int x, int y) {
        if (screen == null || template == null || x < 0 || y < 0 || x + template.w > screen.w || y + template.h > screen.h) return 0.0;
        int n = template.w * template.h;
        if (n == 0) return 0.0;
        double meanT = 0.0, meanS = 0.0;
        for (int yy = 0; yy < template.h; yy++) {
            int ti = yy * template.w, si = (y + yy) * screen.w + x;
            for (int xx = 0; xx < template.w; xx++) {
                meanT += template.px[ti + xx] & 255;
                meanS += screen.px[si + xx] & 255;
            }
        }
        meanT /= n; meanS /= n;
        double varT = 0.0, varS = 0.0;
        for (int yy = 0; yy < template.h; yy++) {
            int ti = yy * template.w, si = (y + yy) * screen.w + x;
            for (int xx = 0; xx < template.w; xx++) {
                double tv = (template.px[ti + xx] & 255) - meanT;
                double sv = (screen.px[si + xx] & 255) - meanS;
                varT += tv * tv; varS += sv * sv;
            }
        }
        if (varT < 1.0 || varS < 1.0) return 0.0;
        double contrastScale = Math.sqrt(varT / varS);
        // Clamp the photometric correction so a flat/wrong patch cannot be normalized into a hit.
        // RoK night/day filters can compress local luminance considerably. Keep a bounded but
        // wider correction range; variance checks above still reject flat/no-information patches.
        contrastScale = Math.max(0.25, Math.min(4.0, contrastScale));
        double diff = 0.0, denominator = 0.0;
        for (int yy = 0; yy < template.h; yy++) {
            int ti = yy * template.w, si = (y + yy) * screen.w + x;
            for (int xx = 0; xx < template.w; xx++) {
                double tv = template.px[ti + xx] & 255;
                double sv = ((screen.px[si + xx] & 255) - meanS) * contrastScale + meanT;
                diff += Math.abs(tv - sv);
                denominator += Math.abs(tv - meanT);
            }
        }
        if (denominator < 1.0) return 0.0;
        return Math.max(0.0, Math.min(1.0, 1.0 - diff / denominator));
    }

    /**
     * Coarse-to-fine photometric search for frames whose brightness/contrast differs enough that
     * raw SAD cannot locate the target. The coarse pass evaluates normalized similarity on a
     * downscaled frame, retains a handful of spatially distinct candidates, then refines each
     * around its full-resolution neighbourhood. Intended as a fallback, not the default pass.
     */
    public static Match findPhotometricBest(Gray screen, Gray template, int[] region) {
        validate(template);
        if (screen == null) return null;
        int left = 0, top = 0, right = screen.w, bottom = screen.h;
        if (region != null) {
            if (region.length != 4) return null;
            left = Math.max(0, region[0]); top = Math.max(0, region[1]);
            right = Math.min(screen.w, region[2]); bottom = Math.min(screen.h, region[3]);
        }
        if (right - left < template.w || bottom - top < template.h) return null;
        int factor = Math.max(2, chooseFactor(template));
        Gray searchRegion = cropGray(screen, left, top, right, bottom);
        Gray smallScreen = searchRegion.downscale(factor);
        Gray smallTemplate = template.downscale(factor);
        int l = 0, t = 0;
        int r = smallScreen.w - smallTemplate.w;
        int b = smallScreen.h - smallTemplate.h;
        if (r < l || b < t) return null;

        final int keep = 5;
        double[] scores = new double[keep];
        int[] xs = new int[keep], ys = new int[keep];
        java.util.Arrays.fill(scores, -1.0);
        int count = 0;
        for (int y = t; y <= b; y++) {
            for (int x = l; x <= r; x++) {
                double score = scoreAt(smallScreen, smallTemplate, x, y);
                if (score <= 0.0) continue;
                int duplicate = -1;
                for (int i = 0; i < count; i++) {
                    if (Math.abs(xs[i] - x) <= Math.max(1, smallTemplate.w / 2) &&
                        Math.abs(ys[i] - y) <= Math.max(1, smallTemplate.h / 2)) { duplicate = i; break; }
                }
                if (duplicate >= 0) {
                    if (score > scores[duplicate]) { scores[duplicate] = score; xs[duplicate] = x; ys[duplicate] = y; }
                    continue;
                }
                int slot = count < keep ? count++ : -1;
                if (slot < 0) {
                    slot = 0;
                    for (int i = 1; i < keep; i++) if (scores[i] < scores[slot]) slot = i;
                    if (score <= scores[slot]) continue;
                }
                scores[slot] = score; xs[slot] = x; ys[slot] = y;
            }
        }
        if (count == 0) return null;

        Match best = null;
        for (int i = 0; i < count; i++) {
            int cx = left + xs[i] * factor, cy = top + ys[i] * factor;
            int x0 = Math.max(left, cx - factor), x1 = Math.min(right - template.w, cx + factor);
            int y0 = Math.max(top, cy - factor), y1 = Math.min(bottom - template.h, cy + factor);
            for (int y = y0; y <= y1; y++) {
                for (int x = x0; x <= x1; x++) {
                    double score = scoreAt(screen, template, x, y);
                    if (best == null || score > best.score) best = new Match(x, y, template.w, template.h, score);
                }
            }
        }
        return best;
    }

    private static Gray cropGray(Gray source, int left, int top, int right, int bottom) {
        int width = right - left, height = bottom - top;
        byte[] pixels = new byte[width * height];
        for (int y = 0; y < height; y++)
            System.arraycopy(source.px, (top + y) * source.w + left, pixels, y * width, width);
        return new Gray(width, height, pixels);
    }

    /**
     * Hybrid score combines grayscale and edge structure. An edge-only fallback is attempted
     * when grayscale is weak, helping tolerate brightness/UI contrast changes without hiding
     * low-confidence matches behind a permissive threshold.
     */
    public static Match findHybrid(HybridFrame screen, Gray template, Gray templateEdges,
                                   double threshold, int[] region) {
        Match best = findHybridCandidate(screen, template, templateEdges, threshold, region);
        return best != null && best.score >= threshold ? best : null;
    }

    /** Returns the best candidate even below threshold, for diagnostic inspection. */
    public static Match findHybridBest(HybridFrame screen, Gray template, Gray templateEdges, int[] region) {
        return findHybridCandidate(screen, template, templateEdges, 0.78, region);
    }

    /** Diagnostic variant whose edge fallback is triggered by the action's own threshold. */
    public static Match findHybridBest(HybridFrame screen, Gray template, Gray templateEdges,
                                       double edgeFallbackThreshold, int[] region) {
        return findHybridCandidate(screen, template, templateEdges, edgeFallbackThreshold, region);
    }

    private static Match findHybridCandidate(HybridFrame screen, Gray template, Gray templateEdges,
                                             double edgeFallbackThreshold, int[] region) {
        validate(template);
        if (templateEdges == null) templateEdges = edgeMap(template);
        Match grayMatch = find(screen.gray, template, 0.0, region);
        Match best = scoreHybridAt(screen, template, templateEdges, grayMatch);

        // Raw SAD is efficient in ordinary conditions, but can fail to locate a night/dim frame
        // before scoreAt's photometric normalization is reached. Retry with bounded normalized
        // coarse search only when the ordinary candidate is weak.
        if (best == null || best.score < Math.max(0.55, edgeFallbackThreshold)) {
            try {
                Match photoMatch = findPhotometricBest(screen.gray, template, region);
                Match photoCandidate = scoreHybridAt(screen, template, templateEdges, photoMatch);
                if (photoCandidate != null && (best == null || photoCandidate.score > best.score)) best = photoCandidate;
            } catch (IllegalArgumentException ignored) {
                // A low-information patch is not a usable candidate.
            }
        }

        if (best == null || best.score < Math.max(0.55, edgeFallbackThreshold)) {
            try {
                Match edgeMatch = find(screen.edges, templateEdges, 0.0, region);
                Match edgeCandidate = scoreHybridAt(screen, template, templateEdges, edgeMatch);
                if (edgeCandidate == null || edgeCandidate.score < Math.max(0.55, edgeFallbackThreshold)) {
                    Match normalizedEdge = findPhotometricBest(screen.edges, templateEdges, region);
                    Match normalizedEdgeCandidate = scoreHybridAt(screen, template, templateEdges, normalizedEdge);
                    if (normalizedEdgeCandidate != null &&
                        (edgeCandidate == null || normalizedEdgeCandidate.score > edgeCandidate.score)) edgeCandidate = normalizedEdgeCandidate;
                }
                if (edgeCandidate != null && (best == null || edgeCandidate.score > best.score)) best = edgeCandidate;
            } catch (IllegalArgumentException ignored) {
                // Sparse/flat edge maps are simply unavailable; grayscale remains available.
            }
        }
        return best;
    }

    /**
     * Finds up to {@code maxCandidates} spatially distinct instances of the same template.
     * After finding the best one, four non-overlapping search strips exclude its bounding box;
     * this detects a second identical button without rescanning every pixel into a large top-K map.
     */
    public static java.util.List<Match> findHybridCandidates(HybridFrame screen, Gray template,
                                                               Gray templateEdges, int[] region,
                                                               int maxCandidates) {
        return findHybridCandidates(screen, template, templateEdges, 0.78, region, maxCandidates);
    }

    public static java.util.List<Match> findHybridCandidates(HybridFrame screen, Gray template,
                                                               Gray templateEdges, double edgeFallbackThreshold,
                                                               int[] region, int maxCandidates) {
        if (maxCandidates <= 0) return java.util.Collections.emptyList();
        int left = region == null ? 0 : Math.max(0, region[0]);
        int top = region == null ? 0 : Math.max(0, region[1]);
        int right = region == null ? screen.gray.w : Math.min(screen.gray.w, region[2]);
        int bottom = region == null ? screen.gray.h : Math.min(screen.gray.h, region[3]);
        if (right <= left || bottom <= top) return java.util.Collections.emptyList();
        Match first = findHybridBest(screen, template, templateEdges, edgeFallbackThreshold,
            new int[]{left, top, right, bottom});
        if (first == null) return java.util.Collections.emptyList();
        java.util.ArrayList<Match> results = new java.util.ArrayList<>();
        results.add(first);
        if (maxCandidates == 1) return results;

        int[][] strips = new int[][]{
            {left, top, first.x, bottom},
            {first.x + first.width, top, right, bottom},
            {left, top, right, first.y},
            {left, first.y + first.height, right, bottom}
        };
        for (int[] strip : strips) {
            if (strip[2] - strip[0] < template.w || strip[3] - strip[1] < template.h) continue;
            Match candidate = findHybridBest(screen, template, templateEdges, edgeFallbackThreshold, strip);
            if (candidate == null) continue;
            boolean duplicate = false;
            for (Match known : results) {
                int dx = Math.abs(known.centerX - candidate.centerX);
                int dy = Math.abs(known.centerY - candidate.centerY);
                if (dx < Math.min(known.width, candidate.width) * 0.45 &&
                    dy < Math.min(known.height, candidate.height) * 0.45) { duplicate = true; break; }
            }
            if (!duplicate) results.add(candidate);
        }
        results.sort((a, b) -> Double.compare(b.score, a.score));
        if (results.size() > maxCandidates) return new java.util.ArrayList<>(results.subList(0, maxCandidates));
        return results;
    }

    private static Match scoreHybridAt(HybridFrame screen, Gray template, Gray templateEdges, Match candidate) {
        if (candidate == null) return null;
        int x = candidate.x, y = candidate.y;
        double grayScore = scoreAt(screen.gray, template, x, y);
        double edgeScore = scoreAt(screen.edges, templateEdges, x, y);
        double combined = 0.45 * grayScore + 0.55 * edgeScore;
        return new Match(x, y, template.w, template.h, combined);
    }

    private static int chooseFactor(Gray t) {
        int m = Math.min(t.w, t.h);
        return m >= 32 ? 4 : (m >= 16 ? 2 : 1);
    }

    /** Error of predicting the template by its own (rounded) mean. */
    private static long flatSad(Gray t) {
        int n = t.w * t.h;
        long sum = 0;
        for (int i = 0; i < n; i++) sum += t.px[i] & 0xFF;
        int mean = (int) Math.round((double) sum / n);
        long dev = 0;
        for (int i = 0; i < n; i++) dev += Math.abs((t.px[i] & 0xFF) - mean);
        return dev;
    }

    /** Sum of absolute differences with row-level early exit once it reaches {@code limit}. */
    private static long sad(Gray s, Gray t, int ox, int oy, long limit) {
        long sum = 0;
        final byte[] sp = s.px, tp = t.px;
        for (int y = 0; y < t.h; y++) {
            int si = (oy + y) * s.w + ox, ti = y * t.w;
            for (int x = 0; x < t.w; x++) {
                int d = (sp[si + x] & 0xFF) - (tp[ti + x] & 0xFF);
                sum += d < 0 ? -d : d;
            }
            if (sum >= limit) return sum;
        }
        return sum;
    }
}
