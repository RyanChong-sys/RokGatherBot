package com.example.rokbot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Offline recognition test and locally retained annotated screenshots. */
object Diagnostics {
    private const val MAX_FILES = 25
    private const val MAX_BYTES = 40L * 1024L * 1024L

    suspend fun run(ctx: Context, saveOverlay: Boolean = false): File? {
        Templates.init(ctx)
        RoiConfig.load(Templates.folder())
        if (!ScreenCapture.active) {
            BotService.log("Test: screen capture is off")
            return null
        }
        ThresholdConfig.load(Templates.folder())
        // For an annotated capture, derive grayscale from that same Bitmap so the boxes cannot
        // drift onto a newer frame taken a few milliseconds later.
        val bitmap = if (saveOverlay) ScreenCapture.grabBitmap(ctx) else null
        val screen = bitmap?.let { bitmapToGray(it) } ?: ScreenCapture.grabGray(ctx)
        if (screen == null) {
            bitmap?.recycle()
            BotService.log("Test: no frame captured")
            return null
        }
        val frame = TemplateMatcher.HybridFrame(screen)
        val environment = AdaptiveLearning.profile(screen)
        BotService.lastEnvironmentProfile = environment.description
        val overlays = mutableListOf<Overlay>()
        val results = linkedMapOf<String, RecognitionResult>()
        BotService.log("--- Recognition diagnostic: ${screen.w}x${screen.h} ${if (screen.w > screen.h) "LANDSCAPE" else "PORTRAIT"} ---")
        BotService.log("Environment profile: ${environment.description}")

        val inventory = Templates.inventory(Config.expectedTemplates)
        inventory.filter { it.missing }.forEach { BotService.log("TEMPLATE MISSING: ${it.id}") }
        inventory.filter { it.id == "UNMAPPED FILES" }.flatMap { it.variants }
            .forEach { BotService.log("TEMPLATE NAME UNMAPPED: ${it.path}") }
        inventory.filter { it.id != "UNMAPPED FILES" }.forEach { entry ->
            entry.variants.forEach { file ->
                val verdict = if (!file.decodable) "UNREADABLE" else if (file.duplicateOf != null) "DUPLICATE" else "OK"
                BotService.log("Template inventory: ${entry.id}/${file.path} $verdict ${file.width}x${file.height}" +
                    (file.error?.let { " error=$it" } ?: "") + (file.duplicateOf?.let { " duplicateOf=$it" } ?: ""))
            }
        }

        for (name in Config.expectedTemplates.distinct()) {
            val normalized = RoiConfig.get(name)
            val roi = try { normalized?.toPixels(screen.w, screen.h) } catch (e: Exception) {
                BotService.log("$name: invalid ROI: ${e.message}")
                continue
            }
            val regionDescription = RoiConfig.description(name)
            val result = RecognitionRouter.recognize(frame, name, Config.thresholdFor(name), roi)
            results[name] = result
            val best = result.best
            val configuredThreshold = Config.thresholdFor(name)
            if (kotlin.math.abs(result.threshold - configuredThreshold) > 0.0001) {
                BotService.log("$name: verified adaptive threshold ${"%.3f".format(result.threshold)} (base ${"%.3f".format(configuredThreshold)}) for ${environment.key}")
            }
            AdaptiveLearning.record(
                Templates.folder(), name, environment, best?.score ?: -1.0, result.threshold,
                result.accepted, best?.match?.centerX ?: -1, best?.match?.centerY ?: -1
            )
            if (best == null) {
                BotService.log("$name: ${result.reason}; ROI=$regionDescription")
            } else {
                val verdict = if (result.accepted) "ACCEPTED" else "REJECTED"
                BotService.log("$name: $verdict score=${"%.3f".format(best.score)} threshold=${"%.3f".format(result.threshold)} " +
                    "variant=${best.file} scale=${best.scale} at ${best.match.x},${best.match.y} " +
                    "${best.match.width}x${best.match.height}; competing=${result.candidates.size - 1}; " +
                    "ROI=$regionDescription; ${result.reason}")
                overlays += Overlay(best.match.x, best.match.y, best.match.width, best.match.height,
                    result.accepted, "$name ${"%.2f".format(best.score)}")
                result.candidates.drop(1).take(2).forEach { candidate ->
                    overlays += Overlay(candidate.match.x, candidate.match.y, candidate.match.width,
                        candidate.match.height, false, "${candidate.file} ${"%.2f".format(candidate.score)}")
                }
            }
        }

        val detectedState = classifyState(results)
        if (BotService.instance?.running != true) BotService.lastState = detectedState
        BotService.log("Diagnostic game state: $detectedState (independent read-only classification)")
        BotService.log("Adaptive memory: ${AdaptiveLearning.summary(Templates.folder()).replace('\n', ' ')}")

        if (bitmap != null) {
            val file = saveOverlay(bitmap, overlays, ctx)
            bitmap.recycle()
            if (file != null) BotService.log("Diagnostic screenshot saved locally: ${file.absolutePath}")
            return file
        }
        return null
    }

    /**
     * Classifies the visible game interface from the results gathered in this diagnostic frame.
     * The thresholds are intentionally lower than tap thresholds: this is a label for debugging,
     * never permission to tap. Unknown is preferable to guessing.
     */
    private fun classifyState(results: Map<String, RecognitionResult>): GameState {
        fun score(id: String): Double = results[id]?.best?.score ?: 0.0
        val popupScore = listOf("popup_no_free_march", "popup_not_found", "popup_no_troops", "btn_close")
            .maxOfOrNull { score(it) } ?: 0.0
        if (popupScore >= 0.55) return GameState.POPUP
        if (score("btn_march") >= 0.62) return GameState.MARCH_CONFIRMATION
        if (score("btn_new_troops") >= 0.58) return GameState.TROOP_SELECTION
        if (score("btn_gather") >= 0.58) return GameState.RESOURCE_INFORMATION
        val tabScore = listOf("tab_food", "tab_wood", "tab_stone", "tab_gold").maxOfOrNull { score(it) } ?: 0.0
        if (score("btn_search_go") >= 0.42 && tabScore >= 0.58) return GameState.RESOURCE_SELECTION
        if (score("btn_search_go") >= 0.42) return GameState.SEARCH_PANEL
        if (score("btn_search") >= 0.68) return GameState.WORLD_MAP
        return GameState.UNKNOWN
    }

    private fun bitmapToGray(bitmap: Bitmap): TemplateMatcher.Gray {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        return TemplateMatcher.Gray.fromArgb(pixels, width, height)
    }

    private data class Overlay(
        val x: Int, val y: Int, val w: Int, val h: Int,
        val accepted: Boolean, val label: String,
    )

    private fun saveOverlay(bitmap: Bitmap, overlays: List<Overlay>, context: Context): File? {
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = maxOf(2f, bitmap.width / 900f)
            textSize = maxOf(18f, bitmap.width / 85f)
        }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            textSize = paint.textSize
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        }
        val density = bitmap.width / 1600f
        for (overlay in overlays) {
            val color = if (overlay.accepted) Color.rgb(40, 220, 100) else Color.rgb(255, 70, 70)
            paint.color = color
            textPaint.color = color
            canvas.drawRect(RectF(overlay.x.toFloat(), overlay.y.toFloat(),
                (overlay.x + overlay.w).toFloat(), (overlay.y + overlay.h).toFloat()), paint)
            val labelY = (overlay.y - 6f).coerceAtLeast(textPaint.textSize)
            canvas.drawText(overlay.label, overlay.x.toFloat(), labelY, textPaint)
        }
        // ROI rectangles are yellow and are based only on explicitly configured normalized bounds.
        for ((id, roi) in RoiConfig.all()) {
            try {
                val p = roi.toPixels(bitmap.width, bitmap.height)
                paint.color = Color.YELLOW
                paint.pathEffect = android.graphics.DashPathEffect(floatArrayOf(10f * density, 7f * density), 0f)
                canvas.drawRect(p[0].toFloat(), p[1].toFloat(), p[2].toFloat(), p[3].toFloat(), paint)
                canvas.drawText("ROI $id", p[0].toFloat() + 4f, (p[1] + textPaint.textSize).toFloat(), textPaint)
            } catch (_: Exception) { /* invalid ROI is already reported in the text log */ }
        }
        paint.pathEffect = null
        if (BotService.lastTapX >= 0f && BotService.lastTapY >= 0f) {
            val display = ScreenCapture.displayInfo(context)
            val tapX = if (display != null && display.displayWidth > 0)
                BotService.lastTapX * bitmap.width / display.displayWidth else BotService.lastTapX
            val tapY = if (display != null && display.displayHeight > 0)
                BotService.lastTapY * bitmap.height / display.displayHeight else BotService.lastTapY
            if (tapX in 0f..bitmap.width.toFloat() && tapY in 0f..bitmap.height.toFloat()) {
                paint.color = Color.CYAN
                paint.style = Paint.Style.STROKE
                canvas.drawCircle(tapX, tapY, 20f * density, paint)
                canvas.drawLine(tapX - 30f * density, tapY, tapX + 30f * density, tapY, paint)
                canvas.drawLine(tapX, tapY - 30f * density, tapX, tapY + 30f * density, paint)
            }
        }
        paint.style = Paint.Style.FILL
        paint.color = Color.BLACK
        canvas.drawRect(0f, 0f, bitmap.width.toFloat(), 45f * density, paint)
        textPaint.color = Color.WHITE
        canvas.drawText("RoK Gather Bot | ${BotService.lastState} | ${bitmap.width}x${bitmap.height} | " +
            "tap=${BotService.lastTapResult}", 12f, 31f * density, textPaint)

        val dir = Templates.diagnosticsFolder()
        if (!dir.exists() && !dir.mkdirs()) {
            BotService.log("Cannot create diagnostics folder: ${dir.absolutePath}")
            return null
        }
        cleanup(dir)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val file = File(dir, "rokdiag_$stamp.png")
        return try {
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            cleanup(dir)
            file
        } catch (e: Exception) {
            BotService.log("Diagnostic screenshot save failed: ${e.message}")
            file.delete()
            null
        }
    }

    fun clear(ctx: Context): Pair<Int, Long> {
        val dir = Templates.diagnosticsFolder()
        val files = dir.listFiles()?.filter { it.isFile && it.extension.equals("png", true) }.orEmpty()
        var bytes = 0L
        var deleted = 0
        for (file in files) {
            val length = file.length()
            if (file.delete()) { deleted++; bytes += length }
            else BotService.log("Diagnostic screenshot could not be deleted: ${file.absolutePath}")
        }
        BotService.log("Diagnostic screenshots cleared: $deleted file(s), $bytes bytes")
        return deleted to bytes
    }

    private fun cleanup(dir: File) {
        val files = dir.listFiles()?.filter { it.isFile && it.extension.equals("png", true) }
            ?.sortedByDescending { it.lastModified() }.orEmpty()
        var bytes = 0L
        files.forEachIndexed { index, file ->
            bytes += file.length()
            if (index >= MAX_FILES || bytes > MAX_BYTES) {
                bytes -= file.length()
                file.delete()
            }
        }
    }
}
