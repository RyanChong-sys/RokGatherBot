package com.example.rokbot

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder

/** Foreground service owning exactly one user-authorized MediaProjection session. */
class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.example.rokbot.action.START_CAPTURE"
        private const val CHANNEL = "capture"
        private const val NOTIFICATION_ID = 1
        @Volatile private var activeService: CaptureService? = null
        fun stopAfterProjectionEnded() { activeService?.stopSelf() }
    }

    override fun onCreate() {
        super.onCreate()
        activeService = this
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager.createNotificationChannel(
            NotificationChannel(CHANNEL, "Screen capture", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("RoK Gather Bot: screen capture is on")
            .setContentText("Use STOP SCREEN CAPTURE in the app when finished")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        // A repeated service start must not consume a second MediaProjection permission result.
        if (ScreenCapture.active) {
            BotService.log("Capture service start ignored: a projection is already active")
            return START_NOT_STICKY
        }
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = readData(intent)
        if (code == Activity.RESULT_OK && data != null) {
            try {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                val projection = manager.getMediaProjection(code, data)
                if (projection == null) {
                    BotService.log("Screen capture failed: Android returned no MediaProjection")
                    stopSelfResult(startId)
                } else {
                    val started = ScreenCapture.start(projection)
                    if (started) {
                        BotService.log("Screen capture permission accepted; projection session started")
                    } else {
                        BotService.log("Screen capture setup failed; new projection was rejected and stopped")
                        stopSelfResult(startId)
                    }
                }
            } catch (e: Exception) {
                BotService.log("Screen capture start failed: ${e.message}")
                stopSelfResult(startId)
            }
        } else {
            BotService.log("Screen capture permission missing or denied")
            stopSelfResult(startId)
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(intent: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("data", Intent::class.java)
        else intent?.getParcelableExtra<Intent>("data")

    override fun onDestroy() {
        val released = ScreenCapture.stop()
        if (released) BotService.log("Capture service destroyed; MediaProjection resources released")
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        if (activeService === this) activeService = null
        super.onDestroy()
    }
}
