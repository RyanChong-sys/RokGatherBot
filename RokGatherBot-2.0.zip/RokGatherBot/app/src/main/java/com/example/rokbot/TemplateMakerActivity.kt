package com.example.rokbot

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

/** Crop real game screenshots into correctly named template variants. */
class TemplateMakerActivity : Activity() {
    private var screenshot: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Templates.init(this)
        val bitmap = BitmapFactory.decodeFile(Templates.screenshotFile().path)
        if (bitmap == null) {
            Toast.makeText(this, "Take a screenshot first", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        screenshot = bitmap
        window.statusBarColor = Color.rgb(5, 6, 8)
        window.navigationBarColor = Color.rgb(5, 6, 8)
        val crop = CropView(this, bitmap)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(5, 6, 8))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(9))
        }
        header.addView(android.widget.TextView(this).apply {
            text = "TEMPLATE STUDIO"
            textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(241, 244, 250))
        })
        header.addView(android.widget.TextView(this).apply {
            text = "Drag around one real game control, then save its template or search region"
            textSize = 11f
            setTextColor(Color.rgb(165, 176, 194))
            setPadding(0, dp(3), 0, 0)
        })
        root.addView(header, LinearLayout.LayoutParams(-1, -2))
        val workspace = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(12, 15, 20))
            addView(crop, FrameLayout.LayoutParams(-1, -1))
        }
        root.addView(workspace, LinearLayout.LayoutParams(-1, 0, 1f))
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(10))
            setBackgroundColor(Color.rgb(16, 17, 21))
        }
        val saveRoi = studioButton("SAVE SEARCH REGION", accent = false).apply {
            setOnClickListener { chooseRoiName(bitmap, crop) }
        }
        val saveTemplate = studioButton("SAVE TEMPLATE VARIANT", accent = true).apply {
            setOnClickListener { chooseName(bitmap, crop) }
        }
        actions.addView(saveRoi, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(5) })
        actions.addView(saveTemplate, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(5) })
        root.addView(actions, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        Toast.makeText(this, "Drag a tight box around one real button or popup", Toast.LENGTH_LONG).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun studioButton(textValue: String, accent: Boolean): Button = Button(this).apply {
        text = textValue
        textSize = 10.5f
        isAllCaps = false
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setTextColor(if (accent) Color.rgb(210, 228, 255) else Color.rgb(241, 244, 250))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(if (accent) Color.rgb(36, 74, 119) else Color.rgb(25, 28, 34))
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), if (accent) Color.rgb(54, 95, 145) else Color.rgb(37, 43, 53))
        }
        stateListAnimator = null
        minHeight = dp(48)
    }

    private fun chooseName(bitmap: Bitmap, crop: CropView) {
        val rect = crop.selection()
        if (rect == null) {
            Toast.makeText(this, "Drag a box first (at least 12x12 px)", Toast.LENGTH_SHORT).show()
            return
        }
        val names = Config.expectedTemplates.distinct().map { id ->
            val count = Templates.variants(id).size
            "$id  (${count} variant${if (count == 1) "" else "s"})"
        }.toTypedArray()
        val ids = Config.expectedTemplates.distinct()
        AlertDialog.Builder(this)
            .setTitle("Choose the button this crop actually shows")
            .setItems(names) { _, index -> promptVariantName(bitmap, rect, ids[index]) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun chooseRoiName(bitmap: Bitmap, crop: CropView) {
        val rect = crop.selection()
        if (rect == null) {
            Toast.makeText(this, "Draw a larger rectangle around where the button appears", Toast.LENGTH_SHORT).show()
            return
        }
        val names = Config.expectedTemplates.distinct().toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Assign this search region to which template?")
            .setItems(names) { _, index ->
                val roi = NormalizedRoi(
                    rect.left.toFloat() / bitmap.width,
                    rect.top.toFloat() / bitmap.height,
                    rect.right.toFloat() / bitmap.width,
                    rect.bottom.toFloat() / bitmap.height,
                )
                try {
                    RoiConfig.set(Templates.folder(), names[index], roi)
                    Toast.makeText(this, "ROI saved for ${names[index]}", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "ROI save failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptVariantName(bitmap: Bitmap, rect: Rect, id: String) {
        val variantDir = File(Templates.folder(), id)
        val defaultVariant = "variant_${(variantDir.listFiles()?.count { it.extension.equals("png", true) } ?: 0) + 1}" 
        val nameInput = EditText(this).apply {
            setText(defaultVariant)
            hint = "variant_01"
            inputType = InputType.TYPE_CLASS_TEXT
            maxLines = 1
        }
        AlertDialog.Builder(this)
            .setTitle("Save new $id variant")
            .setMessage("Use a simple name (letters, numbers, underscore, hyphen). The original variants are preserved.")
            .setView(nameInput)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save crop") { _, _ ->
                val variantName = nameInput.text.toString().trim()
                if (!variantName.matches(Regex("[A-Za-z0-9_-]{1,40}"))) {
                    Toast.makeText(this, "Invalid variant filename", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (!variantDir.exists() && !variantDir.mkdirs()) {
                    Toast.makeText(this, "Cannot create template folder", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val destination = File(variantDir, "$variantName.png")
                if (destination.exists()) {
                    AlertDialog.Builder(this)
                        .setTitle("Variant already exists")
                        .setMessage("Overwrite ${destination.name}?")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Overwrite") { _, _ -> saveCrop(bitmap, rect, id, destination) }
                        .show()
                } else saveCrop(bitmap, rect, id, destination)
            }
            .show()
    }

    private fun saveCrop(bitmap: Bitmap, rect: Rect, id: String, destination: File) {
        try {
            val piece = Bitmap.createBitmap(bitmap, rect.left, rect.top, rect.width(), rect.height())
            val w = piece.width
            val h = piece.height
            try {
                FileOutputStream(destination).use { out ->
                    if (!piece.compress(Bitmap.CompressFormat.PNG, 100, out)) error("PNG encoder returned false")
                }
            } finally {
                if (!piece.isRecycled) piece.recycle()
            }
            Templates.reload()
            BotService.log("Template variant saved: $id/${destination.name} (${w}x${h})")
            Toast.makeText(this, "Saved $id/${destination.name} (${w}x$h)", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            BotService.log("Template save failed for $id: ${e.message}")
            Toast.makeText(this, "Template save failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        screenshot?.recycle()
        screenshot = null
        super.onDestroy()
    }
}

private class CropView(ctx: Context, private val bmp: Bitmap) : View(ctx) {
    private var sx = 0f
    private var sy = 0f
    private var ex = 0f
    private var ey = 0f
    private var has = false
    private val dst = RectF()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(168, 199, 255); style = Paint.Style.STROKE; strokeWidth = 4f }

    private fun layoutDst() {
        val scale = minOf(width.toFloat() / bmp.width, height.toFloat() / bmp.height)
        val w = bmp.width * scale
        val h = bmp.height * scale
        dst.set((width - w) / 2, (height - h) / 2, (width + w) / 2, (height + h) / 2)
    }

    override fun onDraw(canvas: Canvas) {
        layoutDst()
        canvas.drawBitmap(bmp, null, dst, null)
        if (has) canvas.drawRect(minOf(sx, ex), minOf(sy, ey), maxOf(sx, ex), maxOf(sy, ey), paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> { sx = event.x; sy = event.y; ex = sx; ey = sy; has = true }
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> { ex = event.x; ey = event.y }
        }
        invalidate()
        return true
    }

    fun selection(): Rect? {
        if (!has || !dst.contains(minOf(sx, ex), minOf(sy, ey)) || !dst.contains(maxOf(sx, ex), maxOf(sy, ey))) return null
        val scale = dst.width() / bmp.width
        fun toX(value: Float) = ((value - dst.left) / scale).toInt().coerceIn(0, bmp.width)
        fun toY(value: Float) = ((value - dst.top) / scale).toInt().coerceIn(0, bmp.height)
        val left = toX(minOf(sx, ex))
        val right = toX(maxOf(sx, ex))
        val top = toY(minOf(sy, ey))
        val bottom = toY(maxOf(sy, ey))
        return if (right - left >= 12 && bottom - top >= 12) Rect(left, top, right, bottom) else null
    }
}
