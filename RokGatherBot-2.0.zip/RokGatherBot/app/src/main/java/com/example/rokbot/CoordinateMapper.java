package com.example.rokbot;

/** Pure coordinate conversion shared by gesture dispatch and JVM tests. */
public final class CoordinateMapper {
    private CoordinateMapper() {}

    public static final class Point {
        public final float x, y;
        Point(float x, float y) { this.x = x; this.y = y; }
    }

    /**
     * Maps capture-frame pixels to real display pixels. Rotation must be identical: matching
     * aspect ratios alone cannot detect a 180-degree orientation change.
     */
    public static Point map(float frameX, float frameY, int frameW, int frameH,
                            int displayW, int displayH, int captureRotation, int displayRotation) {
        if (frameW <= 0 || frameH <= 0 || displayW <= 0 || displayH <= 0 ||
            !Float.isFinite(frameX) || !Float.isFinite(frameY)) return null;
        if (captureRotation != displayRotation) return null;
        double frameAspect = (double) frameW / frameH;
        double displayAspect = (double) displayW / displayH;
        double error = Math.abs(frameAspect - displayAspect) / Math.max(frameAspect, displayAspect);
        if (error > 0.015) return null;
        float x = frameX * displayW / (float) frameW;
        float y = frameY * displayH / (float) frameH;
        if (x < 0 || y < 0 || x >= displayW || y >= displayH) return null;
        return new Point(x, y);
    }
}
