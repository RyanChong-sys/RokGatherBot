package com.example.rokbot

import android.content.Context
import android.graphics.BitmapFactory
import java.io.File
import java.security.MessageDigest

/**
 * Supports both the original <templates>/<id>.png files and variant folders
 * <templates>/<id>/<variant>.png. Nothing is synthesized: every variant must be a real PNG capture.
 */
object Templates {
    data class Variant(
        val id: String,
        val file: File,
        val gray: TemplateMatcher.Gray,
        val edges: TemplateMatcher.Gray,
        val digest: String,
    )

    data class FileInfo(
        val path: String,
        val decodable: Boolean,
        val width: Int = 0,
        val height: Int = 0,
        val duplicateOf: String? = null,
        val error: String? = null,
    )

    data class InventoryEntry(
        val id: String,
        val expected: Boolean,
        val variants: List<FileInfo>,
    ) {
        val variantCount: Int get() = variants.count { it.decodable }
        val missing: Boolean get() = expected && variantCount == 0
    }

    private var dir: File? = null
    private val cache = HashMap<String, List<Variant>>()

    @Synchronized
    fun init(ctx: Context) {
        if (dir != null) return
        val d = ctx.getExternalFilesDir("templates") ?: File(ctx.filesDir, "templates")
        if (!d.exists()) d.mkdirs()
        dir = d
        AdaptiveLearning.load(d)
    }

    fun folder(): File = dir ?: error("Templates.init() not called")
    fun screenshotFile(): File = File(folder().parentFile ?: folder(), "last_screenshot.png")
    fun diagnosticsFolder(): File = File(folder().parentFile ?: folder(), "diagnostics")

    fun has(name: String): Boolean = variants(name).isNotEmpty()

    @Synchronized
    fun reload() = cache.clear()

    @Synchronized
    fun variants(name: String): List<Variant> {
        cache[name]?.let { return it }
        val root = folder()
        val files = mutableListOf<File>()
        val legacy = File(root, "$name.png")
        if (legacy.isFile) files += legacy
        val variantsDir = File(root, name)
        if (variantsDir.isDirectory) {
            variantsDir.listFiles()?.filter { it.isFile && it.extension.equals("png", true) }
                ?.sortedBy { it.name.lowercase() }?.let { files += it }
        }
        val result = files.distinctBy { it.absolutePath }.mapNotNull { file ->
            try {
                val bitmap = BitmapFactory.decodeFile(file.path) ?: return@mapNotNull null
                val w = bitmap.width
                val h = bitmap.height
                if (w < 8 || h < 8 || w.toLong() * h.toLong() > 4_000_000L) {
                    bitmap.recycle()
                    return@mapNotNull null
                }
                val pixels = IntArray(w * h)
                bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
                bitmap.recycle()
                val gray = TemplateMatcher.Gray.fromArgb(pixels, w, h)
                val digest = MessageDigest.getInstance("SHA-256").digest(gray.px)
                    .joinToString("") { "%02x".format(it) }
                Variant(name, file, gray, TemplateMatcher.edgeMap(gray), digest)
            } catch (e: Exception) {
                BotService.log("Template decode failed: ${file.name}: ${e.message}")
                null
            }
        }
        cache[name] = result
        return result
    }

    /** Legacy convenience API; callers doing multi-variant matching should use variants(). */
    fun get(name: String): TemplateMatcher.Gray? = variants(name).firstOrNull()?.gray

    fun inventory(expected: Collection<String>): List<InventoryEntry> {
        val root = folder()
        val duplicates = HashMap<String, String>()
        val entries = expected.distinct().map { id ->
            val files = mutableListOf<File>()
            val legacy = File(root, "$id.png")
            if (legacy.isFile) files += legacy
            val vdir = File(root, id)
            if (vdir.isDirectory) vdir.listFiles()?.filter { it.isFile && it.extension.equals("png", true) }
                ?.sortedBy { it.name.lowercase() }?.let { files += it }
            val infos = files.map { file ->
                val variant = variants(id).firstOrNull { it.file.absolutePath == file.absolutePath }
                if (variant == null) {
                    FileInfo(file.relativeTo(root).path, false, error = "PNG cannot be decoded or dimensions are invalid")
                } else {
                    val prior = duplicates.putIfAbsent(variant.digest, file.relativeTo(root).path)
                    FileInfo(file.relativeTo(root).path, true, variant.gray.w, variant.gray.h, prior)
                }
            }.toMutableList()
            if (vdir.isDirectory) {
                vdir.listFiles()?.filter { it.isFile && !it.extension.equals("png", true) }?.forEach { file ->
                    infos += FileInfo(file.relativeTo(root).path, false, error = "Expected a .png template variant")
                }
            }
            InventoryEntry(id, true, infos)
        }
        val known = expected.toSet()
        val unknown = root.listFiles()?.filter { file ->
            file.isFile && file.extension.equals("png", true) && file.nameWithoutExtension !in known ||
                file.isDirectory && file.name !in known
        }.orEmpty().map { FileInfo(it.relativeTo(root).path, false, error = "Unmapped template name") }
        return entries + if (unknown.isEmpty()) emptyList() else listOf(InventoryEntry("UNMAPPED FILES", false, unknown))
    }
}
