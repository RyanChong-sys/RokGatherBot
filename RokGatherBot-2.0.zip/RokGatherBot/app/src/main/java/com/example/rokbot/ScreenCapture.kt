package com.example.rokbot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlinx.coroutines.delay

/** Immutable capture/display metadata used to validate orientation and map tap coordinates. */
data class CaptureInfo(
    val frameWidth: Int,
    val frameHeight: Int,
    val displayWidth: Int,
    val displayHeight: Int,
    val captureRotation: Int,
    val displayRotation: Int,
    val densityDpi: Int,
) {
    val orientation: String get() = if (frameWidth > frameHeight) "LANDSCAPE" else "PORTRAIT"
}

/**
 * MediaProjection owner. The latest frame is retained until another arrives; all Image reads and
 * releases are serialized under one lock so a stop/rotation cannot close an Image mid-conversion.
 */
object ScreenCapture {
    private val lock = Any()
    private var workerThread: HandlerThread? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    /** Projections whose stop() threw remain tracked so a later explicit stop can retry. */
    private val stopPending = java.util.LinkedHashSet<MediaProjection>()
    private var projectionCallback: MediaProjection.Callback? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var latest: Image? = null
    private var curW = 0
    private var curH = 0
    private var curRotation = -1
    private var curDensity = 0

    val active: Boolean get() = synchronized(lock) { projection != null || stopPending.isNotEmpty() }

    @Suppress("DEPRECATION")
    fun realMetrics(ctx: Context): DisplayMetrics {
        val dm = DisplayMetrics()
        (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        return dm
    }

    @Suppress("DEPRECATION")
    fun displayRotation(ctx: Context): Int =
        (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation

    fun displayInfo(ctx: Context): CaptureInfo? {
        val dm = realMetrics(ctx)
        val rotation = displayRotation(ctx)
        return synchronized(lock) {
            val image = latest
            CaptureInfo(image?.width ?: curW, image?.height ?: curH,
                dm.widthPixels, dm.heightPixels, curRotation, rotation, dm.densityDpi)
                .takeIf { it.frameWidth > 0 && it.frameHeight > 0 }
        }
    }

    fun start(p: MediaProjection): Boolean {
        synchronized(lock) {
            if (projection === p) {
                BotService.log("Capture start ignored: this MediaProjection is already active")
                return true
            }
        }
        if (active && !stop()) {
            // This newly granted token is not adopted. Stop its projection as well, rather than
            // confusing an older pending projection with the new session.
            try {
                p.stop()
            } catch (e: Exception) {
                synchronized(lock) { stopPending.add(p) }
                BotService.log("New projection also could not be stopped after previous-session failure: ${e.message}")
            }
            BotService.log("Capture start blocked: previous MediaProjection stop is not confirmed")
            return false
        }
        val callback = object : MediaProjection.Callback() {
            override fun onStop() {
                val released = releaseResources(expected = p, stopProjection = false)
                if (released) {
                    BotService.log("MediaProjection stopped by Android; capture resources released")
                    BotService.onCaptureStopped()
                    CaptureService.stopAfterProjectionEnded()
                }
            }
        }
        synchronized(lock) {
            projection = p
            projectionCallback = callback
        }
        try {
            p.registerCallback(callback, mainHandler)
        } catch (e: Exception) {
            releaseResources(expected = p, stopProjection = true)
            BotService.log("Capture callback registration failed: ${e.message}")
            return false
        }
        return synchronized(lock) { projection === p }
    }

    /**
     * Synchronously releases capture resources and asks Android to stop all currently tracked
     * projections (normally one). Returns true only when all stop requests are confirmed; false
     * means no session existed or at least one stop request failed, in which case active remains
     * true and a later explicit stop may retry it.
     */
    fun stop(): Boolean {
        if (!active) return false
        var confirmed = true
        var attempts = 0
        while (active && attempts++ < 4) {
            if (!releaseResources(expected = null, stopProjection = true)) {
                confirmed = false
                break
            }
        }
        val released = confirmed && !active
        if (released) BotService.log("MediaProjection, VirtualDisplay and ImageReader released")
        else BotService.log("Capture shutdown not fully confirmed; one or more MediaProjection sessions remain marked active")
        return released
    }

    /** expected=null means release any active session. Called by MediaProjection.Callback otherwise. */
    private fun releaseResources(expected: MediaProjection?, stopProjection: Boolean): Boolean {
        val p: MediaProjection?
        val callback: MediaProjection.Callback?
        val threadToStop: HandlerThread?
        synchronized(lock) {
            if (expected != null && projection !== expected) return false
            p = projection ?: if (expected == null) stopPending.firstOrNull() else null
            if (p == null) return false
            callback = projectionCallback
            projection = null
            projectionCallback = null
            try { latest?.close() } catch (_: Exception) {}
            latest = null
            try { display?.release() } catch (_: Exception) {}
            display = null
            try { reader?.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
            try { reader?.close() } catch (_: Exception) {}
            reader = null
            curW = 0; curH = 0; curRotation = -1; curDensity = 0
            threadToStop = workerThread
            workerThread = null
        }
        // Keep a non-null local after leaving synchronized: Kotlin cannot smart-cast `p`
        // because it was assigned from inside the synchronized lambda.
        val activeProjection = p ?: return false
        if (callback != null) {
            try { activeProjection.unregisterCallback(callback) } catch (_: Exception) {}
        }
        try { threadToStop?.quitSafely() } catch (_: Exception) {}
        if (stopProjection) {
            try {
                activeProjection.stop()
                synchronized(lock) { stopPending.remove(activeProjection) }
                return true
            } catch (e: Exception) {
                synchronized(lock) { stopPending.add(activeProjection) }
                BotService.log("MediaProjection.stop() could not be confirmed: ${e.message}; capture remains marked active")
                return false
            }
        }
        synchronized(lock) { stopPending.remove(activeProjection) }
        return true
    }

    /** Creates/reconfigures capture surfaces when dimensions, density, or rotation changes. */
    private fun prepare(ctx: Context): Boolean {
        val dm = realMetrics(ctx)
        val rotation = displayRotation(ctx)
        var uncommittedReader: ImageReader? = null
        var newlyCreatedWorker: HandlerThread? = null
        try {
            synchronized(lock) {
                val p = projection ?: return false
                if (display != null && reader != null && dm.widthPixels == curW &&
                    dm.heightPixels == curH && dm.densityDpi == curDensity && rotation == curRotation) return true

                latest?.close(); latest = null
                val oldReader = reader
                val worker = workerThread?.takeIf { it.isAlive } ?: HandlerThread("rokbot-capture").also {
                    it.start()
                    workerThread = it
                    newlyCreatedWorker = it
                }
                val workerHandler = Handler(worker.looper)
                val newReader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 3)
                uncommittedReader = newReader
                newReader.setOnImageAvailableListener({ rd ->
                    val image = try { rd.acquireLatestImage() } catch (_: Exception) { null }
                    if (image != null) synchronized(lock) {
                        if (reader === rd && projection === p) {
                            latest?.close()
                            latest = image
                        } else {
                            image.close()
                        }
                    }
                }, workerHandler)

                val currentDisplay = display
                if (currentDisplay == null) {
                    val created = p.createVirtualDisplay(
                        "rokbot", dm.widthPixels, dm.heightPixels, dm.densityDpi,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                        newReader.surface, null, workerHandler
                    )
                    if (created == null) {
                        newReader.setOnImageAvailableListener(null, null)
                        newReader.close()
                        uncommittedReader = null
                        worker.quitSafely()
                        workerThread = null
                        newlyCreatedWorker = null
                        BotService.log("Capture prepare failed: Android did not create a VirtualDisplay")
                        return false
                    }
                    display = created
                } else {
                    currentDisplay.resize(dm.widthPixels, dm.heightPixels, dm.densityDpi)
                    currentDisplay.setSurface(newReader.surface)
                }
                reader = newReader
                uncommittedReader = null
                newlyCreatedWorker = null
                curW = dm.widthPixels
                curH = dm.heightPixels
                curDensity = dm.densityDpi
                curRotation = rotation
                try { oldReader?.setOnImageAvailableListener(null, null); oldReader?.close() } catch (_: Exception) {}
                BotService.log("Capture surface configured: ${dm.widthPixels}x${dm.heightPixels}, rotation=$rotation")
            }
        } catch (e: Exception) {
            try { uncommittedReader?.setOnImageAvailableListener(null, null); uncommittedReader?.close() } catch (_: Exception) {}
            val worker = newlyCreatedWorker
            if (worker != null) {
                synchronized(lock) {
                    if (workerThread === worker && display == null && reader == null) workerThread = null
                }
                try { worker.quitSafely() } catch (_: Exception) {}
            }
            BotService.log("Capture prepare error: ${e.message}")
            return false
        }
        return true
    }

    private suspend fun <T : Any> withFrame(ctx: Context, timeoutMs: Long, block: (Image) -> T): T? {
        val startedAt = android.os.SystemClock.uptimeMillis()
        while (android.os.SystemClock.uptimeMillis() - startedAt < timeoutMs) {
            if (!prepare(ctx)) return null
            val result = synchronized(lock) {
                val image = latest
                if (image == null || projection == null) null else try { block(image) } catch (e: Exception) {
                    BotService.log("Frame conversion failed: ${e.message}")
                    null
                }
            }
            if (result != null) return result
            delay(60)
        }
        return null
    }

    suspend fun grabGray(ctx: Context, timeoutMs: Long = 1500): TemplateMatcher.Gray? =
        withFrame(ctx, timeoutMs) { toGray(it) }

    suspend fun grabBitmap(ctx: Context, timeoutMs: Long = 2000): Bitmap? =
        withFrame(ctx, timeoutMs) { toBitmap(it) }

    private fun toGray(img: Image): TemplateMatcher.Gray {
        val plane = img.planes[0]
        val buffer = plane.buffer
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val width = img.width
        val height = img.height
        val out = ByteArray(width * height)
        for (y in 0 until height) {
            val rowBase = y * rowStride
            val outBase = y * width
            for (x in 0 until width) {
                val pos = rowBase + x * pixelStride
                val r = buffer.get(pos).toInt() and 0xFF
                val g = buffer.get(pos + 1).toInt() and 0xFF
                val b = buffer.get(pos + 2).toInt() and 0xFF
                out[outBase + x] = ((77 * r + 151 * g + 28 * b) shr 8).toByte()
            }
        }
        return TemplateMatcher.Gray(width, height, out)
    }

    private fun toBitmap(img: Image): Bitmap {
        val plane = img.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val width = img.width
        val height = img.height
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val row = IntArray(width)
        for (y in 0 until height) {
            val base = y * rowStride
            for (x in 0 until width) {
                val pos = base + x * pixelStride
                val r = buffer.get(pos).toInt() and 0xFF
                val g = buffer.get(pos + 1).toInt() and 0xFF
                val b = buffer.get(pos + 2).toInt() and 0xFF
                val a = buffer.get(pos + 3).toInt() and 0xFF
                row[x] = Color.argb(a, r, g, b)
            }
            bitmap.setPixels(row, 0, width, 0, y, width, 1)
        }
        return bitmap
    }
}
