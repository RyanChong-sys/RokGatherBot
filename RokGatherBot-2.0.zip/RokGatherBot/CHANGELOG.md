# Changelog

## Landscape gesture and capture shutdown update

- Corrected the startup log label: the worker performs template-verified accessibility gestures; it is not detection-only.
- Dispatch accessibility gestures on the Android main thread and log the matched point, coordinate mapping, and Android completion result.
- Map captured-frame coordinates to display coordinates and refuse taps when capture/display aspect ratios disagree.
- Added a STOP SCREEN CAPTURE control that is available only after the bot has stopped; it releases MediaProjection and the foreground capture service.


## Reliability upgrade

- Removed automatic coordinate-based tapping. All game taps require a detected screen template.
- Added startup checks for screen capture, resource configuration, required image files, and template contrast.
- Added runtime validation that every template fits the current captured screen size.
- Check Android gesture acceptance/completion and apply a timeout to gesture callbacks.
- Verify that the March button disappears from its original region across two consecutive samples before counting the attempt as a confirmed UI transition.
- Prevent a second March tap when the first attempt cannot be confirmed.
- Restrict popup recovery to a detected close-button template.
- Increase the in-memory activity log to 200 timestamped entries.
- Raise the default template match threshold from 0.75 to 0.78.
- Add a matcher preflight-validation test.

## Limitations

- The March confirmation detects a dialog transition. It does not independently prove that troops were dispatched or reached a resource node.
- Full Android Gradle build and device-level testing were not available in the build environment. The matcher tests and Kotlin worker/config type-check were run separately.

## Gathering features upgrade

- Added persistent gathering settings backed by Android SharedPreferences.
- Added per-resource enable/disable controls and an editable weighted rotation sequence; repeated entries increase that resource's share of march attempts.
- Added controls for march slots, template confidence threshold, normal cycle wait, initial retry wait, and empty-round stop limit.
- Required-template preflight now checks only the resources in the active rotation, while Template Maker still exposes templates for all four resources.
- Added exponential retry backoff after empty rounds, capped at 15 minutes, while retaining the configured stop-after-failures guard.
- Added persistent lifetime monitoring for attempts, dialog transitions, aborted attempts, no-march-slot detections, rounds, and the last attempt.
- Added a user-confirmed lifetime-counter reset action.
- Added per-action image-match confidence logging.

## Feature limitations

- Resource priority is a user-configured weighted rotation. The app does not inspect kingdom inventory or infer which resource is most valuable to the player.
- A dialog closing after the March tap remains a UI-transition signal, not independent proof that troops were successfully dispatched or reached a node.
- Persistent counters describe automation attempts and recognised UI transitions, not in-game resource yield.

## Hybrid recognition, state verification and capture lifecycle update

- Reworked template loading to support legacy flat PNGs plus multiple decoded variants per button identifier; inventory now reports missing, unreadable, duplicate, unmapped and non-PNG files with dimensions.
- Added bounded 0.90–1.10 multi-scale matching and a blended brightness-compensated grayscale / Sobel-edge score. Match thresholds can be overridden per identifier.
- Added normalized, user-calibrated ROIs and a template-manager option to save them from real screenshot crops. Bot start is blocked if a required template lacks a calibrated ROI; full-frame scans are reserved for read-only diagnostics.
- Added explicit game states and state-gated actions with next-state marker verification. Added a conservative AccessibilityNodeInfo fallback for unique, visible, enabled, clickable game-package nodes with expected labels and valid bounds.
- Added frame/display calibration checks; rotation, portrait orientation, display-size, and frame-size changes cancel the active workflow pending manual restart.
- Hardened gesture acknowledgement and logging, including service capability/package checks, coordinate mapping, out-of-bounds rejection, dispatch/completion/cancellation separation, timeout cooldown, and duplicate gesture prevention.
- March transition verification now checks all template variants in the original button bounds across successive frames.
- MediaProjection cleanup now unregisters its callback, closes/recycles image resources, releases VirtualDisplay/ImageReader and capture thread, requests projection stop, and retains an unconfirmed stop state if Android throws. Android projection revocation also stops the bot.
- Added local annotated diagnostic captures with bounding boxes, candidate scores, ROIs, current state, and last tap marker; capped at 25 files / 40 MB and added a clear action.
- Added a configurable maximum retry delay while retaining finite exponential retry waits.
- Expanded the platform-independent tests to 26 total passing assertions, including detection of multiple competing instances of one template. Full Android build, emulator and physical-device testing remain outstanding because the supplied archive lacks Gradle wrapper bootstrap files and this environment lacks the Android SDK.

## Known missing inputs / verification limits

- The supplied ZIP did not include any game template PNGs or screenshots; `btn_search` image mismatch cannot be diagnosed against actual game pixels until those are captured on-device.
- Offline OCR and TFLite inference are not packaged. The accessibility hierarchy and `RecognitionProvider` extension point are included, but OCR/model integration awaits verification with the user's Android build environment.
- The ZIP's Gradle wrapper property is 8.7 (not the 9.6.1 stated in the project request), and wrapper scripts/JAR are absent. The uploaded build configuration was preserved.


## Final review fixes

- Capture start now returns an explicit success result for the exact newly authorized projection instead of inferring success from a shared active flag. Rejected sessions are stopped; projections whose stop call fails remain tracked for retry; explicit stop drains tracked sessions up to a safe bounded limit.
- Diagnostic mode records every recognition polling result, including no-candidate/rejected searches.
- Template crop bitmaps are recycled even when PNG encoding fails.
- Status screen now explicitly reports configured march slots and active workflow step.
- Added `TEST_REPORT.md` with actual executed tests and device/build limitations.

## 2026-11-12 — ScreenCapture Kotlin nullability hotfix

- Fixed `ScreenCapture.releaseResources()` compilation errors where `MediaProjection?` was used as though it were non-null after assignment inside a `synchronized` block.
- Added an explicit non-null local (`activeProjection`) after the lock-protected selection. Callback unregister, `stop()`, and pending-stop bookkeeping now consistently use that validated reference.
- Preserved the existing failure behavior: a failed `MediaProjection.stop()` remains tracked in `stopPending` and is not reported as a confirmed stop.
- Re-ran the platform-independent matcher/coordinate test suite: 26/26 passed. A full Android Gradle build was not run in this environment.

## UI refresh — dark control center

- Replaced the default light, text-heavy screen with a dark Material theme and a custom no-action-bar header.
- Grouped the existing controls into focused cards: live status, gathering plan, timing/recognition, permissions/capture, templates/diagnostics, automation, and activity log.
- Added compact Accessibility, Screen Capture, and Bot status tiles plus a dedicated game-state indicator.
- Separated live status details from the chronological event history so the dashboard no longer mixes a long status dump with log output.
- Styled the event console for readability, with timestamps muted and user-input, successful, and warning/error events distinguished by color. UI button actions are recorded as `UI INPUT` events.
- Added a one-tap COPY LOG action. The log remains local unless the user explicitly copies/shares it.
- Kept the existing settings fields, validation, capture permission flow, diagnostic actions, template manager, Start Bot, Stop Bot, and counter reset behavior.

## Build hotfix: MainActivity Kotlin compatibility

- Replaced the invalid `ScrollView.LayoutParams` reference with `android.widget.FrameLayout.LayoutParams`, which is the correct layout-parameter type for the direct child of a `ScrollView`.
- Replaced the unresolved Kotlin synthetic property `textIsSelectable` with the Android `TextView.setTextIsSelectable(true)` method.
- These changes address the two `MainActivity.kt` compilation errors reported while building the dark UI edition. No Gradle, Kotlin, Android Gradle Plugin, or dependency versions were changed.


## Activity log scrolling fix

- Stop replacing the log TextView contents every second when the log has not changed.
- Auto-follow the newest entry only when the user was already at the actual bottom of the console before an update.
- Preserve the previous scroll offset when new log entries arrive while the user is reading older entries.
- Tighten the bottom detection tolerance and calculate the real scroll range including console padding.
- Allow the nested activity console to handle its own touch scrolling inside the outer dashboard scroll view.

## Screenshot test foreground launch (2026-11-12)

- Screenshot capture, no-tap recognition diagnostics, annotated diagnostic screenshots, and accessibility-node inspection now launch Rise of Kingdoms using the configured game package before starting their countdown.
- Added Android 11+ package visibility declaration for `com.lilithgame.roc.gp` so the app can resolve the game's launcher activity.
- Added an accessibility-root package check. A test proceeds only after the accessibility service confirms the game package is the foreground window, then waits six seconds and checks again immediately before capture/inspection.
- If the game is missing, cannot launch, accessibility is disconnected, capture stops, or the game leaves the foreground, the test is cancelled and no screenshot is taken.
- Screenshot diagnostics remain no-tap operations. This change does not automatically launch the game when the bot itself is started.


## RokGatherBot 2.0 — adaptive recognition and dark control center (2026-11-12)

- Replaced the single long-form screen with a near-black, blue-accented five-section control center: Home, Gather, Recognition, Activity and Settings. The design uses the user's screenshots as visual inspiration only.
- Added a local adaptive-learning ledger. Recognition results are grouped by coarse brightness/contrast environment profiles and can be manually reviewed in the app. A threshold is only calibrated after five confirmed positive and five confirmed negative scored candidates with a minimum 0.045 separation; thresholds remain bounded to 0.70–0.95. Learning can be switched off or reset; original templates are never rewritten.
- Added a verified-positive learning sample when a visual button is followed by a confirmed expected state transition.
- Added illumination-aware matching: expanded bounded local contrast compensation, lower-amplitude Sobel edge retention, and an ROI-cropped coarse-to-fine photometric fallback used only when the normal search is weak.
- Added coarse diagnostic game-state classification and environment/adaptive-threshold reporting. Live automation refreshes the displayed lighting profile from captured frames.
- Retained the existing finite workflow, no-tap diagnostics, accessibility checks, gesture verification and MediaProjection lifecycle safeguards.
- Added unique monotonically increasing learning observation IDs so rapid multi-template diagnostics can be reviewed independently.
- Added a JVM smoke test for profile detection, conservative calibration, sample review, unique IDs and disabled-learning behavior.
- Full Android APK build and device/emulator checks remain unverified because this working environment has no Android SDK/Gradle executable and the source archive omits Gradle wrapper bootstrap files.
