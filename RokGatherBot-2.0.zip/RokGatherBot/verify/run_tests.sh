#!/bin/sh
# Runs the platform-independent Java matcher and coordinate tests on JDK 17+.
set -eu
cd "$(dirname "$0")"
rm -rf out && mkdir out
if command -v javac >/dev/null 2>&1; then JAVAC=javac; else JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"; fi
$JAVAC -d out ../app/src/main/java/com/example/rokbot/TemplateMatcher.java \
  ../app/src/main/java/com/example/rokbot/CoordinateMapper.java \
  MatcherTest.java HybridAndCoordinateTest.java
java -cp out MatcherTest
java -cp out HybridAndCoordinateTest
