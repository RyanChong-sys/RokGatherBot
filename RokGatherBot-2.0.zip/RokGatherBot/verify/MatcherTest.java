import com.example.rokbot.TemplateMatcher;
import com.example.rokbot.TemplateMatcher.Gray;
import com.example.rokbot.TemplateMatcher.Match;
import java.util.Random;

public class MatcherTest {
    static int pass = 0, fail = 0;
    static void check(boolean ok, String name, String detail) {
        if (ok) pass++; else fail++;
        System.out.println((ok ? "PASS  " : "FAIL  ") + name + (detail.isEmpty() ? "" : "  [" + detail + "]"));
    }

    // ---- synthetic scenes -------------------------------------------------------------
    static Gray smooth(int w, int h, long seed) {              // value-noise "artwork" + fine grain
        Random r = new Random(seed);
        int cell = 24, gw = w / cell + 2, gh = h / cell + 2;
        int[] g = new int[gw * gh];
        for (int i = 0; i < g.length; i++) g[i] = r.nextInt(256);
        byte[] p = new byte[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int gx = x / cell, gy = y / cell; double fx = (x % cell) / (double) cell, fy = (y % cell) / (double) cell;
            double v = g[gy * gw + gx] * (1 - fx) * (1 - fy) + g[gy * gw + gx + 1] * fx * (1 - fy)
                     + g[(gy + 1) * gw + gx] * (1 - fx) * fy + g[(gy + 1) * gw + gx + 1] * fx * fy;
            p[y * w + x] = (byte) Math.max(0, Math.min(255, (int) v + r.nextInt(13) - 6));
        }
        return new Gray(w, h, p);
    }
    static Gray textured(int w, int h, long seed) {            // STRESS: hard-edged 5px random cells
        Random r = new Random(seed);
        int cell = 5, cw = (w + cell - 1) / cell, ch = (h + cell - 1) / cell;
        int[] v = new int[cw * ch];
        for (int i = 0; i < v.length; i++) v[i] = r.nextInt(256);
        byte[] p = new byte[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) p[y * w + x] = (byte) v[(y / cell) * cw + (x / cell)];
        return new Gray(w, h, p);
    }
    static void fill(byte[] p, int W, int H, int x0, int y0, int w, int h, int v) {
        for (int y = Math.max(0, y0); y < Math.min(H, y0 + h); y++)
            for (int x = Math.max(0, x0); x < Math.min(W, x0 + w); x++) p[y * W + x] = (byte) v;
    }
    /** Gradient background + panels + "buttons" (150x64, each with its own glyph strokes). */
    static Gray ui(int W, int H, long seed, int[][] buttons) {
        byte[] p = new byte[W * H];
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) p[y * W + x] = (byte) (40 + 60 * y / H + 20 * x / W);
        Random r = new Random(seed);
        for (int i = 0; i < 6; i++) fill(p, W, H, r.nextInt(W - 300), r.nextInt(H - 200), 200 + r.nextInt(400), 100 + r.nextInt(200), 90 + r.nextInt(50));
        for (int[] b : buttons) {
            fill(p, W, H, b[0], b[1], 150, 64, 30);
            fill(p, W, H, b[0] + 2, b[1] + 2, 146, 60, 200);
            Random g = new Random(b[2]);
            for (int k = 0; k < 7; k++) fill(p, W, H, b[0] + 8 + g.nextInt(90), b[1] + 6 + g.nextInt(46), 20 + g.nextInt(30), 4, 50);
        }
        return new Gray(W, H, p);
    }
    static Gray crop(Gray g, int x, int y, int w, int h) {
        byte[] o = new byte[w * h];
        for (int j = 0; j < h; j++) System.arraycopy(g.px, (y + j) * g.w + x, o, j * w, w);
        return new Gray(w, h, o);
    }
    static Gray perturb(Gray g, int amp, int shift, long seed) {
        Random r = new Random(seed);
        byte[] o = new byte[g.px.length];
        for (int i = 0; i < o.length; i++) o[i] = (byte) Math.max(0, Math.min(255, (g.px[i] & 0xFF) + shift + r.nextInt(2 * amp + 1) - amp));
        return new Gray(g.w, g.h, o);
    }
    static String s(Match m) { return m == null ? "null" : m.toString(); }

    public static void main(String[] a) {
        final int W = 2400, H = 1080;
        final double T = 0.75;

        // 1. exact match at every sub-block phase (x,y mod 4 = 0..3), hard-edged texture
        Gray tex = smooth(W, H, 1);
        int[][] pos = {{100, 200}, {1531, 641}, {1202, 302}, {803, 903}, {17, 5}, {2200, 1000}};
        boolean ok = true; String d = "";
        for (int[] p : pos) {
            Match m = TemplateMatcher.find(tex, crop(tex, p[0], p[1], 130, 70), T);
            boolean good = m != null && m.x == p[0] && m.y == p[1] && m.score > 0.999;
            if (!good) d += " miss@" + p[0] + "," + p[1] + "->" + s(m);
            ok &= good;
        }
        check(ok, "exact match, 6 positions / all 4 phases", d);

        // 1b. every one of the 16 sub-block phases on the smooth scene
        ok = true; d = "";
        for (int dx = 0; dx < 4; dx++) for (int dy = 0; dy < 4; dy++) {
            int px = 900 + 37 * dx + dx, py = 400 + 29 * dy + dy;
            Match m = TemplateMatcher.find(tex, crop(tex, px, py, 120, 60), T);
            if (m == null || m.x != px || m.y != py) { ok = false; d += " miss@" + px + "," + py; }
        }
        check(ok, "smooth artwork found at 16 sub-block phases", d);

        // 1c. STRESS (informational): hard-edged random 5px cells, worst case for the coarse pass
        Gray blocky = textured(W, H, 3);
        int hits = 0, tot = 0;
        for (int dx = 0; dx < 4; dx++) for (int dy = 0; dy < 4; dy++) {
            int px = 600 + dx, py = 500 + dy; tot++;
            Match m = TemplateMatcher.find(blocky, crop(blocky, px, py, 130, 70), T);
            if (m != null && m.x == px && m.y == py) hits++;
        }
        System.out.println("INFO  stress texture (random 5px cells): " + hits + "/" + tot + " phases found");

        // 2. sensor-like noise (+-10) and brightness shift (+8) on the screen, clean template
        Gray noisy = perturb(tex, 6, 3, 2);
        Match m2 = TemplateMatcher.find(noisy, crop(tex, 1531, 641, 130, 70), T);
        check(m2 != null && Math.abs(m2.x - 1531) <= 1 && Math.abs(m2.y - 641) <= 1 && m2.score > 0.7, "mild noise (+-6) and brightness shift (+3)", s(m2));

        // 3. template that is not on screen
        Gray other = smooth(W, H, 99);
        Match m3 = TemplateMatcher.find(tex, crop(other, 500, 500, 130, 70), T);
        check(m3 == null, "absent template -> null", s(m3));

        // 4. region restriction
        Gray t4 = crop(tex, 1530, 640, 130, 70);
        Match in = TemplateMatcher.find(tex, t4, T, new int[]{1400, 500, 1800, 800});
        Match out = TemplateMatcher.find(tex, t4, T, new int[]{0, 0, 1000, 1080});
        check(in != null && in.x == 1530 && in.y == 640 && out == null, "region inside/outside", s(in) + " / " + s(out));

        // 5. flat template rejected
        boolean threw = false;
        try { TemplateMatcher.find(tex, new Gray(60, 40, new byte[60 * 40]), T); } catch (IllegalArgumentException e) { threw = true; }
        check(threw, "flat template throws IllegalArgumentException", "");
        boolean validateThrew = false;
        try { TemplateMatcher.validate(new Gray(60, 40, new byte[60 * 40])); } catch (IllegalArgumentException e) { validateThrew = true; }
        check(validateThrew, "preflight validation rejects flat template", "");

        // 6. UI-like scene: found at every phase; decoy button with different glyph is NOT a match
        Gray ref = ui(W, H, 7, new int[][]{{96, 96, 1}});
        Gray tplBtn = crop(ref, 96, 96, 150, 64);
        ok = true; d = "";
        for (int dx = 0; dx < 4; dx++) for (int dy = 0; dy < 4; dy++) {
            int bx = 700 + dx, by = 300 + dy;
            Gray scene = ui(W, H, 7, new int[][]{{bx, by, 1}, {1500, 700, 2}});
            Match m = TemplateMatcher.find(scene, tplBtn, T);
            boolean good = m != null && m.x == bx && m.y == by;
            if (!good) d += " miss@" + bx + "," + by + "->" + s(m);
            ok &= good;
        }
        check(ok, "UI button found at 16 sub-block phases, ignoring decoy", d);
        Gray decoyOnly = ui(W, H, 7, new int[][]{{1500, 700, 2}});
        Match m6 = TemplateMatcher.find(decoyOnly, tplBtn, T);
        check(m6 == null, "decoy button (same colours, other glyph) rejected", s(m6));

        // 7. edges and oversize
        Match c0 = TemplateMatcher.find(tex, crop(tex, 0, 0, 130, 70), T);
        Match c1 = TemplateMatcher.find(tex, crop(tex, W - 130, H - 70, 130, 70), T);
        check(c0 != null && c0.x == 0 && c0.y == 0 && c1 != null && c1.x == W - 130 && c1.y == H - 70, "match at top-left and bottom-right corners", s(c0) + " " + s(c1));
        Gray big = textured(3000, 1200, 5);
        check(TemplateMatcher.find(tex, big, T) == null, "template larger than screen -> null", "");

        // 8. diagnostics mode never reports a confident hit for an absent template
        Match m8 = TemplateMatcher.find(decoyOnly, tplBtn, 0.0);
        check(m8 == null || m8.score < T, "threshold 0.0 returns weak/no candidate when absent", s(m8));

        // 9. tiny template (factor 1 path)
        Gray small = crop(ref, 96, 96, 24, 20);
        Match m9 = TemplateMatcher.find(ui(W, H, 7, new int[][]{{333, 444, 1}}), small, T);
        check(m9 != null && m9.x == 333 && m9.y == 444, "24x20 template (no downscale path)", s(m9));

        // 10. luma + downscale
        Gray g = Gray.fromArgb(new int[]{0xFFFFFFFF, 0xFF000000, 0xFFFF0000, 0xFF00FF00}, 4, 1);
        check((g.px[0] & 0xFF) == 255 && g.px[1] == 0 && (g.px[2] & 0xFF) == 76 && (g.px[3] & 0xFF) == 150, "ARGB -> gray luma", "");
        byte[] blk = new byte[16]; for (int i = 0; i < 16; i++) blk[i] = (byte) (i < 8 ? 100 : 200);
        Gray ds = new Gray(4, 4, blk).downscale(2);
        check(ds.w == 2 && ds.h == 2 && (ds.px[0] & 0xFF) == 100 && (ds.px[3] & 0xFF) == 200, "2x2 box downscale", "");

        // 11. timing on a full 2400x1080 frame
        for (int i = 0; i < 2; i++) TemplateMatcher.find(decoyOnly, tplBtn, T); // warm-up
        long t0 = System.nanoTime();
        int N = 10;
        for (int i = 0; i < N; i++) { TemplateMatcher.find(decoyOnly, tplBtn, T); TemplateMatcher.find(tex, t4, T); }
        double ms = (System.nanoTime() - t0) / 1e6 / (2 * N);
        check(ms < 1500, "speed on 2400x1080 frame", String.format("%.1f ms per search (desktop JVM; phones are slower)", ms));

        System.out.println("\n" + pass + " passed, " + fail + " failed");
        System.exit(fail == 0 ? 0 : 1);
    }
}
