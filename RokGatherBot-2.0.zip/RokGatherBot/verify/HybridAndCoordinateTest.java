import com.example.rokbot.TemplateMatcher;
import com.example.rokbot.CoordinateMapper;
import com.example.rokbot.TemplateMatcher.Gray;
import com.example.rokbot.TemplateMatcher.HybridFrame;
import com.example.rokbot.TemplateMatcher.Match;
import java.util.Arrays;

public final class HybridAndCoordinateTest {
    private static int pass = 0, fail = 0;
    private static void check(boolean ok, String name, String detail) {
        if (ok) { pass++; System.out.println("PASS  " + name); }
        else { fail++; System.out.println("FAIL  " + name + (detail.isEmpty() ? "" : "  [" + detail + "]")); }
    }

    private static Gray paste(Gray background, Gray patch, int x, int y) {
        byte[] out = Arrays.copyOf(background.px, background.px.length);
        for (int row = 0; row < patch.h; row++)
            System.arraycopy(patch.px, row * patch.w, out, (y + row) * background.w + x, patch.w);
        return new Gray(background.w, background.h, out);
    }

    private static Gray background(int w, int h) {
        byte[] px = new byte[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) px[y * w + x] = (byte) (22 + (x * 5 + y * 3) % 35);
        return new Gray(w, h, px);
    }

    private static Gray adjust(Gray source, double gain, int bias) {
        byte[] out = new byte[source.px.length];
        for (int i = 0; i < out.length; i++) {
            int v = (int) Math.round((source.px[i] & 255) * gain + bias);
            out[i] = (byte) Math.max(0, Math.min(255, v));
        }
        return new Gray(source.w, source.h, out);
    }

    public static void main(String[] args) {
        // Reproducible textured template so the hybrid score has meaningful local structure.
        int tw = 72, th = 34;
        byte[] p = new byte[tw * th];
        for (int y = 0; y < th; y++) for (int x = 0; x < tw; x++) {
            int v = ((x * 17 + y * 31 + (x * y) % 47) % 190) + 25;
            if (x < 3 || y < 3 || x >= tw - 3 || y >= th - 3) v = 235;
            p[y * tw + x] = (byte) v;
        }
        Gray template = new Gray(tw, th, p);
        TemplateMatcher.validate(template);

        // Scale support: template cropped at original size, game-side button has a bounded 10% scale change.
        Gray scaled = TemplateMatcher.resize(template, 79, 37);
        Gray scene = paste(background(420, 220), scaled, 213, 87);
        HybridFrame frame = new HybridFrame(scene);
        Match scaleMatch = TemplateMatcher.findHybridBest(frame, scaled, TemplateMatcher.edgeMap(scaled), new int[]{180, 60, 320, 160});
        check(scaleMatch != null && scaleMatch.x == 213 && scaleMatch.y == 87,
            "hybrid matcher locates scaled template in configured ROI", scaleMatch == null ? "null" : scaleMatch.toString());

        // Brightness/contrast compensation should preserve the target location.
        Gray adjustedScene = adjust(paste(background(420, 220), template, 101, 122), 1.28, 24);
        HybridFrame adjustedFrame = new HybridFrame(adjustedScene);
        Match adjustedMatch = TemplateMatcher.findHybridBest(adjustedFrame, template, TemplateMatcher.edgeMap(template), new int[]{70, 90, 220, 190});
        check(adjustedMatch != null && adjustedMatch.x == 101 && adjustedMatch.y == 122 && adjustedMatch.score >= 0.50,
            "hybrid score tolerates brightness and contrast shift", adjustedMatch == null ? "null" : adjustedMatch.toString());

        // Dark-map simulation: reduce luminance and contrast across both background and target.
        Gray darkScene = adjust(paste(background(420, 220), template, 137, 91), 0.34, 3);
        HybridFrame darkFrame = new HybridFrame(darkScene);
        Match darkMatch = TemplateMatcher.findHybridBest(darkFrame, template,
            TemplateMatcher.edgeMap(template), 0.70, new int[]{90, 50, 240, 180});
        check(darkMatch != null && darkMatch.x == 137 && darkMatch.y == 91 && darkMatch.score >= 0.55,
            "adaptive edge map tolerates strong dark-scene change", darkMatch == null ? "null" : darkMatch.toString());

        // Compare normalized structural maps directly: uniform luma changes should not erase edges.
        Gray darkPatch = adjust(template, 0.34, 3);
        double edgeSimilarity = TemplateMatcher.scoreAt(TemplateMatcher.edgeMap(darkPatch),
            TemplateMatcher.edgeMap(template), 0, 0);
        check(edgeSimilarity >= 0.75, "edge structure remains similar after darkening",
            String.format("similarity=%.3f", edgeSimilarity));

        // Invalid ROI that cannot contain the target/template returns no match.
        Match invalidRegion = TemplateMatcher.findHybridBest(new HybridFrame(scene), scaled,
            TemplateMatcher.edgeMap(scaled), new int[]{0, 0, 50, 50});
        check(invalidRegion == null, "ROI too small for template is safely rejected", String.valueOf(invalidRegion));

        // Two identical visible buttons must be reported separately so the caller can reject an
        // ambiguous target instead of blindly tapping the first screen-wide hit.
        Gray duplicateScene = paste(paste(background(420, 220), template, 55, 74), template, 260, 126);
        java.util.List<Match> duplicates = TemplateMatcher.findHybridCandidates(
            new HybridFrame(duplicateScene), template, TemplateMatcher.edgeMap(template),
            new int[]{0, 0, 420, 220}, 2);
        check(duplicates.size() == 2 &&
                ((duplicates.get(0).x == 55 && duplicates.get(0).y == 74) || (duplicates.get(1).x == 55 && duplicates.get(1).y == 74)) &&
                ((duplicates.get(0).x == 260 && duplicates.get(0).y == 126) || (duplicates.get(1).x == 260 && duplicates.get(1).y == 126)),
            "competing identical detections are both surfaced", duplicates.toString());
        check(TemplateMatcher.findHybridCandidates(new HybridFrame(scene), template,
                TemplateMatcher.edgeMap(template), null, 0).isEmpty(),
            "candidate count zero safely returns no detections", "");

        // 3168x1440 -> 1584x720 has equal aspect, so exact x/y scaling is possible.
        CoordinateMapper.Point point = CoordinateMapper.map(1584f, 720f, 3168, 1440,
            1584, 720, 1, 1);
        check(point != null && point.x == 792f && point.y == 360f,
            "landscape capture-to-display mapping scales coordinates", point == null ? "null" : point.x + "," + point.y);

        check(CoordinateMapper.map(100, 100, 3168, 1440, 1440, 3168, 1, 0) == null,
            "landscape-to-portrait mapping is rejected", "");
        check(CoordinateMapper.map(100, 100, 3168, 1440, 1584, 720, 1, 3) == null,
            "unexpected 180-degree rotation is rejected", "");
        check(CoordinateMapper.map(3168, 10, 3168, 1440, 1584, 720, 1, 1) == null,
            "out-of-bounds capture point is rejected", "");
        check(CoordinateMapper.map(Float.NaN, 10, 3168, 1440, 1584, 720, 1, 1) == null,
            "non-finite input coordinate is rejected", "");

        System.out.println("\n" + pass + " passed, " + fail + " failed");
        System.exit(fail == 0 ? 0 : 1);
    }
}
