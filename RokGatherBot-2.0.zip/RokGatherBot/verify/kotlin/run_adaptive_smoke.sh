#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
OUT="$ROOT/verify/kotlin/out"
rm -rf "$OUT" && mkdir -p "$OUT"
javac -d "$OUT" "$ROOT/app/src/main/java/com/example/rokbot/TemplateMatcher.java"
kotlinc -classpath "$OUT" "$ROOT/app/src/main/java/com/example/rokbot/AdaptiveLearning.kt" \
  "$ROOT/verify/kotlin/AdaptiveLearningSmoke.kt" -include-runtime -d "$OUT/adaptive-smoke.jar"
java -cp "$OUT/adaptive-smoke.jar:$OUT" com.example.rokbot.AdaptiveLearningSmokeKt
