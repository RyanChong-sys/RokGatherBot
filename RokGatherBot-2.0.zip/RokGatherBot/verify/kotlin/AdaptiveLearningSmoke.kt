package com.example.rokbot

import java.io.File

@Suppress("UNUSED_PARAMETER")
object BotService { fun log(message: String) {} }
@Suppress("UNUSED_PARAMETER")
object Config { fun thresholdFor(id: String): Double = 0.78 }

fun main() {
    val root = java.nio.file.Files.createTempDirectory("rokbot-learning-").toFile()
    try {
        AdaptiveLearning.enabled = true
        val gray = TemplateMatcher.Gray(4, 4, ByteArray(16) { 40 })
        val profile = AdaptiveLearning.profile(gray)
        check(profile.key.startsWith("DARK")) { "Expected DARK profile, got ${profile.key}" }

        val insufficient = File(root, "insufficient").apply { mkdirs() }
        repeat(4) {
            AdaptiveLearning.record(insufficient, "tab_food", profile, 0.90, 0.78, true, 20, 20, true)
            AdaptiveLearning.record(insufficient, "tab_food", profile, 0.55, 0.78, false, 40, 40, false)
        }
        check(AdaptiveLearning.calibratedThreshold(insufficient, "tab_food", profile.key, 0.78) == null) {
            "Calibration must wait until there are at least five examples per class"
        }

        val overlapping = File(root, "overlapping").apply { mkdirs() }
        repeat(5) {
            AdaptiveLearning.record(overlapping, "tab_food", profile, 0.78, 0.78, true, 20, 20, true)
            AdaptiveLearning.record(overlapping, "tab_food", profile, 0.77, 0.78, false, 40, 40, false)
        }
        check(AdaptiveLearning.calibratedThreshold(overlapping, "tab_food", profile.key, 0.78) == null) {
            "Overlapping positive/negative scores must not change a threshold"
        }

        val calibratedFolder = File(root, "calibrated").apply { mkdirs() }
        repeat(5) {
            AdaptiveLearning.record(calibratedFolder, "tab_food", profile, 0.90, 0.78, true, 20, 20, true)
            AdaptiveLearning.record(calibratedFolder, "tab_food", profile, 0.55, 0.78, false, 40, 40, false)
        }
        val calibrated = AdaptiveLearning.calibratedThreshold(calibratedFolder, "tab_food", profile.key, 0.78)
        check(calibrated != null && calibrated in 0.70..0.95) { "Expected conservative calibration, got $calibrated" }
        check(AdaptiveLearning.pending(calibratedFolder, 20).isEmpty()) { "Trusted-labelled examples should not be pending" }

        AdaptiveLearning.record(calibratedFolder, "btn_search", profile, -1.0, 0.78, false)
        check(AdaptiveLearning.pending(calibratedFolder).size == 1) { "Unreviewed observation should be pending" }
        val pending = AdaptiveLearning.pending(calibratedFolder).first()
        check(AdaptiveLearning.label(calibratedFolder, pending.timestamp, true)) { "Manual feedback should be saved" }
        check(!AdaptiveLearning.label(calibratedFolder, pending.timestamp, false)) { "A sample must not be relabelled silently" }
        val timestamps = AdaptiveLearning.recent(calibratedFolder, 20).map { it.timestamp }
        check(timestamps.distinct().size == timestamps.size) { "Review timestamps must be unique" }

        AdaptiveLearning.enabled = false
        val count = AdaptiveLearning.recent(calibratedFolder, 20).size
        AdaptiveLearning.record(calibratedFolder, "tab_food", profile, 0.99, 0.78, true, 0, 0)
        check(AdaptiveLearning.recent(calibratedFolder, 20).size == count) { "Disabled learning must not collect samples" }
        println("PASS adaptive profile, minimum sample gate, overlap rejection, safe calibration, review feedback, unique IDs, and disabled mode")
    } finally {
        root.deleteRecursively()
    }
}
