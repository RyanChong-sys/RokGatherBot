# RokGatherBot 2.0 — Adaptive Recognition & Dark Control Center

This project is the 2.0 update of the supplied Android accessibility/MediaProjection resource-gathering assistant. The interface now uses a near-black control-center layout, muted blue accents, rounded panels and five focused sections: **Home**, **Gather**, **Recognition**, **Activity** and **Settings**. The ZKMNEXT screenshots were used only as visual inspiration; no copied branding or screen layout is included.

## RokGatherBot 2.0 additions

### Dark control-center UI

- Reorganized status, gathering configuration, recognition tools, activity history and Android permissions into separate pages.
- High-contrast service tiles show accessibility, capture and bot status; a game-state chip and live device/frame information remain visible on Home.
- Bottom navigation switches between the five sections without rebuilding their content.
- Template Studio uses the same dark/blue visual language for screenshot cropping and ROI selection.
- Activity log remains independently scrollable, preserves the reader's position when new lines arrive, colours timestamps/event categories, and has a user-initiated Copy Log action.
- Button actions and navigation are recorded as explicit UI events.

### Adaptive illumination-aware recognition

- Adds a lightweight environment profile based on sampled frame brightness (luma) and contrast. Profiles are coarse labels such as `DARK_LOW_CONTRAST`, `NORMAL_NORMAL_CONTRAST` and `BRIGHT_NORMAL_CONTRAST`; they are not a semantic claim that the game is literally in day/night mode.
- Keeps the original bounded multi-scale, grayscale and edge matcher. The edge map keeps low-amplitude gradients, so faint edges in darker frames are not discarded prematurely.
- When the regular search is weak, a bounded coarse-to-fine photometric-normalized fallback searches the configured ROI. It crops to the ROI first, retains a small number of spatially distinct candidates and refines them at full resolution. It does not enable unrestricted arbitrary scaling.
- Candidate scoring compensates for local brightness/contrast differences with bounded normalization and combines grayscale similarity with edge structure. A wrong/ambiguous candidate is still rejected by thresholds and competing-match logic.

### On-device learning with human-verified feedback

- Recognition diagnostics store compact observations (template ID, environment profile, score, threshold, accept/reject status and candidate centre) in `templates/adaptive_learning.csv`. The screenshots themselves are not added to the learning store, uploaded, or transmitted.
- In **Recognition → Adaptive Intelligence**, review pending examples and mark a candidate as correct/incorrect, or confirm that a target was present when no candidate was found. Feedback stays on the device.
- A button/environment threshold is calibrated only after at least **five reviewed positive and five reviewed negative scored candidates** exist and the weakest positive is separated from the strongest negative by at least 0.045. Candidate thresholds are clamped to 0.70–0.95. Unreviewed observations never change thresholds; ambiguous or overlapping score populations leave the base threshold untouched.
- Confirmed UI state transitions can add trusted positive samples. Learning can be disabled or the local learning memory reset. Resetting learning does not delete original templates, ROIs, or gathering settings.
- This is a conservative local feedback/calibration system, not an online neural-network trainer. It does not rewrite app code or automatically overwrite template PNGs. No TFLite model or OCR dependency was added.

### Workflow verification

- Diagnostic runs now classify a likely visible interface state independently from the last bot state and log the lighting profile plus any adaptive threshold actually used.
- During automation, the last environment profile is refreshed from captured frames.
- A target must remain in a consistent position over two consecutive frames before a visual gesture is dispatched. The existing package, ROI, state-transition, coordinate and gesture checks remain in force.

# RokGatherBot — hybrid recognition update

Android accessibility automation prototype for a user-configured Rise of Kingdoms resource-gathering workflow. It uses only supported Android AccessibilityService and MediaProjection APIs; it does not require root, game memory access, process injection, or game-client modification.

> **Important verification limit:** the uploaded source archive contained no game screenshots or template PNGs. Therefore the exact visual reason the old `btn_search` screenshot did not match cannot be proven from this archive. This update fixes the loader/recognition architecture and adds a template/ROI calibration workflow, but it cannot manufacture the missing real-game assets. The first real-device task is to capture and calibrate them.

## What changed

### Hybrid visual recognition

- Keeps the existing pure-Java matcher and adds a `RecognitionProvider` interface for future detector backends.
- Loads both legacy `templates/<id>.png` files and multiple real PNG variants from `templates/<id>/<variant>.png`.
- Tests a bounded scale set (default 0.90, 0.95, 1.00, 1.05, 1.10), not arbitrary scaling.
- Combines normalized grayscale/brightness-compensated matching with Sobel edge matching (45% grayscale / 55% edge score).
- Rejects low-confidence matches, undersized/flat templates, and close competing detections.
- Supports per-template threshold overrides in `threshold_config.txt` (identifier=value, 0.50–0.99).
- Supports calibrated normalized ROIs in `roi_config.txt`. **Automation is blocked until every template required by the selected resource rotation, including blocker/close templates, has an ROI.** A full-frame fallback is retained for read-only diagnostics, not bot actions.

### Workflow and accessibility

- Tracks `UNKNOWN`, `WORLD_MAP`, `SEARCH_PANEL`, `RESOURCE_SELECTION`, `RESOURCE_INFORMATION`, `TROOP_SELECTION`, `MARCH_CONFIRMATION`, `POPUP`, `GATHERING`, and `ERROR` states.
- Each action is allowed only in its configured workflow state. The next step is gated on a positive marker match in the expected next state.
- Accessibility-node inspection reports package/window, text, content descriptions, resource IDs, screen bounds, clickable/enabled/visible flags, and tree depth. A supplementary tap candidate is accepted only when exactly one clickable, enabled, visible node in the Rise of Kingdoms package has an expected label and in-display bounds. Ambiguous nodes are rejected. Many game buttons may be custom-rendered and expose no nodes; visual templates remain the primary path.
- Four events are logged separately: visual/semantic target found, gesture dispatch accepted by Android, gesture completed/cancelled by Android, and expected UI transition confirmed.
- Gesture dispatch is serialized on the main thread. It validates display bounds, screen orientation, coordinate mapping and foreground package; only one gesture can be in flight. A callback timeout adds a duplicate-action cooldown.
- March success means the March dialog/button disappeared from its original bounds in two successive frames across all known variants. This is a **UI transition signal**, not proof that troops arrived or resources were collected.

### Capture lifecycle and diagnostics

- STOP BOT stops the workflow but keeps screen capture available.
- STOP SCREEN CAPTURE is blocked while the bot is active. It releases the `MediaProjection`, `VirtualDisplay`, `ImageReader`, latest `Image`, capture handler thread, callback registration, and foreground notification. If `MediaProjection.stop()` throws, capture remains marked active and the UI does not report a successful release. A new permission result is not treated as started until `ScreenCapture` explicitly accepts that exact projection; rejected new sessions are stopped, and pending failed-stop sessions remain tracked for another explicit cleanup attempt.
- Android revocation of screen capture stops the bot automatically.
- Unexpected portrait orientation, display rotation/size changes, or frame-size changes cancel the workflow and require a manual restart after recalibration.
- The status area shows accessibility, capture/bot states, orientation and frame/display dimensions, required/missing templates, current game state, last button/confidence, last gesture, last transition, resource rotation and persistent attempt counters.
- Recognition Test is read-only. Annotated local PNG diagnostics show accepted/rejected candidates, bounds, confidence, configured ROIs, state, dimensions and last tap marker. Files are stored locally, capped at 25 images / 40 MB, and can be cleared from the UI.

### Gathering settings

- Food, Wood, Stone and Gold remain user-selectable. Repeated entries in the rotation increase that resource's attempt weight.
- March slots remain configurable (1–6); start with **1**.
- Retry delay doubles after empty rounds (for example 2, 4, 8 minutes), with configurable initial and maximum delays and a finite retry-wait count.
- Settings and counters remain in app-private SharedPreferences.

## Why the old `btn_search` failed

The old implementation expected one flat file named exactly `templates/btn_search.png`. It did not discover a folder of variants. It also searched the full screenshot when no ROI was configured, used the same confidence threshold globally, and did not report per-variant decoding/dimensions. Since the supplied archive has no PNG files at all, the original match score cannot be reproduced and the actual crop/resolution mismatch cannot be diagnosed yet. The updated inventory and read-only diagnostic mode will report missing, undecodable, low-contrast, duplicate, unmapped and out-of-range templates with the observed frame size and score.

## Template capture and calibration

The implementation recognises these 13 identifiers (the currently selected rotation determines which resource-tab templates are required for starting):

`btn_search`, `tab_food`, `tab_wood`, `tab_stone`, `tab_gold`, `btn_search_go`, `btn_gather`, `btn_new_troops`, `btn_march`, `btn_close`, `popup_no_free_march`, `popup_not_found`, `popup_no_troops`.

The app's template directory is normally:

`Android/data/com.example.rokbot/files/templates/`

The app also writes `last_screenshot.png` beside that folder.

1. Enable the RoK Gather Bot accessibility service in Android Settings.
2. Start screen capture and allow Android's MediaProjection prompt.
3. Display the relevant Rise of Kingdoms interface in landscape and use **Screenshot in 6 s**.
4. Open **Manage / capture template variants**. Drag a tight box around the actual button and save it under the correct identifier. Add further variants from genuine screenshots (for example `btn_search/search_01.png`, `search_02.png`). Do not invent, recolor, or draw fake template assets.
5. In Template Maker, select **Save search ROI** and draw the larger region within which that button is expected to appear. Save an ROI for each required button and each popup/close template. ROIs are normalized to the screenshot size and scale with display dimensions.
6. Repeat this for the actual game states: world map, search panel, resource selection, resource information, troop selection, march dialog, and popup screens. Capture each state separately.
7. Use **Template inventory** to check file existence, PNG decodability, dimensions, duplicate hashes, variants and ROI calibration. Use **Run recognition test** while each relevant state is visible. It performs no taps.
8. Save annotated diagnostic screenshots and inspect candidate boxes/scores. If `btn_search` remains weak, use the logged path, variant dimensions, score and ROI to re-capture the button—not a blind lower threshold.

Legacy flat templates remain loadable, but new templates should use per-ID variant folders. PNGs smaller than 8×8, over 4 MP, or too low in contrast are rejected. Non-PNG files inside an ID's variant folder are listed as invalid.

### Configuration files

Both files live beside the template folders:

`roi_config.txt` lines use normalized coordinates:

```text
btn_search=0.00,0.00,0.30,1.00
```

This line is only a format example, **not a recommended/search region**. Capture the ROI from the real UI using Template Maker. Coordinates are `left,top,right,bottom` in the range 0–1.

Per-template thresholds are optional:

```text
btn_search=0.82
btn_march=0.80
```

The defaults remain the global setting shown in the app unless overridden. Tune only with real screenshots and inspect false positives before lowering thresholds.

## OCR and optional object detection

No OCR runtime was added in this build. The current project had no OCR dependency and this environment does not have the Android Gradle/SDK toolchain to verify a new ML dependency's packaging/build impact. Accessibility text/content descriptions are inspected when exposed, but custom-rendered game controls may have no accessible nodes. An offline ML Kit bundled Text Recognition model could be evaluated later as a supplementary label/ROI check; it must not be used as the sole tap authority.

The `RecognitionProvider` and `RecognitionRouter` are the extension point for a future detector. A practical first experiment would be an INT8 TensorFlow Lite EfficientDet-Lite0 or SSD MobileNet detector trained on screenshots from this device. Label real button/popup bounding boxes, include different UI states/brightness/scales, train a detector, export a TFLite model, then compare its boxes against the current ROI/template result before allowing any action. Benchmark on the AQUOS R5G with CPU first; NNAPI/GPU support and latency must be measured on-device, not assumed. The detector is not included or required in this update.

## Build configuration and commands

The **uploaded project** has:

- Android Gradle Plugin: 8.5.2
- Kotlin Android plugin: 1.9.24
- Gradle distribution URL in `gradle/wrapper/gradle-wrapper.properties`: **8.7**
- compileSdk / targetSdk: 34 / 34; minSdk: 26
- Java/Kotlin target: 17

This differs from the environment description in the request, which stated Gradle wrapper 9.6.1. I preserved the uploaded project's actual 8.7 wrapper property rather than silently changing the build tool version. The ZIP also did not contain `gradlew`, `gradlew.bat`, or `gradle-wrapper.jar`; those wrapper bootstrap files must be present in the Code on the Go project folder for a `sh gradlew ...` command to work.

The requested command, when the wrapper files are restored/provided by the IDE, is:

```sh
sh gradlew -Pandroid.aapt2FromMavenOverride="$HOME/android-sdk/build-tools/36.0.0/aapt2" :app:assembleDebug --console=plain
```

Expected APK output:

`app/build/outputs/apk/debug/app-debug.apk`

No APK was generated in this environment: it has no Gradle executable, no wrapper JAR/scripts in the upload, and no Android SDK `android.jar`. Open the project in Code on the Go, ensure its wrapper/tooling is installed, and run the command above. Do not overwrite the existing wrapper property with 9.6.1 unless that is the actual tested version in your local project.

## Tests and verification status

Run platform-independent matcher tests with:

```sh
sh verify/run_tests.sh
```

The included JVM tests cover exact matching, sub-block positions, brightness/noise, absent/flat/oversized templates, ROIs, decoy glyphs, hybrid grayscale/edge matching, bounded scaling, brightness/contrast shifts, and coordinate mapping / orientation / bounds checks.

The current 2.0 verification includes **28 passing platform-independent Java tests** (16 core matcher + 12 hybrid/coordinate tests) and a separate passing Kotlin adaptive-learning smoke test using lightweight app-service stubs. XML resources validate, and the modified UI files passed a Kotlin syntax scan. See `TEST_REPORT.md` for exact scope and limits.

Not performed: Gradle assembleDebug, full Android framework compilation, Android instrumentation/emulator tests, MediaProjection runtime tests, gesture callback tests, accessibility-node tests against the game, or physical AQUOS R5G/game testing. Those require Android SDK/Gradle tooling and the real game/template assets. The first device test should use one march slot, diagnostic mode, and the read-only recognition test before starting the bot.

## Updated dark interface

The main screen now uses a dark control-center layout. Live Accessibility, Screen Capture, and Bot status are shown separately from the game-state and configuration details. Gathering settings, capture permissions, template/diagnostic tools, and automation buttons are grouped into separate cards. The Activity Log is a dedicated scrollable console rather than being appended to the status text. UI button presses are logged as `UI INPUT` entries; recognition and service messages remain in the same chronological stream. Use **COPY LOG** to copy the local log manually when sharing diagnostics.

The UI refresh does not change the gathering workflow, recognition thresholds, or capture permissions. It changes presentation and adds chronological logging of dashboard button inputs.


### Activity log scrolling

The activity console only follows new events when it was already at the bottom. When the user scrolls upward to inspect older messages, incoming log entries no longer force the console back down; the existing scroll position is restored after the log refresh. Unchanged log content is not re-rendered on every dashboard refresh.

## Automatic Rise of Kingdoms launch for screenshot tests

The screenshot-related diagnostic actions now open Rise of Kingdoms (`com.lilithgame.roc.gp`) automatically. This applies to **CAPTURE SCREENSHOT**, **RUN RECOGNITION TEST**, **SAVE ANNOTATED SCREENSHOT**, and **INSPECT ACCESSIBILITY NODES**. The app first checks that screen capture is active (for image-based tests) and that its AccessibilityService is connected. It launches the game, waits up to 15 seconds for the service's active accessibility root to report the Rise of Kingdoms package, then starts the existing six-second countdown. It verifies the foreground package again immediately before taking a screenshot or inspecting nodes. If any check fails, the test is cancelled without capturing the RokGatherBot screen.

This uses the configured game package `com.lilithgame.roc.gp`; the manifest includes a package-visibility `<queries>` entry for Android 11 and newer. It does not perform game taps. Accessibility must be enabled for foreground verification. Keep Rise of Kingdoms installed and launchable on the device.


## RokGatherBot 2.0 learning notes and safe use

The adaptive engine improves **decision calibration** from reviewed examples; it does not currently train a neural network or automatically invent/replace real-game templates. A manually reviewed no-candidate example is retained as evidence of a false negative, but because it has no measurable candidate score it is not used to calculate a numeric confidence threshold. The best response to repeated false negatives is still to inspect the annotated screenshot, ROI and real crop and add a genuine variant if the button's appearance actually differs.

Start with one march slot and use read-only Recognition Test before enabling automation. Keep the game in landscape at the same display configuration during calibration. A lighting profile is a coarse statistic of the complete frame; overlays, snow, popups and map colours can affect it. It is useful for grouping evidence, not a perfect weather/time classifier.

**Backup before replacing an installed build:** templates, ROI and learning data are app-specific files, normally under `Android/data/com.example.rokbot/files/templates/`. Copy this folder somewhere safe before uninstalling or clearing app storage. Installing an update with the same package/signing key normally preserves app data; uninstalling or clearing storage can remove it.

### Build availability

The source project keeps its existing Android Gradle Plugin/Kotlin/SDK configuration. The included `gradle-wrapper.properties` points to Gradle 8.7, while some Code on the Go environments may launch builds using their configured Gradle version. This archive does not contain `gradlew`, `gradlew.bat` or `gradle-wrapper.jar`; use Code on the Go's project task runner (`:app:assembleDebug`) or restore the matching wrapper bootstrap files if using a shell command. Expected debug APK path: `app/build/outputs/apk/debug/app-debug.apk`.
